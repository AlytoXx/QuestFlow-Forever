## 1.0.0-alpha.6 — Stabilité et remises proches — 5 novembre 2026

- Une quête active terminée peut être rendue même si les filtres métier/groupe/élite sont désactivés. Un report explicite reste respecté.
- Remise prioritaire à moins de 40 yards (environ 37 mètres), même carte, avec approche estimée à 15 secondes maximum. Aucun classement « proche » à partir d'un pourcentage de carte. Les accès incertains ou longs ne sont pas forcés.
- La comparaison des quêtes à prendre précède désormais la protection contre les changements de direction ; le premier objectif imposé reste respecté.
- Les changements de sous-zone sur la même carte et les événements concernant d'autres quêtes ne suppriment plus la protection de la route.
- Une position de camp déjà suivie reste choisie tant qu'elle existe dans les données actuelles du fournisseur. Une position native du jeu reste autoritaire ; pas de verrouillage d'une position inventée.
- Les étapes facultatives ajoutées conservent leur objectif principal ; elles ne viennent plus interrompre une instruction déjà suivie.
- Catégories compactes : Métier (si identifié), À rendre, À prendre, Déplacement (passage/autre zone), Objectif. Bouton Plus tard : report de 30 minutes sans abandon. Optimisation manuelle toujours disponible via /qf opt.
- Dialogue de PNJ : mémorisation temporaire (5 minutes) du lieu d'interaction d'une remise confirmée. Cela aide sans QuestieDB, mais ne détecte pas un PNJ inconnu avant dialogue.
- Diagnostic /qf debug : liste des quêtes terminées, présence d'une position et état de report.
- Le correctif des nombres secrets reste inclus.

Installation : quitter le jeu, remplacer Interface/AddOns/QuestFlowForever par le dossier du ZIP, puis relancer. Conserver les SavedVariables.

Validation hors jeu : syntaxe Lua 5.1 ; tests du solveur (14 scénarios), évolution (29), intégration, boucles, profil, guidage, vitesses protégées simulées, import de données et nouvelles régressions de stabilité/remises. Tous réussis. Aucun test sur le client Forever réel ; aucun gain d'XP mesuré annoncé. La priorité de remise nécessite un état terminé et une position exploitable. Les métiers non identifiés faute de données ne sont pas devinés. L'apprentissage par type d'objectif et la comparaison avancée de camps restent à faire.

## 1.0.0-alpha.5-hotfix.1 — 5 novembre 2026

Correction des lectures de vitesse protégée (secret number) dans la navigation, les temps de trajet, l’apprentissage et la détection de blocage. Vérification avant comparaison ; valeur de secours 7 yards/s pour les estimations uniquement. Une vitesse indisponible ne prouve pas que le personnage se déplace. Orientation protégée : flèche masquée temporairement. Aucun contournement des restrictions du client.

Validation : syntaxe Lua 5.1, tests intégration/navigation/évolution/boucles/profil et nouveau test avec API simulées réussis. Les vrais nombres secrets du client ne sont pas reproductibles dans Lua standard : validation en jeu encore nécessaire. Les nouvelles optimisations des camps ne sont pas incluses dans ce correctif.

Installation : quitter le jeu, remplacer le dossier Interface/AddOns/QuestFlowForever par celui de cette archive, puis relancer. Conserver les SavedVariables.

Alpha.5 — calcul des accès et comparaison marginale des offres dans la boucle.

# 1.0.0-alpha.4

Configuration initiale par personnage : classe détectée, métiers automatiques ou choisis, détour maximal et positions facultatives de maîtres connus. Profil modifiable depuis Options ou `/qf profil`.

# 1.0.0-alpha.3

- Flèche compacte, signe de rotation corrigé, approche progressive, stabilisation à l’arrivée.
- Grotte, montagne, détour estimé, passages et approches optionnelles LibQuestDB.
- Haltes courtes chez les maîtres de classe pour les sorts prioritaires.
- Tri prudent du journal, protections et confirmation individuelle avant abandon.

# 1.0.0-alpha.2

- Sessions de durée choisie et reprise après déconnexion.
- Vérification d’offres sur le trajet et mémoire des réponses du PNJ.
- Corrections ciblées, aide en cas de blocage et passages vers les objectifs.
- Apprentissage local des déplacements, transitions et progressions partagées.
- Arrêts marchands utiles, besoins de réparation et objets de quêtes à conserver.
- Anticipation prudente des suites documentées, diagnostics et export/import local.

Cette livraison prolonge la branche 1.0.0-alpha.1. Voir README.md pour les limites et la procédure de test en jeu.
