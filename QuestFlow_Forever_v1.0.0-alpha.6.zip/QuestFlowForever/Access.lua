local _,Q=...
local labels={cave='Grotte',mountain='Montagne',detour='Grand détour'}
function Q:MarkTerrain(kind)
    local current=self.route and self.route[1];local a=current and (current.originalAction or current)
    if not a or not labels[kind] then return self:Print('Choisis une étape de quête avant de marquer le terrain.') end
    self.db.terrain=self.db.terrain or {};local old=self.db.terrain[a.key]
    self.db.terrain[a.key]=not(old and old.kind==kind) and {kind=kind,stamp=self.stamp} or nil
    self:Print(self.db.terrain[a.key] and (labels[kind]..' signalé pour cette étape.') or 'Signalement retiré.');self:UpdateUI()
end
local function usable(n)return type(n)=='number' and n==n and math.abs(n)<math.huge end
function Q:Approach(point)
    local e=point and point.entity
    if not e or not e.area or not e.id or not LibStub or not C_Map or not C_Map.GetMapPosFromWorldPos or not CreateVector2D then return end
    local ok,lib=pcall(function()return LibStub('LibQuestDB-1.0',true)end)
    if not ok or not lib or not lib.GetSpawnApproach or (lib.IsReady and not self.Safe(lib.IsReady,lib)) then return end
    local cacheKey=e.kind..':'..e.id..':'..e.area..':'..self:PointKey(point)
    self.approaches=self.approaches or {};local cache=self.approaches[cacheKey]
    if cache and GetTime()<cache.untilTime then return cache.path end
    local path=self.Safe(lib.GetSpawnApproach,lib,e.kind,e.id,e.area,e.x,e.y)
    local pts={};local length=0
    if path and type(path.points)=='table' and #path.points>=2 and #path.points<=120 then
        for _,xyz in ipairs(path.points) do
            if not (type(xyz)=='table' and usable(xyz[1]) and usable(xyz[2])) then pts={};break end
            local map,v=self.Safe(C_Map.GetMapPosFromWorldPos,path.continent,CreateVector2D(xyz[1],xyz[2]),point.map)
            local p=v and {map=map,x=v.x and v.x*100,y=v.y and v.y*100}
            if not self.ValidPoint(p) or map~=point.map then pts={};break end
            if #pts>0 then local d,real=self:MapDistance(pts[#pts],p);if not real then pts={};break end;length=length+d end
            pts[#pts+1]=p
        end
    end
    local result
    if #pts>=2 then
        local tail,exact=self:MapDistance(pts[#pts],point);local direct=self:MapDistance(pts[1],point)
        if exact and tail<100 and direct then result={points=pts,long=length-direct>100 and length>1.6*direct} end
    end
    self.approaches[cacheKey]={untilTime=GetTime()+60,path=result};return result
end
function Q:AccessTarget(a)
    if not a then return end
    local core=a.originalAction or a
    local mark=self.db.terrain and self.db.terrain[core.key]
    local label=mark and mark.stamp==self.stamp and labels[mark.kind] or nil
    local kind=label and mark.kind
    if not label and core.kind=='work' then
        local words=core.objectiveText
        if not words and core.quest then
            local texts={};for _,o in ipairs(core.quest.objectives or {})do if not o.finished then texts[#texts+1]=o.text or '' end end
            if #texts==1 then words=texts[1] end
        end
        words=tostring(words or ''):lower()
        for _,phrase in ipairs({'dans la grotte','dans la caverne','inside the cave','inside the cavern'})do
            if words:find(phrase,1,true) then kind='cave';label='Grotte';break end
        end
        for _,phrase in ipairs({'au sommet de la montagne','sur la montagne','on top of the mountain','on the mountaintop'})do
            if words:find(phrase,1,true) then kind='mountain';label='Montagne';break end
        end
    end
    if a.kind=='passage' then return a.point,(label or 'Accès')..' · rejoindre le passage' end
    if a.kind=='trainer' then return a.point,'Maître de classe' end
    local path=self:Approach(a.point)
    if path then
        local key=a.key..':'..self:PointKey(a.point)
        if not self.accessStage or self.accessStage.key~=key then self.accessStage={key=key,index=1} end
        local s=self.accessStage
        while path.points[s.index] do
            local d,real=self:MapDistance(self:PlayerPoint(),path.points[s.index]);if not real or d>12 then break end
            s.index=s.index+1
        end
        return path.points[s.index] or a.point,(label or (path.long and 'Grand détour' or 'Accès balisé'))..(s.index==1 and ' · entrée' or ' · passage')
    end
    if label then
        if kind=='cave' and not self:PassageFor(a) then return nil,'Grotte · entrée inconnue' end
        return a.point,label..' · accès à vérifier'
    end
    local here=self:PlayerPoint();local d,real=self:MapDistance(here,a.point)
    if real and d and d>50 and here.map==a.point.map then
        local t=self:TravelEstimate(here,a.point)
        if t and t>d/self:GroundSpeed()*1.8+30 then return a.point,'Grand détour estimé' end
    end
    return a.point,nil
end
