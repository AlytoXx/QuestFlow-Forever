local _,Q=...
local function nonempty(value)return type(value)=='table' and next(value)~=nil or type(value)=='number' and value~=0 end
function Q:CleanupReason(q)
    if not q.active or q.complete or q.profession or q.classQuest or q.kind~='solo' or not self:Provider() then return end
    if self.db.keepQuests and self.db.keepQuests[q.id] then return end
    if not self:DBGet('Quest',q.id,'name') then return end
    for _,field in ipairs({'childQuests','nextQuestInChain','requiredSkill','requiredClasses','sourceItemId','requiredSourceItems','exclusiveTo','specialFlags','inGroupWith'})do
        if nonempty(self:DBGet('Quest',q.id,field)) then return end
    end
    -- Quest sorts may identify a profession or a class even without a skill gate.
    local category=self:DBGet('Quest',q.id,'zoneOrSort');if type(category)~='number' or category<=0 then return end
    if not q.objectives or #q.objectives==0 then return end
    for _,o in ipairs(q.objectives)do
        if o.finished or type(o.current)~='number' or o.current>0 or o.type=='item' then return end
    end
    local level=self.Safe(UnitLevel,'player');if not level or not q.level or q.level<=0 or level-q.level<8 then return end
    return (level-q.level)..' niveaux d’écart · aucun objectif avancé · aucune suite répertoriée.'
end
function Q:CleanupCandidates()
    local rows={};for _,q in ipairs(self.quests or {}) do
        local reason=self:CleanupReason(q);if reason then rows[#rows+1]={id=q.id,title=q.title,reason=reason,level=q.level} end
    end
    table.sort(rows,function(a,b)return a.level==b.level and a.id<b.id or a.level<b.level end);return rows
end
function Q:ReviewAbandon(id)
    self:ReadQuestLog();local found
    for _,q in ipairs(self:CleanupCandidates())do if q.id==id then found=q end end
    if not found then self:Print('La quête a changé. Liste actualisée.');return self:ShowCleanup() end
    -- Delegate the final decision and any item-loss warning to the native UI.
    if OpenQuestLog then self.Safe(OpenQuestLog,id) elseif ToggleQuestLog and not (QuestLogFrame and QuestLogFrame:IsShown()) then self.Safe(ToggleQuestLog) end
    if C_QuestLog and C_QuestLog.SetSelectedQuest then self.Safe(C_QuestLog.SetSelectedQuest,id) end
    if QuestMapFrame_OpenToQuestDetails then self.Safe(QuestMapFrame_OpenToQuestDetails,id) end
    local api=C_QuestLog
    if api and api.SetSelectedQuest and api.GetSelectedQuest and api.SetAbandonQuest and api.GetAbandonQuestName and api.AbandonQuest
        and StaticPopupDialogs and StaticPopup_Show and self.Safe(api.GetSelectedQuest)==id then
        StaticPopupDialogs.QUESTFLOW_CONFIRM_REMOVE={text='Abandonner « %s » ? La progression et les objets liés peuvent être perdus.',
          button1='Abandonner',button2='Annuler',timeout=0,whileDead=false,hideOnEscape=true,
          OnAccept=function(_,data) Q:ConfirmedRemove(data) end}
        StaticPopup_Show('QUESTFLOW_CONFIRM_REMOVE',found.title,nil,{id=id,title=found.title});return
    end
    self:Print('Journal : sélectionne « '..found.title..' » et utilise Abandonner si tu le souhaites.')
end

function Q:ConfirmedRemove(data)
    if not data or self.Safe(InCombatLockdown) then return end
    local api=C_QuestLog
    if not api or self.Safe(api.GetSelectedQuest)~=data.id then return self:Print('Sélection modifiée : ouvre à nouveau le tri.') end
    self:ReadQuestLog();local safe=false
    for _,q in ipairs(self:CleanupCandidates())do if q.id==data.id and q.title==data.title then safe=true;break end end
    if not safe or self.Safe(api.GetSelectedQuest)~=data.id then return self:Print('Quête modifiée : abandon annulé.') end
    local ok=pcall(api.SetAbandonQuest)
    if not ok or self.Safe(api.GetSelectedQuest)~=data.id or self.Safe(api.GetAbandonQuestName)~=data.title then
        return self:Print('Vérifie cette quête dans le journal du jeu.')
    end
    local called=pcall(api.AbandonQuest)
    if not called then self:Print('Utilise Abandonner dans le journal du jeu.') end
end
