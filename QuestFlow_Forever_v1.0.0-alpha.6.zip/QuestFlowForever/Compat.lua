local _,QF=...
function QF.Safe(fn,...)
    if type(fn)~='function' then return nil end
    local ok,a,b,c,d,e,f,g,h=pcall(fn,...)
    if ok then return a,b,c,d,e,f,g,h end
end
function QF:Provider()
    local lib=_G.LibQuestieDB
    if not lib or not lib.RequireContract then return nil end
    if not self.Safe(lib.RequireContract,4) then return nil end
    local status=lib.ModeIndicator and self.Safe(lib.ModeIndicator.GetStatus)
    -- Never use TBC/Era coordinates on Forever merely because the API matches.
    if not status or tostring(status.expansion):lower()~='forever' then return nil end
    return lib
end
function QF:DBGet(entity,id,key)
    local lib=self:Provider()
    return lib and lib[entity] and self.Safe(lib[entity].Get,id,key)
end
function QF:AreaForMap(map)
    local lib=self:Provider()
    if not lib or not map then return nil end
    if self.mapProvider~=lib then
        self.areaMap={}; self.mapProvider=lib
        local support=lib.Support and self.Safe(lib.Support.Get,'ZoneDB')
        local source=support and support.private and support.private.areaIdToUiMapId
        local values=source
        if type(source)=='string' and loadstring then
            local fn=loadstring(source) or loadstring('return '..source)
            values=self.Safe(fn)
        end
        if type(values)=='table' then
            for area,ui in pairs(values) do
                if type(area)=='number' and type(ui)=='number' then
                    -- Reject ambiguous reverse mappings instead of choosing a random area.
                    if self.areaMap[ui]==nil then self.areaMap[ui]=area
                    elseif self.areaMap[ui]~=area then self.areaMap[ui]=false end
                end
            end
        end
    end
    return self.areaMap[map] or nil
end
function QF:PlayerPosition()
    local map=self:MapID()
    local p=map and C_Map and self.Safe(C_Map.GetPlayerMapPosition,map,'player')
    if p then
        local x,y
        if p.GetXY then x,y=self.Safe(p.GetXY,p) else x,y=p.x,p.y end
        if type(x)=='number' and type(y)=='number' then return x*100,y*100 end
    end
end
function QF:JournalCapacity()
    local cap=C_QuestLog and self.Safe(C_QuestLog.GetMaxNumQuestsCanAccept)
    if type(cap)=='number' and cap>0 then return cap,'API' end
    cap=(Constants and Constants.QuestLogConsts and Constants.QuestLogConsts.MAXIMUM_NUM_QUESTS_LOG_CAN_ACCEPT) or _G.MAX_NUM_QUESTS or _G.MAX_QUESTLOG_QUESTS
    if type(cap)=='number' and cap>0 then return cap,'constante client' end
    return nil,'inconnue'
end
function QF:QuestieAvailableSet()
    local loader=_G.QuestieLoader
    local mod=loader and self.Safe(loader.ImportModule,loader,'AvailableQuests')
    if type(mod)=='table' and type(mod.__availableQuests)=='table' then
        return mod.__availableQuests
    end
    return nil
end
function QF:Diagnostic()
    local version,build,_,interface=self.Safe(GetBuildInfo)
    local lib=_G.LibQuestieDB
    local status=lib and lib.ModeIndicator and self.Safe(lib.ModeIndicator.GetStatus) or {}
    local cap,source=self:JournalCapacity()
    local getMeta=C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    local lines={
      'QuestFlow Forever '..self.VERSION,
      'Client '..tostring(version)..' build '..tostring(build)..' interface '..tostring(interface),
      'Questie '..tostring(self.Safe(getMeta,'Questie','Version'))..' ; QuestieDB '..tostring(self.Safe(getMeta,'QuestieDB','Version')),
      'Base '..tostring(status.expansion)..' / '..tostring(status.mode)..' / contrat '..tostring(lib and lib.contractVersion),
      'Base compatible : '..tostring(self:Provider()~=nil),
      'Journal '..#(self.quests or {})..'/'..tostring(cap)..' ('..source..')',
      'Carte '..tostring(self:MapID())..' / Area '..tostring(self:AreaForMap(self:MapID())),
      'Liste Questie exposée : '..tostring(self:QuestieAvailableSet()~=nil),
      'Offres '..#(self.discovery or {})..' ; étapes '..#(self.route or {}),
      'Journal API : '..tostring(C_QuestLog and type(C_QuestLog.GetInfo)=='function'),
      'Dernière erreur : '..tostring(self.lastError or 'aucune'),
      'Calcul : '..tostring(self.solveStatus or 'en attente'),
      'Session : '..self:SessionText(),
      'Données : '..tostring(self.stamp),
      'Zone : '..tostring(self.zoneDecision or 'non évaluée'),
      'API sacs : '..tostring(C_Container and type(C_Container.GetContainerNumFreeSlots)=='function'),
      'API dialogue complet : '..tostring(C_GossipInfo and type(C_GossipInfo.GetNumAvailableQuests)=='function')}
    for _,q in ipairs(self.quests or {}) do
        if q.complete then
            lines[#lines+1]='À rendre '..q.id..' : '..tostring(q.title)..' / position '..tostring(self.ValidPoint(q.returnPoint)==true)..' / report '..tostring(self:IsSkipped(q.id))
        end
    end
    self.db.lastDiagnostic=table.concat(lines,'\n')
    for _,line in ipairs(lines) do self:Print(line) end
    return self.db.lastDiagnostic
end
