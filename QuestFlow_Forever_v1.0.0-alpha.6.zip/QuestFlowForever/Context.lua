local _,QF=...
function QF:RefreshNeeds()
    local needs={};local free,total=0,0
    local bag=C_Container
    if bag and bag.GetContainerNumFreeSlots and bag.GetContainerNumSlots then
        for i=0,4 do
            local n,family=self.Safe(bag.GetContainerNumFreeSlots,i)
            local slots=self.Safe(bag.GetContainerNumSlots,i)
            if type(n)=='number' and type(slots)=='number' and (family==0 or i==0) then free=free+n;total=total+slots end
        end
        if total>0 and free<=math.max(2,math.floor(total*.08)) then needs.vendor=true end
    end
    local durability
    for i=1,19 do
        local cur,max=self.Safe(GetInventoryItemDurability,i)
        if type(cur)=='number' and type(max)=='number' and max>0 then
            local ratio=cur/max;durability=durability and math.min(durability,ratio) or ratio
        end
    end
    if durability and durability<.30 then needs.repair=true end
    self.needs=needs;self.bagFree=total>0 and free or nil
end
function QF:ObserveMerchant()
    local p=self:PlayerPoint();if not self.ValidPoint(p) then return end
    local guid=self.Safe(UnitGUID,'npc')
    local id=guid and guid:match('^[^-]+%-%d+%-%d+%-%d+%-%d+%-(%d+)%-')
    local key=id or self:PointKey(p)
    self.memory.services[key]={point=self.Copy(p),name=self.Safe(UnitName,'npc') or 'Marchand',
      repair=self.Safe(CanMerchantRepair)==true,at=self:Time(),stamp=self.stamp}
    self.servicedUntil=GetTime()+180;self:RefreshNeeds();self:PruneMemory()
end
function QF:RequiredItems()
    local items={}
    for _,q in ipairs(self.quests or {})do
        for _,o in ipairs(q.objectives or {})do
            if o.type=='item' and type(o.objectID)=='number' and not o.finished then
                local row=items[o.objectID] or {id=o.objectID,quests={},needed=0}
                row.quests[#row.quests+1]=q.title
                row.needed=math.max(row.needed,tonumber(o.needed) or 0)
                items[o.objectID]=row
            end
        end
        local source=self:DBGet('Quest',q.id,'sourceItemId')
        if type(source)=='number' and source>0 then
            local row=items[source] or {id=source,quests={},needed=1};row.quests[#row.quests+1]=q.title;items[source]=row
        end
    end
    self.requiredItems=items;return items
end
function QF:PrintItems()
    local items=self:RequiredItems();local ids={};for id in pairs(items)do ids[#ids+1]=id end;table.sort(ids)
    if #ids==0 then return self:Print('Aucun objet nécessaire identifié avec certitude. Vérifie aussi les objets de quête de tes sacs.') end
    for _,id in ipairs(ids)do
        local row=items[id]
        local name=self.Safe(C_Item and C_Item.GetItemNameByID,id) or ('Objet '..id)
        self:Print('Conserver '..name..' : '..(row.needed>0 and ('objectif '..row.needed..' · ') or '')..table.concat(row.quests,', '))
    end
end
function QF:ServiceStep(origin,destination)
    if not self.db.services or GetTime()<(self.servicedUntil or 0) or not origin or not destination then return end
    self:RefreshNeeds()
    if not(self.needs.vendor or self.needs.repair) then return end
    local direct=self:TravelEstimate(origin,destination.point);if not direct then return end
    local best,bestCost
    for key,s in pairs(self.memory.services)do
        if s.stamp==self.stamp and s.point.map==origin.map and self:Time()-s.at<30*86400
          and (not self.needs.repair or s.repair) then
            local first=self:TravelEstimate(origin,s.point);local after=self:TravelEstimate(s.point,destination.point)
            local delta=first and after and math.max(0,first+after-direct)
            if delta and delta<=20 and first<=45 and (not bestCost or delta<bestCost) then
                bestCost=delta;best={key='service:'..key,id=destination.id,kind='service',title=s.name,
                  point=s.point,map=s.point.map,x=s.point.x,y=s.point.y,
                  reason=self.needs.repair and 'Réparer sur le passage ; vente si utile.' or 'Sacs presque pleins : vendre sur le passage.',
                  quest=destination.quest,serviceKey=key}
            end
        end
    end
    if best and self:ActionBlocked(best) then return nil end
    return best
end
function QF:ExplainAction(a)
    if not a then return self.resumeNotice end
    if a.reason then return a.reason end
    if a.kind=='verify' then return 'Vérifier une offre sur le passage ; disponibilité incertaine.' end
    if a.kind=='passage' then return 'Passage enregistré ; rejoindre ensuite l’objectif.' end
    if a.kind=='pickup' then return 'Prendre avant de rejoindre les objectifs.' end
    if a.kind=='turnin' then return a.nearbyTurnin and 'À rendre tout près : récupère la récompense avant de repartir.' or 'Rendre la quête et libérer une place.' end
    if a.remaining and a.remaining<=2 then return 'Terminer les derniers objectifs ici.' end
    if a.quest and a.quest.chainHint then return 'Cette quête prépare une suite documentée.' end
    return a.aggregate and 'Position représentative : vérifier le journal.' or 'Objectif du journal.'
end
function QF:InstallItemHints()
    if self.itemHintsInstalled then return end
    self.itemHintsInstalled=true
    local function annotate(tooltip,id)
        local row=self.requiredItems and self.requiredItems[id]
        if not row or not tooltip or not tooltip.AddLine or tooltip._questFlowHint==id then return end
        tooltip._questFlowHint=id
        tooltip:AddLine('QuestFlow : conserver pour '..table.concat(row.quests,', '),.4,1,.65,true)
        if row.needed>0 then tooltip:AddLine('Quantité de l’objectif : '..row.needed,.7,1,.8) end
    end
    if GameTooltip and GameTooltip.HookScript then
        self.Safe(GameTooltip.HookScript,GameTooltip,'OnTooltipCleared',function(t)t._questFlowHint=nil end)
        self.Safe(GameTooltip.HookScript,GameTooltip,'OnHide',function(t)t._questFlowHint=nil end)
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        self.Safe(TooltipDataProcessor.AddTooltipPostCall,Enum.TooltipDataType.Item,function(tooltip,data)
            if data and type(data.id)=='number' then annotate(tooltip,data.id) end
        end)
    elseif GameTooltip and GameTooltip.HookScript then
        self.Safe(GameTooltip.HookScript,GameTooltip,'OnTooltipSetItem',function(t)
            local _,link=self.Safe(t.GetItem,t)
            local id=type(link)=='string' and tonumber(link:match('item:(%d+)'))
            if id then annotate(t,id) end
        end)
    end
end
