local ADDON, QF = ...
_G.QuestFlowForever = QF
QF.VERSION = '1.0.0-alpha.6'
QF.candidates = {}
QF.quests = {}
QF.route = {}
QF.ready = false
QF.color = '|cff58d7b0'

function QF:Print(s)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(self.color .. '[QuestFlow]|r ' .. tostring(s)) end
end

local function clone(x)
    local t = {}
    for k,v in pairs(x) do t[k] = type(v)=='table' and clone(v) or v end
    return t
end
local defaults = {
    trainerDetour=45,keepQuests={},prioritySpells={},terrain={},verifyOnPath=true, stallDetection=true, services=true, scale=1, expanded=false, observed={}, elite=false, professionPriority=false, experimentalOffers=false, mode='xp', solo=true, group=false, dungeonQuests=false, dungeonRuns=false, dungeonReady=false,
    autoDetours=true, autoRoute=true, useHearth=false, xpTracking=true, secondsPerObjective=24, professionQuests=true, professionTips=true,
    arrowEnabled=true, arrowInvert=false, arrowPoint={'CENTER','UIParent','CENTER',380,210},
    timeBudget=60, visible=true, flightTips=true, trainerTips=true,
    obsoleteDiff=7, hideObsolete=true, skips={}, flightVisited={},
    flyDismissed={}, acknowledged={}, focus=nil, lastMap=nil,
    point={'CENTER','UIParent','CENTER',330,0}, diag=false,
}
function QF:InitSettings()
    if type(QuestFlowForeverDB) ~= 'table' then QuestFlowForeverDB = {} end
    self.db = QuestFlowForeverDB
    self.observedOffers={}
    self.activeIds={}
    for k,v in pairs(defaults) do
        if self.db[k]==nil or type(self.db[k])~=type(v) then self.db[k]=type(v)=='table' and clone(v) or v end
    end
    self:InitMemory();self:InitSession()
end
function QF:Time() return GetServerTime and GetServerTime() or time() end
function QF:MapID()
    if C_Map and C_Map.GetBestMapForUnit then
        local ok,v=pcall(C_Map.GetBestMapForUnit,'player')
        if ok then return v end
    end
end
function QF:Zone() return (GetZoneText and GetZoneText()) or 'Zone inconnue' end
function QF:QuestFinished(id)
    if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
        local ok,done=pcall(C_QuestLog.IsQuestFlaggedCompleted,id)
        if ok and done~=nil then return done==true end
    end
    if IsQuestFlaggedCompleted then
        local ok,done=pcall(IsQuestFlaggedCompleted,id)
        if ok then return done==true end
    end
    return false
end
function QF:IsSkipped(id)
    local s=self.db and self.db.skips[id]
    if not s then return false end
    if s.untilTime and s.untilTime>0 and self:Time()>=s.untilTime then
        self.db.skips[id]=nil
        return false
    end
    return true
end
function QF:Skip(id,reason)
    if not id then return end
    local durations={crowd=1800,far=3600,hard=3600,group=1800,later=1800,never=0,unwanted=0}
    local delay=durations[reason] or 0
    self.db.skips[id]={reason=reason,untilTime=delay>0 and (self:Time()+delay) or 0}
    if self.db.focus==id then self.db.focus=nil end
    self.currentId=nil
    self:Replan()
end
function QF:ClearSkips()
    self.db.skips={}
    self.memory.corrections={};self.memory.negative={}
    self.db.focus=nil
    self.currentId=nil
    self:Replan()
end
function QF:Replan()
    if not self.ready then return end
    self:ReadQuestLog()
    self:Plan()
    self:UpdateUI()
end
function QF:Optimise()
    if not self.ready then return end
    self.db.focus=nil
    -- Ne jamais conserver les découvertes d'une ancienne zone pendant le nouveau scan.
    self.discovery={}
    if self.ReadProfessions then self:ReadProfessions() end
    self:ReadQuestLog()
    -- Publish one route once discovery is ready; avoid a temporary competing target.
    self.lastDiscoverAt=GetTime and GetTime() or 0
    self.lastDiscoveryPoint=self:PlayerPoint()
    self:BeginDiscovery()
    if self.SyncNavigation then self:SyncNavigation() end
end
function QF:FocusNext()
    if #self.route<2 then return end
    local ix=1
    for i,item in ipairs(self.route) do
        if self.db.focus and item.id==self.db.focus then ix=i break end
    end
    local nextItem=self.route[(ix % #self.route)+1]
    if nextItem and nextItem.id then self.db.focus=nextItem.id end
    self:Plan()
    self:UpdateUI()
end
function QF:SetPreference(key,value)
    if self.db[key]~=nil then
        self.db[key]=value
        self:Optimise()
    end
end

-- Low-frequency movement-driven route refresh. No full database scan every frame.
