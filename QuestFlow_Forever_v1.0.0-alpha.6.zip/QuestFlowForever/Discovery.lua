local _,QF=...
local function valid(p)
    return p and type(p.map)=='number' and type(p.x)=='number' and type(p.y)=='number'
       and p.x>=0 and p.x<=100 and p.y>=0 and p.y<=100
end
QF.ValidPoint=valid
local function copy(t) local r={} for k,v in pairs(t or {}) do r[k]=v end return r end
function QF:EntityPoint(kind,id,map,preferred)
    local area=self:AreaForMap(map)
    if not area then return end
    local spawns=self:DBGet(kind,id,'spawns')
    local list=type(spawns)=='table' and spawns[area]
    if not list and type(spawns)=='table' then
        -- A point in another zone is usable only if the installed provider maps
        -- it unambiguously; Travel will still require observed transitions.
        for ui,a in pairs(self.areaMap or {}) do
            if a and type(spawns[a])=='table' then list=spawns[a];map=ui;break end
        end
    end
    local origin=self:PlayerPoint()
    local best,dist
    for _,xy in ipairs(type(list)=='table' and list or {}) do
        local p={map=map,x=xy[1],y=xy[2],approximate=true,entity={kind=kind=='Npc' and 'npc' or 'object',id=id,area=self:AreaForMap(map),x=xy[1],y=xy[2]}}
        if valid(p) then
            if preferred and preferred.entity and preferred.entity.id==id
              and preferred.entity.kind==p.entity.kind and preferred.map==p.map
              and preferred.x==p.x and preferred.y==p.y then return p end
            local d=self:MapDistance(origin,p) or math.huge
            if not best or d<dist then best=p;dist=d end
        end
    end
    return best
end
function QF:EntityGroupPoint(list,map,preferred)
    if type(list)~='table' then return end
    local best,dist; local origin=self:PlayerPoint()
    for i,kind in ipairs({'Npc','Object'}) do
        for _,id in ipairs(list[i] or {}) do
            local p=self:EntityPoint(kind,id,map,preferred)
            if p then
                if preferred and preferred.entity and p.entity.id==preferred.entity.id
                  and p.entity.kind==preferred.entity.kind and p.map==preferred.map
                  and p.x==preferred.x and p.y==preferred.y then return p end
                local d=self:MapDistance(origin,p) or math.huge
                if not best or d<dist then best=p;dist=d end
            end
        end
    end
    return best
end
function QF:QuestKind(id,info)
    local tag=C_QuestLog and self.Safe(C_QuestLog.GetQuestTagInfo,id)
    local n=type(tag)=='table' and tag.tagID
    if n==62 or n==88 or n==89 then return 'raid' end
    if n==81 or n==85 then return 'dungeon' end
    if n==1 then return 'elite' end
    if info and (tonumber(info.suggestedGroup) or 0)>1 then return 'group' end
    return 'solo'
end
function QF:Enrich(q)
    local map=self:MapID()
    q.returnPoint=self:EntityGroupPoint(self:DBGet('Quest',q.id,'finishedBy'),map)
    q.startPoint=q.startPoint or self:EntityGroupPoint(self:DBGet('Quest',q.id,'startedBy'),map)
    local current=self.route and self.route[1]
    current=current and (current.originalAction or current)
    if current and (current.id~=q.id or current.kind~='work') then current=nil end
    -- Only bind individual objectives when the native API supplies an entity ID.
    -- Aggregate native POI is a fallback, never an assertion of a complete objective map.
    for index,o in ipairs(q.objectives or {}) do
        local preferred=current and current.key==q.id..':work'..index and current.point or nil
        if not o.finished and o.objectID then
            if o.type=='monster' then o.point=self:EntityPoint('Npc',o.objectID,map,preferred)
            elseif o.type=='object' then o.point=self:EntityPoint('Object',o.objectID,map,preferred)
            elseif o.type=='item' then
                local drops=self:DBGet('Item',o.objectID,'npcDrops')
                local objs=self:DBGet('Item',o.objectID,'objectDrops')
                o.point=self:EntityGroupPoint({drops or {},objs or {}},map,preferred)
            end
        end
    end
    local partiallyFinished=false
    for _,o in ipairs(q.objectives or {})do if o.finished then partiallyFinished=true end end
    if not q.workPoint and not partiallyFinished then
        local objectives=self:DBGet('Quest',q.id,'objectives')
        if type(objectives)=='table' then
            local list={{},{}}
            for i=1,2 do for _,entry in ipairs(objectives[i] or {}) do
                if type(entry)=='table' then list[i][#list[i]+1]=entry[1] end
            end end
            for _,entry in ipairs(objectives[3] or {}) do
                if type(entry)=='table' then
                    for _,id in ipairs(self:DBGet('Item',entry[1],'npcDrops') or {}) do list[1][#list[1]+1]=id end
                    for _,id in ipairs(self:DBGet('Item',entry[1],'objectDrops') or {}) do list[2][#list[2]+1]=id end
                end
            end
            q.workPoint=self:EntityGroupPoint(list,map,current and current.aggregate and current.point)
        end
    end
    q.level=q.level or self:DBGet('Quest',q.id,'questLevel')
    q.title=q.title or self:DBGet('Quest',q.id,'name') or ('Quête '..q.id)
    local classes=self:DBGet('Quest',q.id,'requiredClasses')
    q.classQuest=type(classes)=='number' and classes>0
    local starters=self:DBGet('Quest',q.id,'startedBy')
    q.npcIDs=type(starters)=='table' and starters[1] or {}
    q.children=self:DBGet('Quest',q.id,'nextQuestInChain')
    if self.AnnotateProfession then self:AnnotateProfession(q) end
    return q
end
function QF:Remember(q)
    local p=self:PlayerPoint()
    local previous=self.db.observed[q.id] or {}
    previous.title=q.title;previous.level=q.level;previous.seenAt=self:Time()
    previous.objectives=q.objectives;previous.complete=q.complete
    previous.lastObservedPosition=p -- observation position, NEVER an objective coordinate
    previous.state=q.active and 'journal' or q.state or 'potential'
    previous.stamp=self.stamp;previous.source=q.active and 'journal-api' or 'npc-dialogue'
    previous.confidence=q.active and 'confirmed' or 'recent-offer'
    if q.workPoint then previous.workPoint=copy(q.workPoint) end
    if q.startPoint then previous.startPoint=copy(q.startPoint) end
    self.db.observed[q.id]=previous
    -- Bound persistent storage; keep active entries, then newest 500 observations.
    local ids={}
    for id,row in pairs(self.db.observed) do ids[#ids+1]={id=id,at=row.seenAt or 0} end
    if #ids>500 then
        table.sort(ids,function(a,b)return a.at>b.at end)
        for i=501,#ids do if not self.activeIds[ids[i].id] then self.db.observed[ids[i].id]=nil end end
    end
end
function QF:ReadQuestLog()
    self.quests={};self.activeIds={}
    local api=C_QuestLog
    if not (api and api.GetNumQuestLogEntries and api.GetInfo) then
        self.lastError='API de journal moderne absente';return
    end
    local n=self.Safe(api.GetNumQuestLogEntries) or 0
    local map=self:MapID();local poi={}
    for _,p in ipairs(self.Safe(api.GetQuestsOnMap,map) or {}) do
        local point={map=map,x=type(p.x)=='number' and p.x*100,y=type(p.y)=='number' and p.y*100}
        if p.questID and valid(point) then poi[p.questID]=point end
    end
    for i=1,n do
        local row=self.Safe(api.GetInfo,i)
        if row and not row.isHeader and type(row.questID)=='number' and row.questID>0 then
            local id=row.questID
            local complete=self.Safe(api.IsComplete,id)
            local q={id=id,title=row.title,level=row.level or row.difficultyLevel,active=true,
              state='journal',complete=complete==true or complete==1 or row.isComplete==true or row.isComplete==1,
              kind=self:QuestKind(id,row),objectives={},zone=self:Zone()}
            for _,o in ipairs(self.Safe(api.GetQuestObjectives,id) or {}) do
                q.objectives[#q.objectives+1]={text=o.text,finished=o.finished==true,
                  current=o.numFulfilled,needed=o.numRequired,objectID=o.objectID,type=o.type}
            end
            local waypointMap,wx,wy=self.Safe(api.GetNextWaypoint,id)
            local wp={map=waypointMap,x=type(wx)=='number' and wx*100,y=type(wy)=='number' and wy*100}
            if not valid(wp) then wp=nil end
            if q.complete then q.returnPoint=wp or poi[id] else q.workPoint=wp or poi[id] end
            local nativeReturn=q.returnPoint
            self:Enrich(q)
            if nativeReturn and q.returnPoint and q.returnPoint.entity then
                local d,real=self:MapDistance(nativeReturn,q.returnPoint)
                if real and d<20 then nativeReturn.entity=q.returnPoint.entity end
            end
            q.returnPoint=nativeReturn or q.returnPoint
            local observed=self.recentTurnins and self.recentTurnins[id]
            if q.complete and observed and observed.expires>self:Time() and observed.stamp==self.stamp then
                q.returnPoint=copy(observed.point)
            end
            if q.workPoint and not q.workPoint.entity then
                for _,o in ipairs(q.objectives)do
                    if o.point and o.point.entity then
                        local d,real=self:MapDistance(q.workPoint,o.point)
                        if real and d<20 then q.workPoint.entity=o.point.entity;break end
                    end
                end
            end
            -- No global GetQuestLogRewardXP(id): some clients take no quest ID.
            local xp=self.Safe(api.GetQuestLogRewardXP,id)
            if type(xp)=='number' then q.xp=xp end
            self.quests[#self.quests+1]=q;self.activeIds[id]=true
            self:Remember(q)
        end
    end
    self:ObserveQuestProgress()
    self:RequiredItems()
end
function QF:NPCID()
    local guid=self.Safe(UnitGUID,'npc')
    return guid and tonumber(guid:match('^[^-]+%-%d+%-%d+%-%d+%-%d+%-(%d+)%-'))
end
function QF:RememberNPCTurnins()
    local p=self:PlayerPoint()
    local rows=C_GossipInfo and self.Safe(C_GossipInfo.GetActiveQuests)
    if not valid(p) or type(rows)~='table' then return end
    self.recentTurnins=self.recentTurnins or {}
    for id,row in pairs(self.recentTurnins) do
        if row.expires<=self:Time() then self.recentTurnins[id]=nil end
    end
    for _,row in ipairs(rows) do
        if type(row.questID)=='number' and row.isComplete==true then
            -- An actual dialogue confirms an interaction location, not exact NPC coordinates.
            local point=copy(p);point.approximate=true;point.source='npc-dialogue'
            self.recentTurnins[row.questID]={point=point,stamp=self.stamp,expires=self:Time()+300}
        elseif type(row.questID)=='number' then self.recentTurnins[row.questID]=nil end
    end
end
function QF:RememberNPCOffers()
    local api=C_GossipInfo
    local list=api and self.Safe(api.GetAvailableQuests)
    local count=api and self.Safe(api.GetNumAvailableQuests)
    local p=self:PlayerPoint()
    if type(list)~='table' or not valid(p) then return end
    local present={};local npcID=self:NPCID()
    for _,row in ipairs(list) do
        if type(row.questID)=='number' and row.questID>0 then
            present[row.questID]=true
            local q={id=row.questID,title=row.title,level=row.questLevel,startPoint=copy(p),state='verified',kind='solo',npcID=npcID}
            q.expires=self:Time()+300
            self.memory.negative[q.id]=nil
            self.observedOffers[q.id]=q;self:Remember(q)
        end
    end
    -- Negative evidence requires a complete list and the exact expected NPC.
    -- A nil API result or a nearby unrelated NPC never suppresses the quest.
    if npcID and type(count)=='number' and count==#list then
        for _,q in ipairs(self.discovery or {})do
            local matches=q.npcID==npcID
            for _,id in ipairs(q.npcIDs or {})do if id==npcID then matches=true end end
            if matches and not present[q.id] and not self.activeIds[q.id] then
                self.memory.negative[q.id]={at=self:Time(),untilTime=self:Time()+600,stamp=self.stamp,source='complete-npc-dialogue',npcID=npcID}
                self.observedOffers[q.id]=nil
            end
        end
    end
    self:PruneMemory()
end
function QF:ObserveDetail()
    local id=self.Safe(GetQuestID);local p=self:PlayerPoint()
    if type(id)=='number' and id>0 and valid(p) and not self.activeIds[id] then
        local q={id=id,title=self.Safe(GetTitleText),startPoint=copy(p),state='verified',kind='solo',expires=self:Time()+300}
        local xp=self.Safe(GetRewardXP);if type(xp)=='number' then q.xp=xp end
        self.observedOffers[id]=q;self:Remember(q)
    end
end
function QF:BeginDiscovery()
    local map=self:MapID();local available=self:QuestieAvailableSet() or {}
    local candidates,seen={},{}
    for id,yes in pairs(available) do
        if yes and type(id)=='number' then seen[id]=true end
    end
    for id,q in pairs(self.observedOffers) do
        if q.expires<=self:Time() then self.observedOffers[id]=nil
        elseif q.startPoint.map==map then seen[id]=true end
    end
    local ids={} for id in pairs(seen) do ids[#ids+1]=id end table.sort(ids)
    self.discoveryToken=(self.discoveryToken or 0)+1
    local token=self.discoveryToken;local at=1
    self.discoveryRunning=true
    local function batch()
        if token~=self.discoveryToken then return end
        for _=1,15 do
            local id=ids[at];if not id then break end;at=at+1
            if not self.activeIds[id] and not self:QuestFinished(id) and not self:IsSkipped(id) and not self:OfferSuppressed(id) then
                local observed=self.observedOffers[id]
                local q=copy(observed)
                q.id=id;q.potential=true;q.active=false;q.kind=self:QuestKind(id)
                q.state=observed and 'verified' or 'potential'
                self:Enrich(q)
                -- Questie's internal list is NOT server-confirmed. Strict default:
                -- only fresh NPC observations are executable pickups.
                if valid(q.startPoint) and q.startPoint.map==map then candidates[#candidates+1]=q end
            end
        end
        if at<=#ids and C_Timer and C_Timer.After then C_Timer.After(0,batch)
        else
            self.discovery=candidates;self.discoveryRunning=false
            self.discoveryError=not self:Provider() and 'QuestieDB Forever compatible non détectée' or nil
            self:Plan()
        end
    end
    batch()
end
