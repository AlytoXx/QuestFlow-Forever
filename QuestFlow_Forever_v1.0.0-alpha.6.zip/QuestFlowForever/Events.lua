local _,QF=...
local f=CreateFrame('Frame');local pending=false;local full=false
local function schedule(discover)
    full=full or discover
    if pending then return end
    pending=true
    local function run()
        pending=false;local refresh=full;full=false
        if QF.ready then
            local ok,err=pcall(function() if refresh then QF:Optimise() else QF:Replan() end end)
            if not ok then QF.lastError=tostring(err);QF:Print('Diagnostic : '..tostring(err)) end
        end
    end
    if C_Timer and C_Timer.After then C_Timer.After(.3,run) else run() end
end
for _,event in ipairs({'PLAYER_LOGIN','QUEST_LOG_UPDATE','QUEST_ACCEPTED','QUEST_REMOVED','QUEST_TURNED_IN',
  'PLAYER_LEVEL_UP','ZONE_CHANGED_NEW_AREA','ZONE_CHANGED','GOSSIP_SHOW','QUEST_DETAIL','SKILL_LINES_CHANGED','PLAYER_LOGOUT','MERCHANT_SHOW','MERCHANT_CLOSED','BAG_UPDATE_DELAYED','UPDATE_INVENTORY_DURABILITY','PLAYER_REGEN_DISABLED','TRAINER_SHOW','TRAINER_UPDATE','SPELLS_CHANGED','LEARNED_SPELL_IN_TAB'}) do
    pcall(f.RegisterEvent,f,event)
end
f:SetScript('OnEvent',function(_,event,...)
    if event=='PLAYER_LOGIN' then
        QF:InitSettings();QF.ready=true;QF:CreateUI();QF:InstallItemHints();schedule(true);QF:ShowProfile(true)
        QF:Print('v'..QF.VERSION..' · /qf opt · /qf debug · Ctrl+molette pour la taille.')
        local _,_,_,interface=QF.Safe(GetBuildInfo)
        if interface~=16001 then QF:Print('Interface '..tostring(interface)..' non validée ; utilise /qf debug.') end
    elseif not QF.ready then return
    elseif event=='PLAYER_LOGOUT' then QF:SaveSession();QF:PruneMemory()
    elseif event=='TRAINER_SHOW' or event=='TRAINER_UPDATE' then
        local a=QF.route and QF.route[1]
        if a and a.profileMaster then local d,real=QF:MapDistance(QF:PlayerPoint(),a.point);if real and d<20 then QF.masterVisitMute=QF.masterVisitMute or {};QF.masterVisitMute[a.profileMaster]=GetTime()+1800 end end
        QF:ObserveTrainer();schedule(false)
    elseif event=='SPELLS_CHANGED' or event=='LEARNED_SPELL_IN_TAB' then schedule(false)
    elseif event=='MERCHANT_SHOW' then QF:ObserveMerchant();schedule(false)
    elseif event=='MERCHANT_CLOSED' or event=='BAG_UPDATE_DELAYED' or event=='UPDATE_INVENTORY_DURABILITY' then QF:RefreshNeeds();schedule(false)
    elseif event=='PLAYER_REGEN_DISABLED' then if QF.travelSample then QF.travelSample.bad=true end
    elseif event=='GOSSIP_SHOW' then QF:RememberNPCTurnins();QF:RememberNPCOffers();schedule(true)
    elseif event=='QUEST_DETAIL' then QF:ObserveDetail();schedule(true)
    elseif event=='ZONE_CHANGED_NEW_AREA' or event=='ZONE_CHANGED' then
        -- A named subzone boundary does not invalidate an objective on this map.
        if QF.routeMap==QF:MapID() then schedule(true);return end
        QF.route={};QF.currentId=nil;QF.lastSwitchAt=-999
        QF.solveToken=(QF.solveToken or 0)+1;QF.discoveryToken=(QF.discoveryToken or 0)+1
        QF.discovery={};QF.visitedPassages={};QF.stall={};schedule(true)
    elseif event=='QUEST_ACCEPTED' or event=='QUEST_TURNED_IN' or event=='QUEST_REMOVED' then
        -- Plan validates the current action; unrelated journal events must not
        -- disable its switch cooldown.
        local a,b=...;local id=event=='QUEST_ACCEPTED' and (b or a) or a
        if type(id)=='number' then QF:RecordHistory(event,id) end
        QF:InvalidateOffers();QF:RememberNPCOffers();schedule(true)
    elseif event=='QUEST_LOG_UPDATE' then schedule(false)
    else
        if event=='PLAYER_LEVEL_UP' then QF:InvalidateOffers() end
        schedule(true)
    end
end)
local elapsed=0
f:SetScript('OnUpdate',function(_,dt)
    elapsed=elapsed+dt
    if elapsed<5 or not QF.ready then return end
    local tick=elapsed;elapsed=0
    QF:TickSession(tick);QF:TickLearning(tick);QF:TickTravel(tick);QF:ObserveStall(tick)
    local a=QF.route and QF.route[1]
    if a and a.kind=='passage' and a.originalAction then
        local nav=QF:NavigationStep(a.originalAction)
        if nav==a.originalAction then schedule(false) end
    end
    QF:UpdateUI()
    if not QF.db.autoRoute then return end
    local p=QF:PlayerPoint();local old=QF.lastAutoPoint
    local nearby=QF:NearbyTurnin(QF.ranked,p)
    local current=a and (a.originalAction or a)
    if nearby and (not current or current.key~=nearby.key) then schedule(false);return end
    local d,real=QF:MapDistance(old,p)
    if p and (not old or old.map~=p.map or (d and d>(real and 35 or .7))) then
        QF.lastAutoPoint=p
        schedule(GetTime()-(QF.lastDiscoverAt or -999)>30)
    end
end)
SLASH_QUESTFLOWFOREVER1='/qf';SLASH_QUESTFLOWFOREVER2='/questflow'
SlashCmdList.QUESTFLOWFOREVER=function(msg)
    if not QF.ready then return end
    msg=(msg or ''):lower():match('^%s*(.-)%s*$')
    local minutes=msg:match('^session%s+(%d+)$')
    if minutes then QF:StartSession(tonumber(minutes))
    elseif msg=='pause' then QF.sessionPaused=not QF.sessionPaused;QF:UpdateUI()
    elseif msg=='passage' then QF:MarkPassage()
    elseif msg=='profil' then QF:ShowProfile(false)
    elseif msg=='tri' then QF:ShowCleanup()
    elseif msg=='grotte' or msg=='montagne' or msg=='detour' then QF:MarkTerrain(({grotte='cave',montagne='mountain',detour='detour'})[msg])
    elseif msg:match('^sort %d+$') then local id=tonumber(msg:match('%d+'));QF.db.prioritySpells[id]=not QF.db.prioritySpells[id];QF:Print('Priorité personnalisée '..id..' : '..tostring(QF.db.prioritySpells[id]))
    elseif msg=='objets' then QF:PrintItems()
    elseif msg=='export' then QF:ShowExport(true)
    elseif msg=='opt' then QF:Optimise()
    elseif msg=='debug' then QF:Diagnostic()
    elseif msg=='options' then QF:ToggleSettings()
    elseif msg=='changer' then QF:ToggleSkipMenu()
    elseif msg=='reset' then QF:ClearSkips()
    elseif msg=='sens' then QF.db.arrowInvert=not QF.db.arrowInvert
    elseif msg=='map' then QF:Waypoint()
    elseif msg=='aide' then QF:Print('/qf opt, debug, options, changer, reset, sens, map, objets, passage, export, pause ; /qf session 30 (0 = libre).')
    else QF.db.visible=not QF.frame:IsShown();QF.frame:SetShown(QF.db.visible) end
end
