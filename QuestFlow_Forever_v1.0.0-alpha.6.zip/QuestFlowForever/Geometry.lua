local ADDON,QF=...
-- Coordinate conversions shared by the arrow and the route engine.
-- WoW returns map coordinates as north=top, east=right. Never assume world X/Y
-- have the same orientation as UI map axes.
local sqrt=math.sqrt
local function coordinates(map,x,y)
    if not(map and type(x)=='number' and type(y)=='number') then return nil end
    if not(C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return nil end
    local ok,continent,vec=pcall(C_Map.GetWorldPosFromMapPos,map,CreateVector2D(x/100,y/100))
    if not(ok and continent and vec) then return nil end
    local wx,wy
    if type(vec.GetXY)=='function' then wx,wy=vec:GetXY() else wx,wy=vec.x,vec.y end
    if type(wx)=='number' and type(wy)=='number' then return continent,wx,wy end
end
QF.WorldPoint=coordinates
function QF:MapDistance(a,b)
    if not(a and b and a.map and b.map and a.x and a.y and b.x and b.y) then return nil,false end
    local c1,x1,y1=coordinates(a.map,a.x,a.y)
    local c2,x2,y2=coordinates(b.map,b.x,b.y)
    if c1 and c2 and c1==c2 then
        return sqrt((x2-x1)^2+(y2-y1)^2),true -- yards, matching GetUnitSpeed()
    end
    -- No unverified meters. Return a normalized SAME MAP proxy for ordering only.
    if a.map~=b.map then return nil,false end
    return sqrt((a.x-b.x)^2+(a.y-b.y)^2),false
end
function QF:PlayerPoint()
    local x,y=self:PlayerPosition()
    local map=self:MapID()
    if x and y and map then return {x=x,y=y,map=map} end
end
-- Only public finite numbers may enter addon arithmetic. pcall around the API
-- alone does not protect later comparisons with a secret return value.
function QF.PublicNumber(value)
    local ok,result=pcall(function()
        if issecretvalue and issecretvalue(value) then return nil end
        if type(value)~='number' then return nil end
        if value~=value or value==math.huge or value==-math.huge then return nil end
        return value
    end)
    if ok then return result end
end
function QF:CurrentSpeed()
    if type(GetUnitSpeed)~='function' then return nil end
    local ok,value=pcall(GetUnitSpeed,'player')
    if ok then return self.PublicNumber(value) end
end
function QF:GroundSpeed()
    local speed=self:CurrentSpeed()
    if speed and speed>1 then return speed end
    return 7 -- Estimate only; never use this fallback to infer player movement.
end
function QF:TravelEstimate(a,b)
    local d,measured=self:MapDistance(a,b)
    if not d then return 300,nil,false end -- unknown / cross map, conservative penalty
    if measured then
        -- Air-line travel is optimistic; +20% makes a modest detour allowance.
        return math.max(0,d*1.20/self:GroundSpeed()),d,true
    end
    -- Map-percent fallback is a RANKING heuristic only, never displayed as meters.
    return math.max(0,d*8),nil,false
end
function QF:HeadingOnMap(px,py,tx,ty)
    if not(px and py and tx and ty) then return nil end
    local dx=tx-px
    local north=py-ty
    if dx==0 and north==0 then return 0 end
    -- 0 is north, positive is counterclockwise (west); east is -pi/2.
    if math.atan2 then return math.atan2(-dx,north) end
    if north>0 then return math.atan(-dx/north) end
    if north<0 then return math.atan(-dx/north)+(dx>=0 and -math.pi or math.pi) end
    return dx>=0 and -math.pi/2 or math.pi/2
end
