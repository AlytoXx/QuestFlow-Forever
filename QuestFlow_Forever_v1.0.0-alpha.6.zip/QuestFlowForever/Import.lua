local _,QF=...
function QF:ImportDataPack()
    local p=self.DataPack
    if type(p)~='table' then return end
    if p.schema~=1 or p.stamp~=self.stamp or type(p.source)~='string' or #p.source<3 then
        self.importStatus='Pack refusé : version, provenance ou client incompatible';return
    end
    if type(p.passages)~='table' or type(p.edges)~='table' or #p.passages>100 or #p.edges>100 then
        self.importStatus='Pack refusé : structure ou taille';return
    end
    -- Validate all records before mutating persistent memory.
    for _,r in ipairs(p.passages)do
        if type(r.action)~='string' or not r.action:match('^%d+:[%w]+$') or not self.ValidPoint(r.point) then
            self.importStatus='Pack refusé : passage invalide';return
        end
    end
    for _,r in ipairs(p.edges)do
        if not self.ValidPoint(r.from) or not self.ValidPoint(r.to) or r.from.map==r.to.map
          or type(r.seconds)~='number' or r.seconds<=0 or r.seconds>600 or type(r.samples)~='number' or r.samples<2 or r.samples>7 then
            self.importStatus='Pack refusé : transition invalide';return
        end
    end
    local token=p.stamp..':'..p.source..':'..tostring(p.revision)
    if self.memory.importToken==token then return end
    for _,r in ipairs(p.passages)do
        self.memory.passages[r.action]={point=self.Copy(r.point),stamp=self.stamp,at=self:Time(),source=p.source,imported=true}
    end
    for _,r in ipairs(p.edges)do
        local key=self:PointKey(r.from)..'>'..self:PointKey(r.to)
        self.memory.edges[key]={from=self.Copy(r.from),to=self.Copy(r.to),seconds=r.seconds,count=r.samples,
          samples={},stamp=self.stamp,at=self:Time(),source=p.source,imported=true,key=key}
        for _=1,r.samples do table.insert(self.memory.edges[key].samples,r.seconds) end
    end
    self.memory.importToken=token;self.importStatus='Pack local chargé : '..p.source
    self:PruneMemory()
end
