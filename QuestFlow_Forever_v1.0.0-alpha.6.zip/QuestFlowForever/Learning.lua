local _,QF=...
function QF:TickLearning(dt)
    local invalid=self.Safe(UnitIsAFK,'player') or self.Safe(UnitIsDeadOrGhost,'player') or self.sessionPaused
    local busy=self.Safe(UnitAffectingCombat,'player') or (self:CurrentSpeed() or 0)>1
    if invalid or not busy then self.learningEpoch=(self.learningEpoch or 0)+1
    else self.learningActive=(self.learningActive or 0)+math.min(dt,10) end
end
function QF:ObserveQuestProgress()
    self._objectiveSample=self._objectiveSample or {}
    local now=GetTime();local nextSample={};local gains={};local progressed={}
    for _,q in ipairs(self.quests or {})do
        local done=0;local entities={}
        for _,o in ipairs(q.objectives or {})do
            done=done+(tonumber(o.current) or (o.finished and (o.needed or 1) or 0))
            if o.type=='monster' and type(o.objectID)=='number' and type(o.current)=='number' then entities[o.objectID]=o.current end
        end
        local prev=self._objectiveSample[q.id]
        if prev and done>prev.done then
            local dt=now-prev.at;local active=(self.learningActive or 0)-(prev.active or 0)
            if prev.epoch==(self.learningEpoch or 0) and dt>=8 and dt<=180 and active>=dt*.8 and done-prev.done<=6 then
                gains[#gains+1]=active/(done-prev.done)
            end
            for entity,value in pairs(entities)do
                local old=prev.entities and prev.entities[entity]
                if old and value>old then
                    progressed[entity]=progressed[entity] or {};progressed[entity][q.id]=value-old
                end
            end
        end
        if not prev or prev.done~=done then
            nextSample[q.id]={done=done,at=now,active=self.learningActive or 0,epoch=self.learningEpoch or 0,entities=entities}
        else nextSample[q.id]=prev end
    end
    self._objectiveSample=nextSample
    if #gains>0 then
        table.sort(gains);local value=gains[math.ceil(#gains/2)]
        if value>=8 and value<=90 then self.db.secondsPerObjective=math.max(12,math.min(65,self.db.secondsPerObjective*.9+value*.1)) end
    end
    if self.memory then
        self.memory.shared=self.memory.shared or {}
        for entity,quests in pairs(progressed)do
            local ids={};for id in pairs(quests)do ids[#ids+1]=id end;table.sort(ids)
            for i=1,#ids do for j=i+1,#ids do
                if quests[ids[i]]==quests[ids[j]] then
                    local key=entity..':'..ids[i]..':'..ids[j]
                    local r=self.memory.shared[key]
                    if not r or r.stamp~=self.stamp then r={count=0,stamp=self.stamp} end
                    r.count=math.min(10,r.count+1);r.at=self:Time();self.memory.shared[key]=r
                end
            end end
        end
    end
end
function QF:ShareProof(entity,id,other)
    local a,b=math.min(id,other),math.max(id,other)
    local r=self.memory.shared and self.memory.shared[entity..':'..a..':'..b]
    return r and r.count>=3 and r.stamp==self.stamp and self:Time()-r.at<30*86400
end
function QF:AnnotateSharedWork(actions)
    -- Pair only: every overlap has its own empirical proof. Never transitively
    -- assume that a third quest shares credit because two other pairs do.
    local paired={}
    for i,a in ipairs(actions)do
        if a.kind=='work' and a.entity and a.quest.active and not paired[a.key] then
            for j=i+1,#actions do
                local b=actions[j]
                if b.kind=='work' and b.entity==a.entity and b.id~=a.id and b.quest.active
                  and not paired[b.key] and b.map==a.map and self:ShareProof(a.entity,a.id,b.id) then
                    local key=a.entity..':'..math.min(a.id,b.id)..':'..math.max(a.id,b.id)
                    a.shareKey=key;b.shareKey=key;paired[a.key]=true;paired[b.key]=true
                    a.unitSeconds=math.max(0,(a.seconds-6)/math.max(1,a.remaining))
                    b.unitSeconds=math.max(0,(b.seconds-6)/math.max(1,b.remaining));break
                end
            end
        end
    end
end
