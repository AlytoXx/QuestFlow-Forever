local _,Q=...
-- Snapshot the same approaches used by the arrow, without advancing its waypoint.
function Q:LoopAccess(actions)
    local byKey={}
    for _,a in ipairs(actions) do
        local p=self:PassageFor(a)
        local path=self:Approach(a.point)
        local points={}
        if p then points[#points+1]=p end
        if path then for _,v in ipairs(path.points) do points[#points+1]=v end end
        local mark=self.db.terrain[a.key]
        local text=(a.objectiveText or ''):lower()
        if text=='' and a.quest and a.quest.objectives and #a.quest.objectives==1 then
            text=(a.quest.objectives[1].text or ''):lower()
        end
        local uncertain=(mark and mark.stamp==self.stamp) or text:find('dans la grotte',1,true)
          or text:find('dans la caverne',1,true) or text:find('au sommet de la montagne',1,true)
        byKey[a.key]={points=points,penalty=#points==0 and uncertain and 60 or 0}
    end
    return byKey
end
function Q:LoopTravel(start,finish,action,previous,access)
    local src=previous and access[previous.key];local dst=access[action.key]
    local out=src and src.points or {};local into=dst and dst.points or {}
    local from,seconds=start,0
    local function leg(p)
        local t=self:TravelEstimate(from,p)
        if not t then return false end
        seconds=seconds+t;from=p;return true
    end
    -- If both objectives use the same entrance, stop at their last common
    -- waypoint instead of walking out to the village and back in.
    local common=0
    while out[common+1] and into[common+1] and self:PointKey(out[common+1])==self:PointKey(into[common+1]) do common=common+1 end
    for i=#out,math.max(common,1),-1 do if not leg(out[i]) then return nil end end
    local first=common+1
    if not previous and self.visitedPassages[action.key] and self:PassageFor(action) then first=2 end
    for i=first,#into do if not leg(into[i]) then return nil end end
    if not leg(finish) then return nil end
    return seconds+(dst and dst.penalty or 0)
end
local function rate(s)
    return (s.xp+s.utility+.25*math.max(0,s.credit))/math.max(1,s.seconds)
end
function Q:ComparePickups(winner,actions,start,opt)
    local O=self.Optimizer
    local checks=0
    local function checkpoint()
        checks=checks+1
        if checks%128==0 and opt.yieldFn then opt.yieldFn() end
    end
    local function replay(seq)
        if opt.forceFirst and (not seq[1] or seq[1].key~=opt.forceFirst) then return end
        local s={used={},seq={},where=start,seconds=0,travel=0,xp=0,utility=0,slots=opt.slots,credit=0,tie=''}
        for _,a in ipairs(seq) do
            checkpoint()
            if not O.Eligible(a,s,opt.capacity) then return end
            s=O.Step(a,s,opt.travel)
            if not s then return end
            if opt.budget and s.seconds>opt.budget+(a.kind=='turnin' and math.min(120,opt.budget*.1) or 0) then return end
        end
        return s
    end
    local bundles,ids={},{}
    for _,a in ipairs(actions) do
        if a.quest and a.quest.potential and not a.blocked then
            if not bundles[a.id] then bundles[a.id]={};ids[#ids+1]=a.id end
            table.insert(bundles[a.id],a)
        end
    end
    table.sort(ids)
    local log={}
    for _,id in ipairs(ids) do
        local base,has={},false
        for _,a in ipairs(winner.seq) do
            if a.id==id then has=true else base[#base+1]=a end
        end
        local without=replay(base)
        local with=has and replay(winner.seq) or nil
        if without and not has then
            local seq={};for i,a in ipairs(base)do seq[i]=a end
            -- Insert each stage where it adds the least travel, respecting the
            -- order of this quest and preserving the existing loop's order.
            local after=0
            for _,a in ipairs(bundles[id]) do
                local best,index
                for i=after+1,#seq+1 do
                    checkpoint()
                    local prev,nextA=seq[i-1],seq[i]
                    local from=prev and prev.point or start
                    local inbound=opt.travel(from,a.point,a,prev)
                    local onward,original=0,0
                    if nextA then
                        onward=opt.travel(a.point,nextA.point,nextA,a)
                        original=opt.travel(from,nextA.point,nextA,prev)
                    end
                    if inbound and onward and original then
                        local added=inbound+onward-original
                        if not best or added<best then best,index=added,i end
                    end
                end
                if not index then seq=nil;break end
                table.insert(seq,index,a);after=index
            end
            if seq and #seq<=opt.horizon and bundles[id][#bundles[id]].kind=='turnin' then with=replay(seq) end
        end
        if without and with then
            local keep=#without.seq==0 or rate(with)>=rate(without)*(has and .98 or 1.02)
            winner=keep and with or without
            log[id]={included=keep,extraSeconds=with.seconds-without.seconds,extraXP=with.xp-without.xp}
        end
    end
    return winner,log
end
