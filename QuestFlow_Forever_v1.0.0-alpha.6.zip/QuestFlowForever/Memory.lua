local _,QF=...
local function copy(t) local n={} for k,v in pairs(t or {}) do n[k]=v end return n end
QF.Copy=copy
function QF:DataStamp()
    local _,build,_,interface=self.Safe(GetBuildInfo)
    local lib=self:Provider()
    local meta=C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    return tostring(interface)..':'..tostring(build)..':'..tostring(self.Safe(meta,'QuestieDB','Version') or (lib and lib.contractVersion))
end
function QF:InitMemory()
    self.db.memory=self.db.memory or {}
    local m=self.db.memory
    for _,key in ipairs({'negative','corrections','passages','edges','services','timings','history','shared'}) do
        if type(m[key])~='table' then m[key]={} end
    end
    self.memory=m;self.stamp=self:DataStamp()
    if m.stamp~=self.stamp then
        -- Keep observations/history but invalidate live navigation assumptions.
        m.negative={};m.corrections={};m.stamp=self.stamp
    end
    m.schema=2
    self.stall={};self.visitedPassages={}
    self:PruneMemory()
    self:ImportDataPack()
end
function QF:PruneMemory()
    local m=self.memory;if not m then return end
    local now=self:Time()
    for _,key in ipairs({'negative','corrections'}) do
        for id,v in pairs(m[key]) do if not v.untilTime or v.untilTime<=now then m[key][id]=nil end end
    end
    local limits={edges=160,timings=160,services=80,passages=100,history=100,shared=200,negative=200,corrections=200}
    for key,limit in pairs(limits) do
        local keys={};for id,v in pairs(m[key]) do keys[#keys+1]={id=id,at=v.at or 0} end
        table.sort(keys,function(a,b)return a.at>b.at end)
        for i=limit+1,#keys do m[key][keys[i].id]=nil end
    end
end
function QF:RecordHistory(kind,id)
    local h=self.memory.history
    h[#h+1]={kind=kind,id=id,at=self:Time(),point=self:PlayerPoint(),stamp=self.stamp}
    while #h>100 do table.remove(h,1) end
end
function QF:OfferSuppressed(id)
    local n=self.memory and self.memory.negative[id]
    return n and n.stamp==self.stamp and n.untilTime>self:Time()
end
function QF:InvalidateOffers()
    self.observedOffers={}
    self.memory.negative={}
end
function QF:PointKey(p)
    if not self.ValidPoint(p) then return nil end
    return p.map..':'..math.floor(p.x*2+.5)..':'..math.floor(p.y*2+.5)
end
function QF:ActionBlocked(a)
    local c=self.memory and self.memory.corrections[a.key]
    return c and c.untilTime>self:Time() and c.stamp==self.stamp
        and c.pointKey==self:PointKey(a.point)
end
function QF:Feedback(reason)
    local a=self.route and self.route[1];if not a then return end
    self.stall={};self.stallHint=nil
    if a.kind=='service' and reason~='continue' then self.servicedUntil=GetTime()+1800;self:Replan();return end
    if a.kind=='trainer' and reason~='continue' then self.trainerMute=GetTime()+1800;self:Replan();return end
    if reason=='continue' then self.stallMute=GetTime()+600;self:UpdateUI();return end
    if reason=='wrong' or reason=='passage' or reason=='npc' then
        local target=a.kind=='passage' and a.originalAction or a
        self.memory.corrections[target.key]={reason=reason,at=self:Time(),untilTime=self:Time()+1800,
          pointKey=self:PointKey(target.point),stamp=self.stamp}
        if reason=='npc' then self.memory.negative[a.id]={at=self:Time(),untilTime=self:Time()+900,stamp=self.stamp,source='user'} end
        if a.kind=='passage' and a.originalAction then
            self.memory.passages[a.originalAction.key]=nil
            if a.edgeKey then
                self.memory.corrections['edge:'..a.edgeKey]={at=self:Time(),untilTime=self:Time()+1800,
                  pointKey=self:PointKey(a.point),stamp=self.stamp,reason=reason}
            end
        end
        self:RecordHistory(reason,a.id);self.route={};self:Replan()
    else
        if reason=='hard' then
            local old=self.memory.timings['hard:'..a.id] or {count=0}
            old.count=math.min(5,old.count+1);old.at=self:Time();old.stamp=self.stamp
            self.memory.timings['hard:'..a.id]=old
        end
        self:Skip(a.id,reason)
    end
end
function QF:TimeMultiplier(id)
    local h=self.memory and self.memory.timings['hard:'..id]
    if not h or h.stamp~=self.stamp or self:Time()-h.at>86400 then return 1 end
    return 1+math.min(.75,h.count*.15)
end
function QF:ObserveStall(dt)
    if not self.db.stallDetection then return end
    local a=self.route and self.route[1]
    if not a or a.kind~='work' then self.stall={};self.stallHint=nil;return end
    local current=0
    for _,o in ipairs(a.quest.objectives or {}) do current=current+(o.current or (o.finished and 1 or 0)) end
    local p=self:PlayerPoint();local d,real=self:MapDistance(p,a.point)
    local near=d and d<(real and 130 or 2.5)
    local busy=self.Safe(UnitAffectingCombat,'player')==true or (self:CurrentSpeed() or 0)>1
    local inactive=self.Safe(UnitIsAFK,'player') or self.Safe(UnitIsDeadOrGhost,'player') or self.Safe(UnitOnTaxi,'player')
    local s=self.stall
    if s.key~=a.key or s.progress~=current then
        self.stall={key=a.key,progress=current,seconds=0};self.stallHint=nil;return
    end
    if near and busy and not inactive and not self.sessionPaused then s.seconds=s.seconds+math.min(dt,10) end
    if s.seconds>=180 and GetTime()>(self.stallMute or 0) then
        self.stallHint='Pas de progression observée : Continuer ou Changer ?'
    end
end
function QF:MemoryExport()
    local lines={'QF-OBSERVATIONS\t2','build\t'..self.stamp,'generated\t'..self:Time()}
    local function clean(v)return tostring(v or ''):gsub('[\t\r\n]',' ')end
    local ids={};for id in pairs(self.db.observed)do ids[#ids+1]=id end;table.sort(ids)
    for _,id in ipairs(ids) do
        local q=self.db.observed[id]
        lines[#lines+1]=table.concat({'quest',id,clean(q.title),clean(q.state),q.seenAt or 0,clean(q.stamp)},'\t')
    end
    for key,row in pairs(self.memory.passages)do
        lines[#lines+1]=table.concat({'passage',key,row.point.map,row.point.x,row.point.y,clean(row.stamp)},'\t')
    end
    for _,id in ipairs(ids)do
        local q=self.db.observed[id]
        for _,role in ipairs({'workPoint','startPoint','lastObservedPosition'})do
            local p=q[role]
            if self.ValidPoint(p)then lines[#lines+1]=table.concat({'position',id,role,p.map,p.x,p.y,clean(q.stamp)},'\t') end
        end
        for index,o in ipairs(q.objectives or {})do
            lines[#lines+1]=table.concat({'objective',id,index,clean(o.type),clean(o.objectID),clean(o.current),clean(o.needed),tostring(o.finished==true)},'\t')
        end
    end
    for _,e in pairs(self.memory.edges)do
        lines[#lines+1]=table.concat({'edge',e.from.map,e.from.x,e.from.y,e.to.map,e.to.x,e.to.y,e.seconds,e.count,e.at,clean(e.stamp)},'\t')
    end
    for key,t in pairs(self.memory.timings)do
        if t.samples then lines[#lines+1]=table.concat({'timing',key,table.concat(t.samples,','),t.at,clean(t.stamp)},'\t') end
    end
    self.db.lastExport=table.concat(lines,'\n');return self.db.lastExport
end
