local ADDON,QF=...
-- 0.4: Map-space bearing and world-space distance are deliberately independent.
-- Texture rotates COUNTERCLOCKWISE for positive angles (WoW SetRotation).
local function wrap(a)return (a+math.pi)%(2*math.pi)-math.pi end
function QF:CalculateGuidance(q)
    if not q then return nil,'Aucune étape' end
    local p,note=self:AccessTarget(q);local here=self:PlayerPoint()
    if not p or not here or p.map~=here.map then return nil,note or 'Position indisponible' end
    local c,n,w=self.WorldPoint(here.map,here.x,here.y)
    local c2,n2,w2=self.WorldPoint(p.map,p.x,p.y)
    if not c or c~=c2 then return nil,note or 'Direction inconnue' end
    local dn,dw=n2-n,w2-w;local yards=math.sqrt(dn*dn+dw*dw)
    if yards~=yards or yards==math.huge then return nil,'Direction inconnue' end
    local bearing=self:HeadingOnMap(0,0,-dw,-dn)
    local facing=self.PublicNumber(self.Safe(GetPlayerFacing))
    return {distance=yards*.9144,bearing=bearing,arrived=yards<12,verified=true,
      rotation=type(facing)=='number' and facing==facing and wrap(bearing-facing) or nil,note=note,point=p}
end
function QF:CreateNavigation()
    if self.navFrame then return end
    local f=CreateFrame('Frame','QuestFlowForeverArrow',UIParent,'BackdropTemplate')
    f:SetSize(160,54)
    local p=self.db.arrowPoint
    if type(p)=='table' and type(p[4])=='number' then
        f:SetPoint(p[1] or 'CENTER',UIParent,p[3] or 'CENTER',p[4],p[5])
    else f:SetPoint('CENTER',UIParent,'CENTER',380,210) end
    if f.SetBackdrop then
        f:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=10,insets={left=2,right=2,top=2,bottom=2}})
        f:SetBackdropColor(.035,.055,.075,.93)
        f:SetBackdropBorderColor(.26,.56,.51,.65)
    end
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag('LeftButton')
    f:SetScript('OnDragStart',function(self) self:StartMoving() end)
    f:SetScript('OnDragStop',function(self)
        self:StopMovingOrSizing();local a,_,c,x,y=self:GetPoint(1)
        QF.db.arrowPoint={a,'UIParent',c,x,y}
    end)
    f.icon=f:CreateTexture(nil,'ARTWORK');f.icon:SetSize(30,30)
    f.icon:SetPoint('LEFT',f,'LEFT',8,0)
    f.icon:SetTexture('Interface\\AddOns\\QuestFlowForever\\Arrow.tga')
    f.icon:SetVertexColor(.31,.94,.71)
    local function label(y,font)
        local t=f:CreateFontString(nil,'OVERLAY',font)
        t:SetPoint('TOPLEFT',f,'TOPLEFT',42,y)
        t:SetWidth(114);if t.SetWordWrap then t:SetWordWrap(false) end;t:SetJustifyH('LEFT');return t
    end
    f.heading=label(-5,'GameFontNormalSmall')
    f.target=label(-21,'GameFontNormalSmall')
    f.distance=label(-37,'GameFontNormalSmall')
    f.distance:SetTextColor(.38,.98,.79)
    f:SetScript('OnUpdate',function(self,elapsed)
        self.tick=(self.tick or 0)+elapsed
        if self.tick<.06 then return end
        local dt=self.tick;self.tick=0
        QF:UpdateArrowRealtime(dt)
    end)
    self.navFrame=f
    self:RefreshNavigation()
end
function QF:SyncNavigation() if self.navFrame then self:RefreshNavigation() end end
function QF:RefreshNavigation()
    local f=self.navFrame
    if not f then return end
    local q=self.route and self.route[1]
    if not self.db.arrowEnabled or not q then f:Hide();return end
    f:Show();f.target:SetText(q.title);self:UpdateArrowRealtime(0)
end
function QF:UpdateArrowRealtime(dt)
    local f=self.navFrame;if not f or not f:IsShown() then return end
    local a=self.route and self.route[1];local guide,note=self:CalculateGuidance(a)
    if not guide then
        f.icon:Hide();f.heading:SetText(note or 'Accès inconnu');f.distance:SetText('—');self.arrowState=nil;return
    end
    local key=a.key..':'..self:PointKey(guide.point)
    local state=self.arrowState
    if not state or state.key~=key then state={key=key};self.arrowState=state end
    -- Two different thresholds avoid blinking/spinning while standing on a target.
    state.near=guide.distance<(state.near and 16 or 11)
    f.heading:SetText(guide.note or (a.kind=='trainer' and 'Maître de classe' or 'Direction'))
    f.distance:SetText(state.near and 'Sur place' or (math.floor(guide.distance+.5)..' m directs'))
    if state.near or not guide.rotation then f.icon:Hide();state.angle=nil;return end
    local target=self.db.arrowInvert and -guide.rotation or guide.rotation
    if not state.angle then state.angle=target else
        local diff=wrap(target-state.angle)
        if math.abs(diff)>.018 then state.angle=wrap(state.angle+diff*(1-math.exp(-math.min(dt or .06,.3)*16))) end
    end
    f.icon:Show();f.icon:SetRotation(state.angle)
end
