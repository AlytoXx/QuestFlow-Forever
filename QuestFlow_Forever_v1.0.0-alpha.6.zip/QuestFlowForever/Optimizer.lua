local _,QF=...
-- Pure Lua action-graph solver. No WoW APIs; fixtures execute this exact file.
local O={};QF.Optimizer=O
local function copy(t) local n={} for k,v in pairs(t) do n[k]=v end return n end
local function append(t,v) local n={} for i,x in ipairs(t) do n[i]=x end n[#n+1]=v return n end
function O.Eligible(a,s,capacity)
    if s.used[a.key] or a.blocked then return false end
    if a.kind=='pickup' and (not capacity or s.slots>=capacity) then return false end
    for _,key in ipairs(a.requires or {}) do if not s.used[key] then return false end end
    return true
end
function O.Step(a,s,travel)
    local dt=travel(s.where,a.point,a,s.seq[#s.seq])
    if not dt then return nil end
    local work=a.seconds;local shared=copy(s.shared or {})
    if a.shareKey and a.unitSeconds and a.remaining then
        local prior=shared[a.shareKey] or 0
        work=math.max(0,work-math.min(prior,a.remaining)*a.unitSeconds)
        shared[a.shareKey]=math.max(prior,a.remaining)
    end
    local n={shared=shared,used=copy(s.used),seq=append(s.seq,a),where=a.point,
      seconds=s.seconds+dt+work,travel=s.travel+dt,
      xp=s.xp+(a.xp or 0),utility=s.utility+(a.utility or 0),slots=s.slots,
      credit=s.credit+(a.credit or 0),tie=(s.tie or '')..'/'..a.key}
    n.used[a.key]=true
    if a.kind=='pickup' then n.slots=n.slots+1 elseif a.kind=='turnin' then n.slots=n.slots-1 end
    n.score=(n.xp+n.utility+n.credit)/math.max(1,n.seconds)
    return n
end
function O.Solve(actions,start,options)
    local opt=options or {}; local width=opt.width or 12
    local initial={used={},seq={},where=start,seconds=0,travel=0,xp=0,utility=0,credit=0,slots=opt.slots or 0,tie=''}
    local beam={initial};local best;local expansions=0;local frontier={}
    local horizon=math.min(#actions,opt.horizon or 90)
    for depth=1,horizon do
        local expanded={}
        for _,s in ipairs(beam) do
            local advanced=false
            for _,a in ipairs(actions) do
                if (depth~=1 or not opt.forceFirst or a.key==opt.forceFirst) and O.Eligible(a,s,opt.capacity) then
                    local n=O.Step(a,s,opt.travel)
                    if n and (not opt.budget or n.seconds<=opt.budget or
                      (a.kind=='turnin' and n.seconds<=opt.budget+math.min(120,opt.budget*.1))) then
                        if a.kind=='pickup' and opt.capacity then
                            -- Occupying scarce remaining slots has a small internal
                            -- cost; no slots are permanently reserved.
                            n.score=n.score/(1+math.max(0,n.slots/opt.capacity-.8)*.3)
                        end
                        advanced=true;expanded[#expanded+1]=n
                    end
                end
                expansions=expansions+1
                if opt.yieldFn and expansions%128==0 then opt.yieldFn() end
            end
            if not advanced and #s.seq>0 then frontier[#frontier+1]=s end
        end
        table.sort(expanded,function(a,b)
            if math.abs(a.score-b.score)<.0000001 then return a.tie<b.tie end
            return a.score>b.score
        end)
        beam={}
        for i=1,math.min(width,#expanded) do beam[i]=expanded[i] end
        if #beam==0 then break end
        -- Preserve complete-loop choices at several horizons for diagnostics.
        if depth==6 or depth==18 or depth==horizon then
            if beam[1] then frontier[#frontier+1]=beam[1] end
        end
    end
    for _,s in ipairs(beam) do frontier[#frontier+1]=s end
    -- Compare reward/time at several horizons. Prefer a longer coherent route
    -- only when it remains within 8 percent of the best measured model ratio.
    local highest=-1
    for _,s in ipairs(frontier) do
        s.finalScore=(s.xp+s.utility+(opt.budget and math.max(0,s.credit)*.25 or 0))/math.max(1,s.seconds)
        if s.finalScore>highest then highest=s.finalScore end
    end
    for _,s in ipairs(frontier) do
        if s.finalScore>=highest*.92 and (not best or #s.seq>#best.seq or
           (#s.seq==#best.seq and s.finalScore>best.finalScore)) then best=s end
    end
    if best then best.expansions=expansions end
    return best or initial
end
function O.KeepCurrent(best,current,now,lastSwitch,nearFinish)
    if not current or #current.seq==0 then return false end
    if not best or #best.seq==0 then return true end
    local threshold=nearFinish and 1.7 or 1.18
    local a=(best.xp+best.utility+best.credit)/math.max(1,best.seconds)
    local b=(current.xp+current.utility+current.credit)/math.max(1,current.seconds)
    return now-lastSwitch<30 or a<b*threshold
end
