local ADDON,QF=...
-- Player skill lines, never inferred from a quest title.
local aliases={
 ['alchemy']=171,['alchimie']=171, ['blacksmithing']=164,['forge']=164,
 ['enchanting']=333,['enchantement']=333,['engineering']=202,['ingenierie']=202,
 ['herbalism']=182,['herboristerie']=182,['inscription']=773,
 ['jewelcrafting']=755,['joaillerie']=755,['leatherworking']=165,['travail du cuir']=165,
 ['mining']=186,['minage']=186,['skin ning']=393,['skinning']=393,['depecage']=393,
 ['tailoring']=197,['couture']=197,['first aid']=129,['secourisme']=129,
 ['fishing']=356,['peche']=356,['cooking']=185,['cuisine']=185,
}
local function normalize(s)
    if type(s)~='string' then return '' end
    s=s:lower()
    s=s:gsub('é','e'):gsub('è','e'):gsub('ê','e'):gsub('à','a'):gsub('î','i'):gsub('ô','o'):gsub('ç','c')
    return s
end
function QF:ReadProfessions()
    local out={}
    if GetProfessions and GetProfessionInfo then
        local ids={GetProfessions()}
        for _,index in pairs(ids) do
            if type(index)=='number' then
                local ok,name,_,rank,cap,_,_,skillID=pcall(GetProfessionInfo,index)
                if ok and name then
                    local id=type(skillID)=='number' and skillID or aliases[normalize(name)]
                    if id then out[id]={name=name,rank=rank or 0,cap=cap or 0} end
                end
            end
        end
    end
    -- Classic clients also expose the older Skill window API. This picks up
    -- Cooking, Fishing and First Aid on clients whose GetProfessions omits them.
    if GetNumSkillLines and GetSkillLineInfo then
        local n=GetNumSkillLines() or 0
        for i=1,n do
            local name,isHeader,_,rank,_,_,maxRank=GetSkillLineInfo(i)
            if not isHeader and name then
                local id=aliases[normalize(name)]
                if id and not out[id] then out[id]={name=name,rank=rank or 0,cap=maxRank or 0} end
            end
        end
    end
    if C_SkillInfo and C_SkillInfo.GetNumSkillLines and C_SkillInfo.GetSkillLineInfo then
        for i=1,(self.Safe(C_SkillInfo.GetNumSkillLines) or 0) do
            local skill=self.Safe(C_SkillInfo.GetSkillLineInfo,i)
            if skill and not skill.isHeader and type(skill.skillID)=='number' then
                out[skill.skillID]={name=skill.name,rank=skill.rank or 0,cap=skill.maxRank or 0}
            end
        end
    end
    self.professions=out
    return out
end
function QF:QuestProfession(id)
    local lib=self:Provider()
    if not(lib and lib.Quest and lib.Quest.Get) then return nil,nil end
    local ok,req=pcall(lib.Quest.Get,id,'requiredSkill')
    if ok and type(req)=='table' and type(req[1])=='number' and req[1]>0 then
        return req[1],req[2] or 0
    end
    local valid,category=pcall(lib.Quest.Get,id,'zoneOrSort')
    if valid and type(category)=='number' and category<0 and self.professions and self.professions[-category] then
        return -category,0
    end
    return nil,nil
end
function QF:AnnotateProfession(q)
    if not q or not q.id then return end
    if not self.professions then self:ReadProfessions() end
    local skill,required=self:QuestProfession(q.id)
    if skill then
        local owned=self.professions[skill]
        if owned then
            q.profession=skill
            q.professionName=owned.name
            q.professionRequired=required
        elseif required and required>0 then
            q.missingProfession=true
        end
    end
end
function QF:ProfessionReminder()
    if not self.db.professionTips then return nil end
    if not self.professions then self:ReadProfessions() end
    for skill,p in pairs(self.professions or {}) do
        if p.cap and p.cap>0 and p.rank and p.rank>=p.cap-8 and p.cap<375 then
            local key='proftrain:'..skill..':'..p.cap
            if not self.db.acknowledged[key] then
                return {key=key,title='Métier : '..p.name,
                  detail=p.rank..'/'..p.cap..' : pense au prochain rang auprès d’un maître.',type='profession'}
            end
        end
    end
end
