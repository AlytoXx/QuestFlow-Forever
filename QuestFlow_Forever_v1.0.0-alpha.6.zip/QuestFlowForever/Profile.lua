local _,Q=...
local professions={{171,'Alchimie'},{164,'Forge'},{333,'Enchantement'},{202,'Ingénierie'},
 {182,'Herboristerie'},{165,'Travail du cuir'},{186,'Minage'},{393,'Dépeçage'},
 {197,'Couture'},{185,'Cuisine'},{356,'Pêche'},{129,'Secourisme'},{755,'Joaillerie'},{773,'Calligraphie'}}
local function jobName(id)
    for _,job in ipairs(professions)do if job[1]==id then return job[2] end end
    return 'Métier '..tostring(id)
end
function Q:FollowProfession(id)
    local p=self.db.profile
    return not p or not p.customJobs or p.jobs[id]==true
end
function Q:ProfileDraft()
    local p=self.db.profile or {};return {customJobs=p.customJobs==true,jobs=self.Copy(p.jobs or {}),
      masters=self.Copy(p.masters or {}),detour=self.db.trainerDetour,mode=not self.db.professionQuests and 0 or self.db.professionPriority and 2 or 1}
end
function Q:ApplyProfile(d)
    self.db.profile={done=true,customJobs=d.customJobs,jobs=self.Copy(d.jobs),masters=self.Copy(d.masters)}
    self.db.trainerDetour=d.detour;self.db.professionQuests=d.mode>0;self.db.professionPriority=d.mode==2
    if self.ready then self:Optimise() end
end
local function label(f,y)
    local t=f:CreateFontString(nil,'OVERLAY','GameFontNormal');t:SetPoint('TOPLEFT',14,y);t:SetWidth(370);t:SetJustifyH('LEFT');return t
end
local function button(f,x,y,w,fn)
    local b=CreateFrame('Button',nil,f,'UIPanelButtonTemplate');b:SetSize(w,23);b:SetPoint('TOPLEFT',x,y);b:SetScript('OnClick',fn);return b
end
local function input(f,x,y,w)
    local b=CreateFrame('EditBox',nil,f,'InputBoxTemplate');b:SetSize(w,22);b:SetPoint('TOPLEFT',x,y);b:SetAutoFocus(false);b:SetMaxLetters(20);return b
end
function Q:RefreshProfile()
    local f=self.profileFrame;local d=self.profileDraft
    f.detour:SetText(d.detour==0 and 'Maître de classe : désactivé' or 'Maître de classe : détour maximal '..d.detour..' s')
    f.mode:SetText('Quêtes de métier : '..({[0]='désactivées','utiles','prioritaires'})[d.mode])
    f.auto:SetText(d.customJobs and 'Sélection personnelle' or 'Tous mes métiers appris (auto)')
    for _,b in ipairs(f.jobs)do local checked=d.customJobs and d.jobs[b.id] or not d.customJobs and self.professions[b.id];b:SetText((checked and '[x] ' or '[ ] ')..jobName(b.id)) end
    f.masterType:SetText(self.profileMaster=='class' and 'Maître de classe' or jobName(self.profileMaster))
    local m=d.masters[self.profileMaster];f.saved:SetText(m and ('Point enregistré : carte '..m.point.map..', '..m.point.x..' / '..m.point.y) or 'Facultatif : coordonnées sur ta carte actuelle.')
    for _,w in ipairs(f.advancedWidgets) do w:SetShown(self.profileAdvanced) end
    f.spell:SetShown(self.profileAdvanced and self.profileMaster=='class');f.spellLabel:SetShown(self.profileAdvanced and self.profileMaster=='class')
    f.toggle:SetText(self.profileAdvanced and 'Masquer les emplacements' or '+ Indiquer un maître connu (facultatif)')
    local y=self.profileAdvanced and -430 or -293
    f.save:ClearAllPoints();f.save:SetPoint('TOPLEFT',12,y);f.skip:ClearAllPoints();f.skip:SetPoint('TOPLEFT',205,y)
    f:SetHeight(self.profileAdvanced and 475 or 336)
end
function Q:ProfileMasterPoint(x,y,spell)
    local map=self:MapID();x=tonumber((tostring(x):gsub(',','.')));y=tonumber((tostring(y):gsub(',','.')))
    if not map or not x or not y or x<0 or x>100 or y<0 or y>100 then return nil,'Coordonnées requises entre 0 et 100.' end
    if spell and spell~='' and (not tonumber(spell) or not tostring(spell):match('^%d+$') or tonumber(spell)<1) then return nil,'Identifiant de sort invalide.' end
    return {point={map=map,x=x,y=y},spell=tonumber(spell),stamp=self.stamp}
end
function Q:ShowProfile(first)
    if first and self.db.profile and self.db.profile.done then return end
    self:ReadProfessions();self.profileDraft=self:ProfileDraft();self.profileMaster='class';self.profileAdvanced=false
    if not self.profileFrame then
        local f=CreateFrame('Frame',nil,UIParent,'BackdropTemplate');self.profileFrame=f
        f:SetSize(400,475);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG');f:SetClampedToScreen(true);f:EnableMouse(true)
        if f.SetBackdrop then f:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=10});f:SetBackdropColor(.025,.045,.055,.98) end
        f.title=label(f,-12);f.detour=button(f,12,-38,375,function()local d=Q.profileDraft;d.detour=({[0]=30,[30]=45,[45]=60,[60]=0})[d.detour] or 45;Q:RefreshProfile()end)
        f.mode=button(f,12,-65,375,function()local d=Q.profileDraft;d.mode=(d.mode+1)%3;Q:RefreshProfile()end)
        f.auto=button(f,12,-92,375,function()local d=Q.profileDraft;d.customJobs=not d.customJobs;Q:RefreshProfile()end)
        f.jobs={}
        for i,job in ipairs(professions)do local id=job[1];local b=button(f,12+((i-1)%3)*125,-123-math.floor((i-1)/3)*25,124,function()
            local d=Q.profileDraft
            if not d.customJobs then d.jobs={};for _,entry in ipairs(professions)do if Q.professions[entry[1]] then d.jobs[entry[1]]=true end end end
            d.customJobs=true;d.jobs[id]=not d.jobs[id];Q:RefreshProfile()
        end);b.id=id;f.jobs[#f.jobs+1]=b end
        f.toggle=button(f,12,-253,375,function()Q.profileAdvanced=not Q.profileAdvanced;Q:RefreshProfile() end)
        f.masterType=button(f,12,-282,190,function()
            local keys={'class'};for _,j in ipairs(professions)do if Q.profileDraft.jobs[j[1]] or Q.professions[j[1]] then keys[#keys+1]=j[1] end end
            local idx=1;for i,v in ipairs(keys)do if v==Q.profileMaster then idx=i end end;Q.profileMaster=keys[idx%#keys+1];Q:FillProfileFields();Q:RefreshProfile()
        end)
        local rm=button(f,210,-282,176,function()Q.profileDraft.masters[Q.profileMaster]=nil;Q:FillProfileFields();Q:RefreshProfile()end);rm:SetText('Effacer ce point')
        f.saved=label(f,-314);f.saved:SetHeight(22)
        f.x=input(f,35,-346,47);f.y=input(f,111,-346,47)
        local xx=label(f,-349);xx:SetWidth(16);xx:SetText('X');local yy=label(f,-349);yy:ClearAllPoints();yy:SetPoint('TOPLEFT',f,'TOPLEFT',92,-349);yy:SetWidth(16);yy:SetText('Y')
        f.spellLabel=label(f,-349);f.spellLabel:ClearAllPoints();f.spellLabel:SetPoint('TOPLEFT',f,'TOPLEFT',168,-349);f.spellLabel:SetWidth(80);f.spellLabel:SetText('ID du sort');f.spell=input(f,248,-346,60)
        f.add=button(f,12,-377,375,function()local m,err=Q:ProfileMasterPoint(f.x:GetText(),f.y:GetText(),Q.profileMaster=='class' and f.spell:GetText() or nil);if m then Q.profileDraft.masters[Q.profileMaster]=m;Q:RefreshProfile() else f.saved:SetText(err) end end);f.add:SetText('Ajouter ce point sur la carte actuelle')
        f.advancedWidgets={f.masterType,rm,f.saved,f.x,f.y,xx,yy,f.add}
        local save=button(f,12,-430,180,function()
            if Q.profileAdvanced then
                local x,y=f.x:GetText() or '',f.y:GetText() or ''
                local spell=Q.profileMaster=='class' and (f.spell:GetText() or '') or ''
                local old=Q.profileDraft.masters[Q.profileMaster]
                if (x~='' or y~='' or spell~='') and (not old or tostring(old.point.x)~=x or tostring(old.point.y)~=y or tostring(old.spell or '')~=spell) then
                    local point,err=Q:ProfileMasterPoint(x,y,spell)
                    if not point then f.saved:SetText(err);return end
                    Q.profileDraft.masters[Q.profileMaster]=point
                end
            end
            Q:ApplyProfile(Q.profileDraft);f:Hide()
        end);save:SetText('Enregistrer mon profil')
        local skip=button(f,205,-430,182,function() if not Q.db.profile or not Q.db.profile.done then Q:ApplyProfile(Q:ProfileDraft()) end;f:Hide() end);skip:SetText('Garder mes réglages');f.save=save;f.skip=skip
    end
    local f=self.profileFrame;f.title:SetText('Profil QuestFlow · '..(self.Safe(UnitClass,'player') or 'Personnage'));self:FillProfileFields();self:RefreshProfile();f:Show()
end
function Q:FillProfileFields()
    local f=self.profileFrame;local m=self.profileDraft.masters[self.profileMaster]
    f.x:SetText(m and tostring(m.point.x) or '');f.y:SetText(m and tostring(m.point.y) or '');f.spell:SetText(m and m.spell and tostring(m.spell) or '')
end
function Q:DeclaredMasterStep(origin,goal)
    local p=self.db.profile
    if not p or self.db.trainerDetour<=0 or not goal or not origin or origin.map~=goal.map or (goal.remaining and goal.remaining<=2) or GetTime()<(self.trainerMute or 0) then return end
    local best,bestCost
    for key,m in pairs(p.masters or {})do
        if m.stamp==self.stamp and m.point.map==origin.map then
            local reason
            if key=='class' and m.spell then
                local known=self.Safe(IsSpellKnown or IsPlayerSpell or (C_SpellBook and C_SpellBook.IsSpellKnown),m.spell)
                local name=self.Safe(C_Spell and C_Spell.GetSpellName,m.spell) or self.Safe(GetSpellInfo,m.spell)
                if known==false and name then reason='Vérifier '..name end
            elseif key~='class' and self.db.professionQuests and self:FollowProfession(key) then
                local j=self.professions and self.professions[key]
                if j and j.cap and j.cap>0 and j.rank and j.rank>=j.cap-5 then reason='Vérifier le prochain rang de '..jobName(key) end
            end
            if reason and not (self.masterVisitMute and self.masterVisitMute[key] and self.masterVisitMute[key]>GetTime()) then
                local _,r1=self:MapDistance(origin,m.point);local _,r2=self:MapDistance(m.point,goal.point)
                local direct=self:TravelEstimate(origin,goal.point);local first=self:TravelEstimate(origin,m.point);local last=self:TravelEstimate(m.point,goal.point)
                local extra=direct and first and last and math.max(0,first+last-direct)+8
                if r1 and r2 and extra and first<=90 and extra<=self.db.trainerDetour and (not bestCost or extra<bestCost) then
                    bestCost=extra;best={id=goal.id,key='profil:'..key,kind='trainer',title=key=='class' and 'Maître de classe' or 'Maître de '..jobName(key),point=m.point,map=m.point.map,x=m.point.x,y=m.point.y,profileMaster=key,reason=reason..' · point indiqué · +'..math.ceil(extra)..' s'}
                end
            end
        end
    end
    return best
end
