local _,QF=...
local function copy(t) local n={} for k,v in pairs(t) do n[k]=v end return n end
function QF:IsAllowed(q)
    if self:IsSkipped(q.id) then return false end
    if q.active and q.complete then return true end -- Work filters never hide an earned turn-in.
    if q.kind=='raid' or q.missingProfession then return false end
    if q.profession and (not self.db.professionQuests or not self:FollowProfession(q.profession)) then return false end
    if q.kind=='dungeon' then return self.db.dungeonQuests and (q.potential or q.complete or self.db.dungeonRuns) end
    if q.kind=='group' then return self.db.group end
    if q.kind=='elite' then return self.db.elite end
    return self.db.solo
end
function QF:QuestValue(q)
    if type(q.xp)=='number' and q.xp>=0 then return q.xp,true end
    -- Explicit estimated reward, internal only. Never recorded as observed XP.
    return math.max(100,(tonumber(q.level) or UnitLevel('player') or 1)*55),false
end
function QF:BuildActions()
    local actions={};local pool={};local seen={};self.unlocated={};self.obsolete={};self.potentialCount=0
    for _,q in ipairs(self.quests or {}) do pool[#pool+1]=q;seen[q.id]=true end
    for _,q in ipairs(self.discovery or {}) do if not seen[q.id] then pool[#pool+1]=q;seen[q.id]=true end end
    local function add(q,kind,p,seconds,xp,credit,requires,suffix)
        local a={key=tostring(q.id)..':'..(suffix or kind),id=q.id,kind=kind,point=p,
          seconds=seconds,xp=xp or 0,credit=credit or 0,requires=requires or {},quest=q,
          title=q.title,state=q.state,active=q.active,complete=kind=='turnin',potential=kind=='pickup',
          map=p.map,x=p.x,y=p.y,objectives=q.objectives,approximate=p.approximate}
        actions[#actions+1]=a;return a
    end
    for _,q in ipairs(pool) do
        if self:IsAllowed(q) then
            local usable=not q.potential or q.state=='verified' or (q.state=='potential' and self.db.experimentalOffers)
            if q.potential and not usable then self.potentialCount=self.potentialCount+1 end
            if usable then
                local xp=self:QuestValue(q);local dependencies={};local progressCredit=0
                local multiplier=self:TimeMultiplier(q.id)
                local pickup
                if q.potential and self.ValidPoint(q.startPoint) then
                    pickup=add(q,'pickup',q.startPoint,8,0,xp*.10,{})
                    progressCredit=xp*.10
                    dependencies={pickup.key}
                end
                if not q.complete then
                    local todo={};local allLocated=true
                    for i,o in ipairs(q.objectives or {}) do
                        if not o.finished then
                            if not self.ValidPoint(o.point) then allLocated=false end
                            todo[#todo+1]={index=i,objective=o}
                        end
                    end
                    local workKeys={}
                    if #todo>0 and allLocated then
                        for _,entry in ipairs(todo) do
                            local o=entry.objective
                            local left=math.max(0,(tonumber(o.needed) or 1)-(tonumber(o.current) or 0))
                            local credit=xp*(pickup and .65 or .75)/#todo
                            local a=add(q,'work',o.point,6+left*self.db.secondsPerObjective*multiplier,0,credit,dependencies,'work'..entry.index)
                            a.remaining=left;a.entity=o.type=='monster' and o.objectID or nil;a.objectiveText=o.text;workKeys[#workKeys+1]=a.key;progressCredit=progressCredit+credit
                        end
                    elseif self.ValidPoint(q.workPoint) then
                        local left=0
                        for _,entry in ipairs(todo) do
                            local o=entry.objective
                            left=left+math.max(0,(tonumber(o.needed) or 3)-(tonumber(o.current) or 0))
                        end
                        if left==0 then left=8 end
                        local seconds=12+left*self.db.secondsPerObjective*multiplier
                        if q.kind=='dungeon' then seconds=seconds+(self.db.dungeonReady and 540 or 900) end
                        local a=add(q,'work',q.workPoint,seconds,0,xp*(pickup and .65 or .75),dependencies)
                        a.remaining=left;a.aggregate=true;workKeys={a.key};progressCredit=xp*.75
                    else
                        self.unlocated[#self.unlocated+1]=q
                        if pickup then pickup.incompleteData=true end
                    end
                    if #workKeys>0 then dependencies=workKeys else dependencies=nil end
                end
                if dependencies and self.ValidPoint(q.returnPoint) then
                    local a=add(q,'turnin',q.returnPoint,10,xp,-progressCredit,dependencies)
                    a.utility=self:ChainBenefit(q)
                    if q.profession and self.db.professionPriority then a.utility=a.utility+xp*.25 end
                elseif q.complete then self.unlocated[#self.unlocated+1]=q end
                -- Pickup without located future work is visible at the NPC, but is
                -- not an automatic detour: the future benefit cannot be evaluated.
                if pickup and (not dependencies or not self.ValidPoint(q.returnPoint)) then pickup.blocked=true end
            end
        end
    end
    self:AnnotateSharedWork(actions)
    for _,a in ipairs(actions)do
        if self:ActionBlocked(a) then a.blocked=true end
        if a.quest and a.quest.state=='verified' and a.quest.expires and a.quest.expires<=self:Time() then a.blocked=true end
    end
    return actions
end
-- Nearby completed hand-ins take precedence over a modeled long XP loop.
-- Require real distance plus an accessible short approach, never map-percent guesses.
function QF:NearbyTurnin(actions,start,access)
    if not start then return end
    local best,cost
    for _,a in ipairs(actions or {}) do
        if a.kind=='turnin' and a.quest and a.quest.active and a.quest.complete
          and not self:IsSkipped(a.id) and not self:ActionBlocked(a)
          and self.Optimizer.Eligible(a,{used={},slots=#self.quests},self:JournalCapacity())
          and a.point.map==start.map then
            local d,real=self:MapDistance(start,a.point)
            if real and d and d<=40 then
                local snapshot=access or self:LoopAccess({a})
                local t=self:LoopTravel(start,a.point,a,nil,snapshot)
                if t and t<=15 and (not cost or t<cost or (t==cost and a.key<best.key)) then best=a;cost=t end
            end
        end
    end
    return best
end
function QF:Plan()
    self.solveToken=(self.solveToken or 0)+1;local token=self.solveToken
    local start=self:PlayerPoint()
    if not start then self.route={};self.solveStatus='Position inconnue';self:UpdateUI();return end
    self.routeMap=start.map
    local actions=self:BuildActions();local cap=self:JournalCapacity()
    local displayed=self.route and self.route[1]
    local old=displayed
    if old and old.originalAction then old=old.originalAction end
    if old then
        local valid=false
        for _,a in ipairs(actions) do
            if a.key==old.key and self.Optimizer.Eligible(a,{used={},slots=#self.quests},cap) then valid=true;break end
        end
        if not valid then self.route={};old=nil;self:UpdateUI() end
    end
    local travelCache={}
    local access=self:LoopAccess(actions)
    local nearby=self:NearbyTurnin(actions,start,access)
    local function locationKey(p)return p and (p.map..":"..p.x..":"..p.y) or "nil" end
    local options={width=12,horizon=90,capacity=cap,slots=#self.quests,
      budget=self:SessionBudget(),forceFirst=nearby and nearby.key,
      travel=function(a,b,action,previous)
        local key=locationKey(a)..'>'..action.key..':'..(previous and previous.key or 'start')
        if travelCache[key]==nil then
            travelCache[key]=self:LoopTravel(a,b,action,previous,access) or false
        end
        return travelCache[key] or nil
      end,
      yieldFn=function() coroutine.yield() end}
    local co=coroutine.create(function()
        local winner=self.Optimizer.Solve(actions,start,options)
        if #winner.seq==0 and options.budget then
            -- The session is a soft preference: never leave a player stranded
            -- just because one meaningful action exceeds the remaining time.
            local fallback=self.Copy(options);fallback.budget=nil;fallback.horizon=1
            winner=self.Optimizer.Solve(actions,start,fallback)
            if winner.seq[1] then winner.seq[1].reason='Étape dépassant probablement le temps restant.' end
        end
        -- Compare complete candidates BEFORE deciding whether to change direction.
        local comparisons
        winner,comparisons=self:ComparePickups(winner,actions,start,options)
        if not nearby and old and winner.seq[1] and old.key~=winner.seq[1].key then
            local present
            local initial={used={},slots=#self.quests}
            for _,a in ipairs(actions) do
                if a.key==old.key and self.Optimizer.Eligible(a,initial,cap) then present=a;break end
            end
            if present then
                local locked=self.Copy(options);locked.forceFirst=old.key
                local keep=self.Optimizer.Solve(actions,start,locked)
                local keepComparisons
                keep,keepComparisons=self:ComparePickups(keep,actions,start,locked)
                local d,real=self:MapDistance(start,present.point)
                local near=present.kind=='work' and (present.remaining or 99)<=2 and d and d<(real and 130 or 2.6)
                if self.Optimizer.KeepCurrent(winner,keep,GetTime(),self.lastSwitchAt or -999,near) then
                    winner=keep;comparisons=keepComparisons
                end
            end
        end
        if token~=self.solveToken then return end
        self.loopComparisons=comparisons
        local nextStep=winner.seq[1]
        if nextStep and nearby and nextStep.key==nearby.key then nextStep.nearbyTurnin=true end
        if nextStep and (not old or nextStep.key~=old.key) then self.lastSwitchAt=GetTime() end
        self.route=self:DecorateRoute(winner,start,displayed);self.currentId=nextStep and nextStep.id;self.ranked=actions
        self.lastSimulation={seconds=winner.seconds,xp=winner.xp,travel=winner.travel,expansions=winner.expansions}
        local first=self.route[1];local comparison=first and comparisons[first.id]
        if first and first.kind=='pickup' and comparison and comparison.included then
            first.reason='Prendre ici : la boucle reste rentable avec cette quête.'
        end
        self.solveStatus='Prêt';self:SaveSession();self:UpdateUI()
    end)
    self.solveStatus='Calcul en cours'
    local function resume()
        if token~=self.solveToken then return end
        -- 128 expansion checks per resume; max sixteen resumes per timer callback.
        for _=1,16 do
            local ok,err=coroutine.resume(co)
            if not ok then self.lastError=tostring(err);self.solveStatus='Erreur';self:UpdateUI();return end
            if coroutine.status(co)=='dead' then return end
        end
        if C_Timer and C_Timer.After then C_Timer.After(.01,resume)
        else self.lastError='C_Timer.After absent';self.solveStatus='API incompatible' end
    end
    resume()
end
function QF:Waypoint()
    local q=self.route and self.route[1]
    if not q then return end
    if TomTom and TomTom.AddWaypoint then
        if self.tomtomPoint and TomTom.RemoveWaypoint then self.Safe(TomTom.RemoveWaypoint,TomTom,self.tomtomPoint) end
        self.tomtomPoint=self.Safe(TomTom.AddWaypoint,TomTom,q.map,q.x/100,q.y/100,{title=q.title,persistent=false,silent=true})
    end
end
function QF:FocusNext() self:ToggleSkipMenu() end
