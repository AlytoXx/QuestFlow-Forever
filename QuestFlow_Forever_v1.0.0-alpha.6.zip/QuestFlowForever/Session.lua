local _,QF=...
function QF:InitSession()
    local saved=self.db.session
    self.sessionRemaining=type(saved)=='table' and tonumber(saved.remaining) or nil
    if self.sessionRemaining==nil then self.sessionRemaining=(self.db.timeBudget or 0)*60 end
    self.sessionRemaining=math.max(0,self.sessionRemaining)
    self.sessionPaused=false;self.sessionEnded=false
    self.resumeNotice=type(saved)=='table' and saved.lastQuest and 'Reprise : journal et position revérifiés.' or nil
end
function QF:StartSession(minutes)
    local valid={[0]=true,[15]=true,[30]=true,[60]=true,[90]=true}
    if not valid[minutes] then return self:Print('Durée : 15, 30, 60, 90 ou 0 (libre).') end
    self.db.timeBudget=minutes;self.sessionRemaining=minutes*60
    self.sessionPaused=false;self.sessionEnded=false;self.resumeNotice=nil
    self:SaveSession();self:Optimise()
end
function QF:SaveSession()
    local a=self.route and self.route[1]
    self.db.session={remaining=self.sessionRemaining,at=self:Time(),lastQuest=a and a.id,
      lastAction=a and a.key,point=self:PlayerPoint(),stamp=self.stamp}
end
function QF:TickSession(dt)
    if not self.sessionPaused and not self.Safe(UnitIsAFK,'player') and (self.db.timeBudget or 0)>0 then
        self.sessionRemaining=math.max(0,(self.sessionRemaining or 0)-math.min(dt,10))
        if self.sessionRemaining==0 and not self.sessionEnded then
            self.sessionEnded=true;self:Print('Durée prévue écoulée. Le guide continue ; ajuste la session dans Options.')
            self:Plan()
        end
    end
    self:SaveSession()
end
function QF:SessionBudget()
    if self.db.timeBudget==0 or (self.sessionRemaining or 0)<=0 then return nil end
    return self.sessionRemaining
end
function QF:SessionText()
    if self.db.timeBudget==0 then return 'Libre' end
    return math.ceil((self.sessionRemaining or 0)/60)..' min'..(self.sessionPaused and ' · pause' or '')
end
