local _,QF=...
local function list(v) return type(v)=='table' and v or {} end
-- Forecast usefulness only. Never turns a hypothetical unlocked quest into an offer.
function QF:ChainBenefit(q)
    local children={};local nextID=self:DBGet('Quest',q.id,'nextQuestInChain')
    if type(nextID)=='number' and nextID>0 then children[#children+1]=nextID end
    for _,id in ipairs(list(self:DBGet('Quest',q.id,'childQuests')))do
        if id~=nextID then children[#children+1]=id end
    end
    for index,id in ipairs(children)do
        if index>8 then break end
        if not self:QuestFinished(id) and not self.activeIds[id] then
            local blocked=false;local req=self:DBGet('Quest',id,'requiredLevel')
            if type(req)~='number' or req>(UnitLevel('player') or 1) then blocked=true end
            for _,other in ipairs(list(self:DBGet('Quest',id,'exclusiveTo')))do
                if self.activeIds[other] or self:QuestFinished(other) then blocked=true end
            end
            for _,pre in ipairs(list(self:DBGet('Quest',id,'preQuestGroup')))do
                if pre~=q.id and (pre<=0 or not self:QuestFinished(pre)) then blocked=true end
            end
            local singles=list(self:DBGet('Quest',id,'preQuestSingle'));local any=#singles==0
            for _,pre in ipairs(singles)do if pre==q.id or (pre>0 and self:QuestFinished(pre)) then any=true end end
            if not any then blocked=true end
            -- Complex class/faction/event gates require a verified future offer.
            for _,field in ipairs({'requiredRaces','requiredClasses','requiredSkill','requiredMinRep','requiredMaxRep','requiredSpell','specialFlags'})do
                local gate=self:DBGet('Quest',id,field)
                if gate and gate~=0 and (type(gate)~='table' or next(gate)) then blocked=true end
            end
            local level=self:DBGet('Quest',id,'questLevel')
            if not blocked and type(level)=='number' and level>0 then
                q.chainHint=id;return math.min(self:QuestValue(q)*.15,level*4)
            end
        end
    end
    return 0
end
function QF:VerificationStep(origin,destination)
    if not self.db.verifyOnPath or not origin or not destination then return end
    local capacity=self:JournalCapacity();if not capacity or #self.quests>=capacity then return end
    if destination.kind=='work' and (destination.remaining or 99)<=2 then return end
    local direct=self:TravelEstimate(origin,destination.point);if not direct then return end
    local best,cost
    for _,q in ipairs(self.discovery or {})do
        if q.state=='potential' and not self:OfferSuppressed(q.id) and self:IsAllowed(q)
          and self.ValidPoint(q.startPoint) and self.ValidPoint(q.workPoint) and self.ValidPoint(q.returnPoint)
          and q.startPoint.map==origin.map then
            local first=self:TravelEstimate(origin,q.startPoint)
            local nextLeg=self:TravelEstimate(q.startPoint,destination.point)
            local synergy=self:TravelEstimate(q.workPoint,destination.point)
            local detour=first and nextLeg and math.max(0,first+nextLeg-direct)+8
            if detour and synergy and detour<=20 and first<=40 and synergy<=60
              and (not cost or detour<cost) then
                cost=detour;best={key=q.id..':verify',id=q.id,kind='verify',title=q.title,quest=q,state='potential',
                  point=q.startPoint,map=q.startPoint.map,x=q.startPoint.x,y=q.startPoint.y,approximate=true}
            end
        end
    end
    if best and self:ActionBlocked(best) then return nil end
    return best
end
function QF:DecorateRoute(winner,start,previous)
    local seq=winner.seq
    if #seq==0 then
        local trainer=self:TrainerStep(start,{id=0,kind='work',point=start,map=start.map})
        if trainer then seq[1]=trainer end
        return seq
    end
    -- Stop future steps becoming execution instructions: only the actual first
    -- actionable step gets navigation inserts. Everything else is forecast.
    local first=seq[1]
    local verify=not first.nearbyTurnin and self:VerificationStep(start,first)
    local service=not first.nearbyTurnin and not verify and self:ServiceStep(start,first)
    local trainer=not first.nearbyTurnin and not verify and not service and self:TrainerStep(start,first)
    local insert=verify or service or trainer
    local previousBase=previous and (previous.originalAction or previous)
    if previousBase and previousBase.key==first.key then
        -- An incidental stop cannot interrupt an instruction already being followed.
        -- Keep an existing incidental stop only while it is still recommended.
        if not previous.originalAction or not insert or insert.key~=previous.key then insert=nil end
    end
    if insert then
        insert.originalAction=first
        table.insert(seq,1,insert)
    else
        local nav=self:NavigationStep(first)
        if nav~=first then table.insert(seq,1,nav) end
    end
    local current=seq[1]
    current.reason=self:ExplainAction(current)
    self.zoneDecision=nil
    if first.map~=start.map then
        self.zoneDecision='Changer de zone : trajet observé, objectifs connus.'
    elseif #seq>1 then self.zoneDecision='Poursuivre les objectifs accessibles ici.' end
    return seq
end
