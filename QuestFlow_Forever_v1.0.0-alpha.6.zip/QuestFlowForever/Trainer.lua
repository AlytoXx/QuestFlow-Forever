local _,Q=...
-- Priority choices, not claims about Forever levels or trainer locations.
local staples={HUNTER={3044,5116,13165},MAGE={116,118},WARRIOR={100,355},
 PRIEST={17,2006},PALADIN={635,7328},WARLOCK={172,5782},DRUID={5185,5487},
 SHAMAN={403,8042},ROGUE={5277,1766}}
local function spellName(id)
    return Q.Safe(C_Spell and C_Spell.GetSpellName,id) or Q.Safe(GetSpellInfo,id)
end
local function known(id)
    local fn=IsSpellKnown or IsPlayerSpell or (C_SpellBook and C_SpellBook.IsSpellKnown)
    local result=Q.Safe(fn,id);if result==true or result==false then return result end
end
function Q:ObserveTrainer()
    local _,class=self.Safe(UnitClass,'player');local here=self:PlayerPoint()
    if not class or not self.ValidPoint(here) then return end
    local n=self.Safe(GetNumTrainerServices);if type(n)~='number' or n<1 then return end
    local wanted={};for _,id in ipairs(staples[class] or {})do local name=spellName(id);if name then wanted[name]=id end end
    for id,yes in pairs(self.db.prioritySpells or {})do local name=spellName(id);if yes and name then wanted[name]=id end end
    local offers={};local level=self.Safe(UnitLevel,'player')
    for i=1,math.min(n,1000) do
        local name,a,b=self.Safe(GetTrainerServiceInfo,i)
        local status=(a=='available' or a=='unavailable' or a=='used') and a or b
        local id=name and wanted[name]
        if id then
            -- Match a higher rank only with an exact spell link. A localized
            -- name alone cannot distinguish an upgrade from a learned rank.
            local link=self.Safe(GetTrainerServiceItemLink,i)
            local linked=type(link)=='string' and tonumber(link:match('spell:(%d+)'))
            if linked and spellName(linked)==name then id=linked
            elseif type(a)=='string' and (tonumber(a:match('(%d+)')) or 1)>1 then id=nil end
        end
        if id and known(id)==false then
            local required=self.Safe(GetTrainerServiceLevelReq,i)
            if status=='available' or (status=='unavailable' and type(required)=='number' and level and required>level) then
                local cost=self.Safe(GetTrainerServiceCost,i)
                offers[#offers+1]={id=id,name=name,level=required or level,available=status=='available',cost=cost}
            end
        end
    end
    local npc=self:NPCID() or self:PointKey(here);self.db.trainers=self.db.trainers or {}
    self.db.trainers[npc]={point=self.Copy(here),name=self.Safe(UnitName,'npc') or 'Maître de classe',
        class=class,offers=offers,at=self:Time(),stamp=self.stamp}
    self.trainerMute=GetTime()+120
end
function Q:TrainerStep(origin,goal)
    if self.db.trainerDetour==0 or not origin or not goal or goal.kind~='work' and goal.kind~='turnin' and goal.kind~='pickup' then return end
    if GetTime()<(self.trainerMute or 0) or origin.map~=goal.map or (goal.remaining and goal.remaining<=2) then return end
    local _,class=self.Safe(UnitClass,'player');local level=self.Safe(UnitLevel,'player')
    local purse=self.Safe(GetMoney);local direct=self:TravelEstimate(origin,goal.point)
    if not direct or not level or not class then return end
    local best,cost
    for key,t in pairs(self.db.trainers or {}) do
        if t.stamp==self.stamp and t.class==class and self:Time()-t.at<7*86400 and t.point.map==origin.map then
            local _,r1=self:MapDistance(origin,t.point);local _,r2=self:MapDistance(t.point,goal.point)
            local outward=self:TravelEstimate(origin,t.point);local after=self:TravelEstimate(t.point,goal.point)
            local extra=outward and after and math.max(0,outward+after-direct)+8
            if r1 and r2 and extra and outward<=90 and extra<=self.db.trainerDetour and (not cost or extra<cost) then
                for _,s in ipairs(t.offers) do
                    if known(s.id)==false and level>=s.level and (not s.cost or not purse or purse>=s.cost) then
                        best={key='trainer:'..key..':'..s.id,id=goal.id,kind='trainer',title=t.name,quest=goal.quest,
                         point=t.point,map=t.point.map,x=t.point.x,y=t.point.y,spell=s.id,
                         reason=(s.available and 'Apprendre ' or 'Vérifier ')..s.name..' · détour ~'..math.ceil(extra)..' s'}
                        if self:ActionBlocked(best) then best=nil else cost=extra;break end
                    end
                end
            end
        end
    end
    return best or self:DeclaredMasterStep(origin,goal)
end
