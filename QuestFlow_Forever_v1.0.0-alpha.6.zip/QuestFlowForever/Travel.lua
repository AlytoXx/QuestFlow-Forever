local _,QF=...
local baseEstimate=QF.TravelEstimate
local function median(t)
    local n={};for _,v in ipairs(t)do n[#n+1]=v end;table.sort(n)
    return n[math.ceil(#n/2)]
end
function QF:MarkPassage()
    local a=self.route and self.route[1];local p=self:PlayerPoint()
    if not a or not self.ValidPoint(p) or a.kind=='passage' then return self:Print('Sélectionne un objectif puis place-toi à son entrée.') end
    self.memory.passages[a.key]={point=self.Copy(p),at=self:Time(),stamp=self.stamp,source='user'}
    self.visitedPassages[a.key]=true -- currently standing at the marked entrance
    self:Print('Passage enregistré pour cet objectif.');self:Plan()
end
function QF:PassageFor(a)
    local row=self.memory.passages[a.key]
    if row and row.stamp==self.stamp and row.point.map==a.point.map then return row.point end
end
function QF:NavigationStep(a)
    if not a then return end
    local p=self:PassageFor(a)
    if p and self:MapID()==p.map and not self.visitedPassages[a.key] then
        local d,real=self:MapDistance(self:PlayerPoint(),p)
        if d and d<(real and 15 or .3) then self.visitedPassages[a.key]=true
        else
            local n=self.Copy(a);n.kind='passage';n.key=a.key..':passage';n.title='Passage vers '..a.title
            n.point=p;n.map=p.map;n.x=p.x;n.y=p.y;n.originalAction=a;n.remaining=nil
            return n
        end
    end
    local origin=self:PlayerPoint()
    if origin and origin.map~=a.map then
        local _,edge=self:KnownCrossMap(origin,a.point)
        if edge then
            local n=self.Copy(a);n.kind='passage';n.key=a.key..':transition';n.title='Passage vers la zone suivante'
            n.point=edge.from;n.map=edge.from.map;n.x=edge.from.x;n.y=edge.from.y;n.originalAction=a;n.remaining=nil
            n.edgeKey=edge.key
            return n
        end
    end
    return a
end
function QF:AddTransition(from,to,seconds)
    local key=self:PointKey(from)..'>'..self:PointKey(to)
    local row=self.memory.edges[key]
    if not row or row.stamp~=self.stamp then row={from=self.Copy(from),to=self.Copy(to),samples={},stamp=self.stamp,key=key} end
    row.samples[#row.samples+1]=seconds;if #row.samples>7 then table.remove(row.samples,1) end
    row.at=self:Time();row.seconds=median(row.samples);row.count=#row.samples
    self.memory.edges[key]=row;self:PruneMemory()
end
function QF:KnownCrossMap(a,b)
    if not a or not b then return end
    -- Bounded Dijkstra across observed directed transitions; no reverse edge invented.
    local queue={{p=a,time=0,visited={}}};local best;local distances={[self:PointKey(a)]=0}
    for _=1,160 do
        table.sort(queue,function(x,y)return x.time<y.time end)
        local s=table.remove(queue,1);if not s then break end
        if s.p.map==b.map then
            local t=s.time+baseEstimate(self,s.p,b)
            if not best or t<best.time then best={time=t,first=s.first} end
        end
        if not best or s.time<best.time then
            for key,e in pairs(self.memory.edges)do
                if e.count>=2 and e.stamp==self.stamp and e.from.map==s.p.map and not s.visited[key]
                  and self:Time()-e.at<30*86400 and not self:ActionBlocked({key='edge:'..key,point=e.from}) then
                    local time=s.time+baseEstimate(self,s.p,e.from)+e.seconds
                    local node=self:PointKey(e.to)
                    if not distances[node] or time<distances[node] then
                        distances[node]=time
                        local visited=self.Copy(s.visited);visited[key]=true
                        queue[#queue+1]={p=e.to,time=time,first=s.first or e,visited=visited}
                    end
                end
            end
        end
    end
    if best then return best.time,best.first end
end
function QF:TravelEstimate(a,b)
    if not a or not b then return nil end
    if a.map~=b.map then
        local t=self.memory and self:KnownCrossMap(a,b);return t,nil,false
    end
    local key=self:PointKey(a)..'>'..self:PointKey(b)
    local row=self.memory and self.memory.timings[key]
    if row and row.stamp==self.stamp and row.samples and #row.samples>=3 and self:Time()-row.at<30*86400 then
        return median(row.samples),nil,false
    end
    return baseEstimate(self,a,b)
end
function QF:TickTravel(dt)
    local p=self:PlayerPoint();local now=GetTime()
    local invalid=self.Safe(UnitAffectingCombat,'player') or self.Safe(UnitIsAFK,'player')
      or self.Safe(UnitIsDeadOrGhost,'player') or self.Safe(UnitOnTaxi,'player') or self.sessionPaused
    local moving=(self:CurrentSpeed() or 0)>1
    local prev=self.travelPrevious
    if prev and p and prev.p.map~=p.map and not invalid and not prev.invalid and moving then
        local d,real=self:MapDistance(prev.p,p)
        -- Short continuous crossings only; teleports/boats/taxis aren't inferred.
        if real and d and d<150 and now-prev.at<=12 then self:AddTransition(prev.p,p,now-prev.at) end
    end
    self.travelPrevious=p and {p=self.Copy(p),at=now,invalid=invalid}
    local a=self.route and self.route[1]
    if not a or not p then self.travelSample=nil;return end
    local s=self.travelSample
    if not s or s.key~=a.key then
        self.travelSample={key=a.key,from=self.Copy(p),target=self.Copy(a.point),at=now,bad=invalid or not moving,path=0,last=self.Copy(p)};return
    end
    local step,real=self:MapDistance(s.last,p);s.last=self.Copy(p)
    if invalid or not moving or dt>10 or not real or not step then s.bad=true end
    if step then s.path=s.path+step end
    local d,reliable=self:MapDistance(p,s.target)
    if reliable and d<15 then
        local direct,world=self:MapDistance(s.from,s.target);local seconds=now-s.at
        if not s.bad and world and direct>40 and s.path<direct*2.5 and seconds>=5 and seconds<=600 then
            local key=self:PointKey(s.from)..'>'..self:PointKey(s.target)
            local row=self.memory.timings[key]
            if not row or row.stamp~=self.stamp then row={samples={},stamp=self.stamp} end
            row.samples[#row.samples+1]=seconds;if #row.samples>7 then table.remove(row.samples,1)end
            row.at=self:Time();self.memory.timings[key]=row
        end
        self.travelSample=nil
    end
end
