local _,QF=...
local function panel(name,parent,w,h)
    local f=CreateFrame('Frame',name,parent,'BackdropTemplate');f:SetSize(w,h)
    if f.SetBackdrop then
        f:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=10,insets={left=3,right=3,top=3,bottom=3}})
        f:SetBackdropColor(.025,.043,.058,.96);f:SetBackdropBorderColor(.26,.58,.5,.8)
    end
    return f
end
local function text(f,y,font)
    local t=f:CreateFontString(nil,'OVERLAY',font or 'GameFontNormalSmall')
    t:SetPoint('TOPLEFT',12,y);t:SetWidth(306);t:SetJustifyH('LEFT');return t
end
local function button(f,label,x,y,w,fn)
    local b=CreateFrame('Button',nil,f,'UIPanelButtonTemplate');b:SetPoint('TOPLEFT',x,y);b:SetSize(w,23)
    b:SetText(label);b:SetScript('OnClick',fn);return b
end
local function verb(a)
    return a.kind=='trainer' and 'Apprendre' or a.kind=='verify' and 'Vérifier' or a.kind=='service' and 'Passer chez' or a.kind=='passage' and 'Rejoindre' or a.kind=='pickup' and 'Prendre' or a.kind=='turnin' and 'Rendre' or 'Faire'
end
function QF:ActionCategory(a)
    if not a then return 'QuestFlow Forever' end
    local q=a.quest or (a.kind=='passage' and a.originalAction and a.originalAction.quest)
    local category=a.kind=='turnin' and 'À rendre' or a.kind=='pickup' and 'À prendre'
      or a.kind=='trainer' and 'Maître' or a.kind=='service' and 'Service'
      or a.kind=='verify' and 'Offre à vérifier' or a.kind=='passage' and 'Déplacement' or 'Objectif'
    if q and q.profession then return 'Métier · '..(q.professionName or 'métier')..' · '..category end
    if a.map and a.map~=self:MapID() then return 'Déplacement · autre zone' end
    return category
end
function QF:CreateUI()
    local f=panel('QuestFlowForeverPanel',UIParent,264,126);self.frame=f
    local p=self.db.point;f:SetPoint(p[1],UIParent,p[3],p[4],p[5]);f:SetScale(self.db.scale)
    f:SetMovable(true);f:EnableMouse(true);f:RegisterForDrag('LeftButton')
    f:SetScript('OnDragStart',function(s)s:StartMoving()end)
    f:SetScript('OnDragStop',function(s)
        s:StopMovingOrSizing();local a,_,c,x,y=s:GetPoint();QF.db.point={a,'UIParent',c,x,y}
    end)
    f:EnableMouseWheel(true)
    f:SetScript('OnMouseWheel',function(s,delta)
        if IsControlKeyDown and IsControlKeyDown() then
            QF.db.scale=math.max(.7,math.min(1.6,QF.db.scale+delta*.05));s:SetScale(QF.db.scale)
        end
    end)
    self.title=text(f,-7,'GameFontNormalSmall');self.title:SetText('|cff6ee7b7QuestFlow Forever|r')
    self.goal=text(f,-25,'GameFontNormal');self.goal:SetWidth(242);self.goal:SetHeight(27)
    self.detail=text(f,-55);self.detail:SetWidth(242);self.detail:SetHeight(22)
    self.status=text(f,-80);self.status:SetWidth(242)
    self.reasonLabel=text(f,-132);self.reasonLabel:SetWidth(242);self.reasonLabel:SetHeight(30)
    self.steps=text(f,-165);self.steps:SetWidth(242);self.steps:SetHeight(59)
    button(f,'Plus tard',7,-100,84,function()QF:Feedback('later')end)
    button(f,'Changer',93,-100,80,function()QF:ToggleSkipMenu()end)
    button(f,'Options',175,-100,82,function()QF:ToggleSettings()end)
    button(f,'+',231,-3,25,function()QF.db.expanded=not QF.db.expanded;QF:UpdateUI()end)
    self.options=panel(nil,f,332,604);self.options:SetPoint('TOPRIGHT',f,'TOPLEFT',-5,0)
    text(self.options,-12):SetText('Options · Ctrl + molette : taille')
    local prefs={{'Quêtes solo','solo'},{'Quêtes de groupe','group'},{'Quêtes élites','elite'},
      {'Préparer les quêtes de donjon','dungeonQuests'},{'Faire les donjons','dungeonRuns'},
      {'Groupe prêt','dungeonReady'},{'Métiers utiles','professionQuests'},
      {'Métiers prioritaires','professionPriority'},{'Flèche','arrowEnabled'},
      {'Offres Questie : expérimental','experimentalOffers'},{'Recalcul automatique','autoRoute'},{'Vérifier les PNJ sur le trajet','verifyOnPath'},
      {'Aide si la progression bloque','stallDetection'},{'Services utiles sur le passage','services'}}
    self.optionButtons={}
    for i,pref in ipairs(prefs) do
        local key,label=pref[2],pref[1]
        local b=button(self.options,'',10,-35-(i-1)*28,310,function()
            QF.db[key]=not QF.db[key];QF:RefreshOptions();QF:Optimise()
        end)
        b.key=key;b.caption=label;self.optionButtons[#self.optionButtons+1]=b
    end
    self.sessionButton=button(self.options,'Session',10,-432,200,function()
        local cycle={[0]=15,[15]=30,[30]=60,[60]=90,[90]=0}
        QF:StartSession(cycle[QF.db.timeBudget] or 0)
    end)
    self.pauseButton=button(self.options,'Pause',216,-432,104,function()
        QF.sessionPaused=not QF.sessionPaused;QF:RefreshOptions()
    end)
    button(self.options,'Diagnostic',10,-462,150,function()QF:ShowExport(false)end)
    button(self.options,'Rétablir les reports',166,-462,154,function()QF:ClearSkips()end)
    button(self.options,'Marquer une entrée ici',10,-492,200,function()QF:MarkPassage()end)
    button(self.options,'Objets utiles',216,-492,104,function()QF:PrintItems()end)
    button(self.options,'Mon profil',10,-522,150,function()QF:ShowProfile(false)end)
    button(self.options,'Exporter',166,-522,154,function()QF:ShowExport(true)end)
    button(self.options,'Trier les quêtes',10,-550,150,function()QF:ShowCleanup()end)
    self.trainerButton=button(self.options,'Maître',166,-550,154,function()
        local choices={[0]=30,[30]=45,[45]=60,[60]=0};QF.db.trainerDetour=choices[QF.db.trainerDetour] or 45;QF:Optimise()
    end)
    self.providerLabel=text(self.options,-578);self.providerLabel:SetHeight(18)
    self.options:Hide()
    self.skipMenu=panel(nil,f,332,215);self.skipMenu:SetPoint('TOPLEFT',f,'BOTTOMLEFT',0,-5)
    local reasons={{'Trop de monde','crowd'},{'Trop difficile','hard'},{'Trop loin','far'},
      {'Pas envie','unwanted'},{'Groupe indisponible','group'},{'Reporter 30 min','later'},
      {'Mauvais endroit','wrong'},{'Passage impossible','passage'},{'PNJ absent','npc'},{'Continuer ici','continue'}}
    for i,r in ipairs(reasons) do
        local label,key=r[1],r[2]
        button(self.skipMenu,label,10+((i-1)%2)*158,-12-math.floor((i-1)/2)*38,154,function()
            QF:Feedback(key);QF.skipMenu:Hide()
        end)
    end
    self.skipMenu:Hide();self:RefreshOptions();self:CreateNavigation()
    if not self.db.visible then f:Hide() end
end
function QF:ShowExport(observations)
    if not self.exportFrame then
        local f=panel('QuestFlowForeverExport',UIParent,570,430);f:SetPoint('CENTER')
        local scroll=CreateFrame('ScrollFrame',nil,f,'UIPanelScrollFrameTemplate')
        scroll:SetPoint('TOPLEFT',14,-40);scroll:SetSize(520,340)
        local edit=CreateFrame('EditBox',nil,scroll);edit:SetMultiLine(true);edit:SetAutoFocus(false)
        edit:SetFontObject('ChatFontNormal');edit:SetSize(510,340);edit:SetScript('OnEscapePressed',function()f:Hide()end)
        scroll:SetScrollChild(edit);f.edit=edit
        text(f,-12):SetText('Ctrl+A puis Ctrl+C pour copier')
        button(f,'Fermer',420,-392,130,function()f:Hide()end);self.exportFrame=f
    end
    local value=observations and self:MemoryExport() or self:Diagnostic()
    self.exportFrame.edit:SetText(value);self.exportFrame:Show()
end
function QF:RefreshOptions()
    if self.trainerButton then self.trainerButton:SetText(self.db.trainerDetour==0 and "Maître : désactivé" or "Maître : +"..self.db.trainerDetour.." s max") end
    if self.sessionButton then self.sessionButton:SetText('Session : '..(self.db.timeBudget==0 and 'libre' or self.db.timeBudget..' min')) end
    if self.pauseButton then self.pauseButton:SetText(self.sessionPaused and 'Reprendre' or 'Pause') end
    for _,b in ipairs(self.optionButtons or {}) do b:SetText((self.db[b.key] and '[x] ' or '[ ] ')..b.caption) end
    local lib=_G.LibQuestieDB
    local s=lib and lib.ModeIndicator and self.Safe(lib.ModeIndicator.GetStatus) or {}
    if self.providerLabel then self.providerLabel:SetText('QuestieDB : '..tostring(s.expansion or 'absente')..' / '..tostring(s.mode or '?')) end
end
function QF:ToggleSettings() self.options:SetShown(not self.options:IsShown());self.skipMenu:Hide() end
function QF:ToggleSkipMenu() self.skipMenu:SetShown(not self.skipMenu:IsShown());self.options:Hide() end
function QF:UpdateUI()
    if not self.frame then return end
    local a=self.route and self.route[1]
    self.title:SetWidth(212);self.title:SetText('|cff6ee7b7'..self:ActionCategory(a)..'|r')
    self.goal:SetText(a and (verb(a)..' : '..a.title) or 'Aucune destination fiable')
    local detail
    if a then
        detail=a.objectiveText or (a.kind=='pickup' and 'Parle au donneur de quête.' or a.kind=='turnin' and 'Retour au donneur de quête.' or 'Avance les objectifs du journal.')
        if a.remaining then detail=detail..' · '..a.remaining..' restants' end
        if a.state=='potential' then detail=a.kind=='verify' and 'Parle au PNJ pour vérifier son offre.' or '[Expérimental] Disponibilité à confirmer au PNJ.' end
    else
        detail=#(self.unlocated or {})>0 and (#self.unlocated..' quête(s) sans position exploitable : consulte le journal.')
            or ((self.potentialCount or 0)>0 and 'Quêtes Questie à confirmer auprès des PNJ.' or self.discoveryError or 'Ouvre le journal ou parle à un PNJ.')
    end
    local hint=a and self:ExplainAction(a)
    if a and (a.kind=='trainer' or a.kind=='service' or a.kind=='passage') then detail=hint end
    local _,access
    if a then _,access=self:AccessTarget(a) end
    self.detail:SetText(self.stallHint or (a and a.nearbyTurnin and 'Tout près : récupère ta récompense.') or (a and a.kind~='trainer' and access) or detail)
    self.reasonLabel:SetText(self.stallHint or (a and self:ExplainAction(a)) or self.resumeNotice or '')
    local capacity=self:JournalCapacity()
    self.status:SetText(self:Zone()..' · Journal '..#(self.quests or {})..'/'..tostring(capacity or '?')..' · '..self:SessionText())
    local lines={}
    for i=2,math.min(4,#(self.route or {})) do
        local step=self.route[i];lines[#lines+1]=(i-1)..'. '..verb(step)..' : '..step.title
    end
    self.steps:SetText(table.concat(lines,'\n'));self.steps:SetShown(self.db.expanded)
    self.reasonLabel:SetShown(self.db.expanded);self.frame:SetHeight(self.db.expanded and 227 or 126)
    self:RefreshOptions();self:RefreshNavigation()
end

function QF:ShowCleanup()
    self:ReadQuestLog();local rows=self:CleanupCandidates()
    if not self.cleanPanel then
        local f=panel(nil,UIParent,340,165);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG');f:SetClampedToScreen(true)
        text(f,-12):SetText('Tri du journal');f.name=text(f,-40,'GameFontNormal');f.why=text(f,-72);f.why:SetHeight(38)
        f.review=button(f,'Examiner',8,-115,92,function()local id=f.id;if id then f:Hide();QF:ReviewAbandon(id) end end)
        f.keep=button(f,'Conserver',102,-115,88,function()if f.id then QF.db.keepQuests[f.id]=true;QF:ShowCleanup()end end)
        f.next=button(f,'Suivante',192,-115,76,function()QF.cleanIndex=(QF.cleanIndex or 1)+1;QF:ShowCleanup()end)
        button(f,'Fermer',269,-115,64,function()f:Hide()end);self.cleanPanel=f
    end
    local f=self.cleanPanel;self.cleanIndex=#rows>0 and ((self.cleanIndex or 1)-1)%#rows+1 or 1
    local r=rows[self.cleanIndex];f.id=r and r.id
    f.name:SetText(r and (self.cleanIndex..'/'..#rows..' · '..r.title) or 'Aucune quête proposée à l’abandon')
    f.why:SetText(r and r.reason or 'Le guide conserve les quêtes avancées, utiles ou insuffisamment documentées.')
    f.review:SetShown(r~=nil);f.keep:SetShown(r~=nil);f.next:SetShown(#rows>1);f:Show()
end
