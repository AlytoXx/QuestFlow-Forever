## 1.0.0-alpha.6 — Stabilité et remises proches — 5 novembre 2026

- Une quête active terminée peut être rendue même si les filtres métier/groupe/élite sont désactivés. Un report explicite reste respecté.
- Remise prioritaire à moins de 40 yards (environ 37 mètres), même carte, avec approche estimée à 15 secondes maximum. Aucun classement « proche » à partir d'un pourcentage de carte. Les accès incertains ou longs ne sont pas forcés.
- La comparaison des quêtes à prendre précède désormais la protection contre les changements de direction ; le premier objectif imposé reste respecté.
- Les changements de sous-zone sur la même carte et les événements concernant d'autres quêtes ne suppriment plus la protection de la route.
- Une position de camp déjà suivie reste choisie tant qu'elle existe dans les données actuelles du fournisseur. Une position native du jeu reste autoritaire ; pas de verrouillage d'une position inventée.
- Les étapes facultatives ajoutées conservent leur objectif principal ; elles ne viennent plus interrompre une instruction déjà suivie.
- Catégories compactes : Métier (si identifié), À rendre, À prendre, Déplacement (passage/autre zone), Objectif. Bouton Plus tard : report de 30 minutes sans abandon. Optimisation manuelle toujours disponible via /qf opt.
- Dialogue de PNJ : mémorisation temporaire (5 minutes) du lieu d'interaction d'une remise confirmée. Cela aide sans QuestieDB, mais ne détecte pas un PNJ inconnu avant dialogue.
- Diagnostic /qf debug : liste des quêtes terminées, présence d'une position et état de report.
- Le correctif des nombres secrets reste inclus.

Installation : quitter le jeu, remplacer Interface/AddOns/QuestFlowForever par le dossier du ZIP, puis relancer. Conserver les SavedVariables.

Validation hors jeu : syntaxe Lua 5.1 ; tests du solveur (14 scénarios), évolution (29), intégration, boucles, profil, guidage, vitesses protégées simulées, import de données et nouvelles régressions de stabilité/remises. Tous réussis. Aucun test sur le client Forever réel ; aucun gain d'XP mesuré annoncé. La priorité de remise nécessite un état terminé et une position exploitable. Les métiers non identifiés faute de données ne sont pas devinés. L'apprentissage par type d'objectif et la comparaison avancée de camps restent à faire.

## 1.0.0-alpha.5-hotfix.1 — 5 novembre 2026

Correction des lectures de vitesse protégée (secret number) dans la navigation, les temps de trajet, l’apprentissage et la détection de blocage. Vérification avant comparaison ; valeur de secours 7 yards/s pour les estimations uniquement. Une vitesse indisponible ne prouve pas que le personnage se déplace. Orientation protégée : flèche masquée temporairement. Aucun contournement des restrictions du client.

Validation : syntaxe Lua 5.1, tests intégration/navigation/évolution/boucles/profil et nouveau test avec API simulées réussis. Les vrais nombres secrets du client ne sont pas reproductibles dans Lua standard : validation en jeu encore nécessaire. Les nouvelles optimisations des camps ne sont pas incluses dans ce correctif.

Installation : quitter le jeu, remplacer le dossier Interface/AddOns/QuestFlowForever par celui de cette archive, puis relancer. Conserver les SavedVariables.

# QuestFlow Forever — 1.0.0-alpha.5

Cette version ajoute la gestion des sessions, la vérification prudente des offres sur le passage, une mémoire des erreurs, des trajets observés et des services utiles. **Elle reste une alpha : aucun essai dans le client Forever n'a pu être effectué ici.** Les comportements ont été testés en Lua 5.1 avec des API simulées.

## Boucles de quêtes et accès
Le calcul inclut les segments disponibles jusqu’à l’objectif et la sortie vers la suite de la boucle. Deux objectifs partageant un passage réutilisent la partie commune. Un terrain difficile signalé sans chemin connu reçoit une marge heuristique de 60 secondes, qui représente une incertitude et non une durée mesurée.

Pour chaque offre exploitable, le moteur compare son insertion ou son retrait dans l’ordre de visite retenu. Il rejoue les dépendances, la capacité du journal, le budget de session et les crédits partagés. L’insertion recherche des positions à faible détour dans la boucle existante. Cette recherche locale dépend des données et ne garantit pas un optimum global. L’XP et les coûts restent des estimations. Test dédié : `python tests/test_loop.py`.

## Profil au premier lancement

Le premier écran détecte la classe. Choisis le détour maximal pour un maître et le mode des quêtes de métier. Garde la détection automatique ou coche les métiers à suivre, y compris ceux que tu prévois d’apprendre. Une sélection personnelle n’accorde pas le métier au personnage. « Enregistrer mon profil » ou « Garder mes réglages » termine la configuration pour ce personnage. `/qf profil` et Options → Mon profil permettent de la rouvrir. Les autres personnages ont leur propre profil.

« Indiquer un maître connu » est facultatif. Saisis X et Y sur la carte actuelle, avec éventuellement l’ID d’un sort de classe à vérifier. Pour un maître de métier déclaré, le guide peut proposer de vérifier le prochain rang lorsque le métier appris est à cinq points ou moins de son plafond connu. Les points déclarés servent à vérifier une possibilité, sans preuve de disponibilité. Les haltes respectent le seuil de détour choisi et la limite d’aller de 90 secondes. Un point de classe seul ne prouve pas qu’un sort y est disponible. La visite d’un maître permet toujours de mémoriser son catalogue observable.

## Flèche, relief, maître et tri du journal

Le panneau replié mesure 264 × 126 et la flèche 160 × 54 (échelle 100 %). Le sens est calculé par rapport à l’orientation du personnage. La flèche tourne par l’angle le plus court et disparaît sur place ou sans coordonnées mondiales fiables. `+` dévoile les détails. Si tu avais activé `/qf sens` comme contournement sur l’alpha.2, restaure le réglage normal au premier essai.

La ligne d’accès distingue une indication explicite de l’objectif, un passage identifié et un détour estimé. Une entrée déjà enregistrée sert de première destination. La bibliothèque optionnelle LibQuestDB-1.0, si elle fournit une approche exploitable pour le point précis, permet de suivre ses points dans l’ordre. Un accès balisé peut aussi correspondre à un chemin extérieur. Une grotte identifiée sans entrée fiable affiche « entrée inconnue ». `/qf grotte`, `/qf montagne` et `/qf detour` marquent ou démarquent l’étape actuelle. À une entrée connue, utilise `/qf passage`. Le relief inconnu demande toujours une information du jeu, du joueur ou d’une source compatible.

Le guide mémorise les sorts prioritaires proposés par les maîtres rencontrés pour ton personnage. Pour un chasseur, la sélection initiale comprend Tir des arcanes, Trait de choc et Aspect du faucon. `/qf sort 123` ajoute ou retire l’identifiant 123 des priorités personnelles. Le niveau, la disponibilité et le prix viennent du formateur lorsque son interface les expose. Une offre vue avant d’avoir le niveau sera indiquée « Vérifier ». Les rangs supplémentaires nécessitent un identifiant distinct vérifiable. Le bouton Maître dans Options règle le détour ajouté maximal estimé (30, 45 ou 60 secondes, ou désactivé). Le défaut est 45 secondes, avec un aller de 90 secondes maximum, sur la même carte. Une quête presque finie reste prioritaire. L’apprentissage du sort se fait chez le PNJ.

`/qf tri` ou **Options → Trier les quêtes** propose les anciennes quêtes solo documentées, sans progression et avec au moins huit niveaux d’écart. Les quêtes de classe, de métier, de groupe, avancées, avec objet ou suite connue sont écartées du tri. « Conserver » protège une quête pour les prochains tris. « Examiner » montre une quête à la fois. Si les API le permettent, le bouton final « Abandonner » demande confirmation et le guide revérifie la sélection et les critères juste avant l’abandon. Sinon, termine l’action dans le journal du jeu. Une suite absente des données Forever peut rester inconnue : lis la quête avant de confirmer.

## Installer la mise à jour

1. Fermer WoW et garder une copie de l'ancien dossier QuestFlowForever.
2. Remplacer ce dossier par **QuestFlowForever** contenu dans le ZIP, dans `Interface/AddOns/` du client Forever.
3. Garder QuestFlowTBC désactivé. Activer les versions Forever de Questie et QuestieDB pour enrichir les positions.
4. Entrer en jeu et taper `/qf opt`.

Le fichier `QuestFlowForever.toc` doit être directement dans `Interface/AddOns/QuestFlowForever/`. Les dossiers `tests` et `tools` du ZIP ne vont pas dans AddOns. Les sauvegardes alpha.1 sont conservées et enrichies automatiquement. Aucun abonnement, réseau ou synchronisation externe dans l'addon.

Le TOC reste **16001**, relevé dans Questie Forever. Le diagnostic affiche le numéro réellement détecté chez vous. Le fournisseur de données doit annoncer Forever et accepter le contrat 4 ; les coordonnées TBC/Era ne servent pas de remplacement silencieux.

## Les nouveautés utilisables

| Fonction | Comportement |
|---|---|
| Session | Options : 15, 30, 60, 90 minutes ou libre. Le temps hors ligne et les pauses explicites/AFK ne sont pas décomptés. |
| Reprise | Le temps restant est sauvegardé ; journal, disponibilités et position sont relus. Une ancienne route n'est pas exécutée aveuglément. |
| Durée souple | Le calcul privilégie le budget disponible ; autorise une petite marge pour rendre. Si aucune action n'entre dans le budget, il propose une étape en précisant le dépassement estimé. À zéro, le guide continue en durée libre jusqu'au prochain choix. |
| Vérifier une offre | En mode prudent, un PNJ peut être proposé avec « Vérifier », sans action « Prendre » supposée. Seulement petit détour, proximité du trajet, objectifs compatibles connus et place disponible. |
| PNJ sans offre | Suppression temporaire uniquement après dialogue complet et identification du bon PNJ. Une erreur API ou un PNJ voisin ne constitue pas une preuve d'absence. |
| Corrections | Changer : mauvais endroit, passage impossible, PNJ absent. Le problème visé est écarté temporairement ; la quête reste dans le journal. |
| Blocage possible | Après au moins trois minutes d'activité près d'un objectif sans progression, propose de continuer ou changer. Pas de question automatique répétée, pas de conclusion « zone bondée » inventée. |
| Difficulté | Un signalement accroît légèrement et temporairement le coût de cette quête ; pas de changement définitif sur une seule mauvaise rencontre. |
| Entrées/passages | À une entrée réellement connue, « Marquer une entrée ici » l'associe à l'objectif actuel. La prochaine approche vise ce passage avant l'objectif. |
| Temps de trajet | Utilise la médiane après trois observations compatibles, sans combat, pause, taxi ou mort détectés. Les grands détours sont rejetés. |
| Changement de zone | Utilise des transitions courtes observées au moins deux fois, dans le sens observé, ou un pack local relu. Les transitions inconnues ne sont pas inventées. |
| Services | Marchands/réparateurs mémorisés quand vous les ouvrez. Un arrêt est proposé sur le trajet en cas de sacs presque pleins ou d'équipement très usé ; aucune vente/réparation automatique. |
| Objets utiles | Liste `/qf objets` et annotation d'infobulle si l'API le permet : objets identifiés pour des quêtes acceptées. Aucune recommandation spéculative de stockage. |
| Chaînes | Petit bonus d'utilité pour une suite documentée après contrôle des prérequis simples et exclusions. La suite ne devient jamais une offre confirmée par simulation. |
| Objectifs partagés | Déduplication limitée aux paires de quêtes acceptées visant le même monstre, avec au moins trois progressions simultanées concordantes observées. |
| Mise à jour du jeu | Les anciennes observations sont conservées, mais les trajets et passages d'une autre empreinte client/base ne sont plus utilisés automatiquement. |
| Export/import local | Diagnostic et observations copiables ; outils hors jeu pour préparer puis valider un pack de passages/transitions. Rien n'est envoyé automatiquement. |

Les insertions de PNJ/services ont un coût supplémentaire borné mais ne constituent pas une preuve d'optimalité. Les autres étapes affichées restent des prévisions, revalidées lorsque le journal change.

## Commandes et interface

- `/qf` : afficher/masquer le panneau ; `/qf opt` : recalculer.
- `/qf session 30` : démarrer une session de 30 minutes ; `0` = libre. Choix également dans Options.
- `/qf pause` : mettre en pause/reprendre le décompte de session.
- `/qf changer` : corrections et reports ; `/qf reset` : rétablir les reports et corrections temporaires.
- `/qf passage` : enregistrer l'entrée où vous êtes pour l'objectif sélectionné. À utiliser seulement lorsque vous connaissez réellement le passage.
- `/qf objets` : objets à conserver identifiés ; `/qf export` : observations copiables.
- `/qf debug` : diagnostic dans le chat. Le bouton Diagnostic affiche une fenêtre copiable.
- `/qf sens` : inverser le signe de la flèche pour le test dans le client ; `/qf map` : waypoint TomTom si installé.
- Ctrl + molette sur le panneau : taille. Glisser : position. `+` : trois prochaines étapes.

Dans Changer, « Continuer ici » coupe la suggestion de blocage pendant dix minutes. Les reports expirent après 30 ou 60 minutes, sauf « Pas envie » qui reste jusqu'au rétablissement manuel. Les corrections de position/passage expirent après 30 minutes. Une offre absente observée expire après dix minutes ; un signalement manuel de PNJ absent après quinze minutes.

## Ce qui reste limité

- **Pas de couverture exhaustive des quêtes Forever.** Une quête inconnue est enregistrée sans inventer sa destination.
- **Pas de pathfinding général.** Sur une même carte, le calcul reste une distance directe majorée lorsqu'aucun trajet compatible n'a été observé. Les obstacles non connus restent possibles. L'affichage en mètres indique une distance à vol d'oiseau.
- **Pas de réseau complet de transports.** Taxis, bateaux, téléportations, foyer et death skips ne sont pas planifiés automatiquement. Les grandes ruptures de position sont rejetées pour ne pas apprendre un faux passage.
- **Pas de stratégie mondiale de leveling.** Le changement de zone compare les objectifs connus et les transitions disponibles, sans analyser toutes les zones/quêtes du jeu. Une relation de zone sans coordonnées exploitable ne suffit pas.
- **Chaînes : anticipation limitée**, pas parcours complet des futures chaînes. Les conditions complexes non vérifiées désactivent le bonus ; classe, métier et faction ne sont pas devinés.
- **Métiers/donjons : filtres et estimations**, pas préparation exhaustive. « Groupe prêt » reste votre choix explicite. Les maîtres de classe sont proposés à partir de leur catalogue observé. Les achats de consommables et déblocages personnalisés non documentés restent hors parcours.
- **Services : observations locales** à l'ouverture du marchand, pas une base mondiale de services. Pas d'abandon automatique et pas de recommandation d'abandon potentiellement nuisible.
- **Objets : uniquement besoins identifiés du journal.** Pas d'inventaire complet des futurs besoins ; aucune action sur les objets. Les quantités de plusieurs quêtes ne sont pas additionnées sans savoir si elles partagent les mêmes objets.
- **Apprentissage conservateur** : il peut ne rien apprendre lorsque le client n'expose pas les identifiants ou coordonnées requis. La mesure d'activité reste un proxy, pas un chronométrage exact des combats.
- **Flèche, infobulles, affichage et FPS non validés dans le client.** Les mocks contrôlent les appels et la logique, pas le rendu du jeu ni ses restrictions réelles.

## Premier test en jeu

1. `/qf debug` : vérifier le client et QuestieDB Forever. Conserver le texte si problème.
2. Choisir une session de 30 min, fermer/reconnecter : le temps hors ligne ne doit pas être retranché, et la quête courante doit être relue.
3. Tester un PNJ offrant plusieurs quêtes ; vérifier la distinction « Vérifier » / « Prendre » et l'actualisation après acceptation.
4. Faire avancer une quête, rendre, puis changer de zone. Les anciennes destinations doivent disparaître.
5. Tourner dans les quatre directions pour vérifier la flèche. Une flèche qui pivote correctement dans les tests mathématiques peut encore nécessiter `/qf sens` dans le client.
6. Tester un report et son rétablissement. Les quêtes ne doivent jamais être abandonnées.
7. Facultatif : marquer une entrée connue et vérifier qu'elle est proposée lors d'une nouvelle approche.

Pour les erreurs Lua : `/console scriptErrors 1`, puis `/reload`. Fournir l'erreur, `/qf debug`, la quête et l'action qui a déclenché le problème. Ne pas partager tout le dossier WTF.

## Tests reproductibles

```sh
python -m pip install -r tests/requirements.txt
python tests/run_tests.py
python tests/test_integration.py
python tests/test_evolution.py
python tests/test_guidance_review.py
python tests/test_pack.py
python tests/benchmark_evolution.py
```

Voir `VALIDATION.md` et les trois fichiers de résultats JSON. Les tests exécutent les modules Lua livrés, sous Lua 5.1. La comparaison à alpha.1 utilise une copie de son solveur, à travail et XP identiques sur six cartes synthétiques. Elle n'est pas un gain de temps mesuré dans WoW.

## Données locales optionnelles

L'usage normal ne demande pas de manipuler de fichiers de données. Pour une correction avancée ou un partage volontaire :

1. `/qf export`, copier le contenu dans `observations.tsv`.
2. `python tools/observations_to_pack.py observations.tsv brouillon.json`.
3. Relire les coordonnées, la provenance et les transitions. Le brouillon porte `reviewed: false`. Ne mettre `true` qu'après vérification ; corriger aussi la provenance si nécessaire.
4. `python tools/build_data_pack.py brouillon.json DataPack.lua`.
5. Fermer le jeu et remplacer le `DataPack.lua` de QuestFlowForever, puis relancer.

L'import exige la même empreinte client/base et valide tous les enregistrements avant application. Il est appliqué une seule fois par provenance/révision. Il ne donne aucune disponibilité de quête et ne peut pas importer du code via JSON. Un fichier Lua obtenu ailleurs reste du code : utiliser le générateur fourni à partir de données relues. Une déclaration de provenance ne prouve pas qu'une donnée est correcte.

## Sources de compatibilité

Consultées le 4 novembre 2026 ; vérifier le client réel avec le diagnostic :

- [Questie TOC Forever](https://github.com/Questie/Questie/blob/master/Questie_Forever.toc)
- [Adaptateurs Questie](https://github.com/Questie/Questie/blob/master/Modules/QuestieCompat.lua)
- [Liste des offres Questie, interne et optionnelle](https://github.com/Questie/Questie/blob/master/Modules/Quest/AvailableQuests/AvailableQuests.lua)
- [API QuestieDB](https://github.com/Questie/QuestieDB/blob/master/docs/api.md)
- [Données Forever et lacunes connues](https://github.com/Questie/QuestieDB/blob/master/docs/forever.md)
- [Schéma de quêtes consommé par Questie](https://github.com/Questie/Questie/blob/master/Database/QuestieDB.lua)
- [Documentation générée des sacs, miroir du code UI Blizzard](https://github.com/Gethe/wow-ui-source/blob/live/Interface/AddOns/Blizzard_APIDocumentationGenerated/ContainerDocumentation.lua) : documentation d'une autre branche, utilisée comme référence de signatures et non comme preuve de disponibilité Forever.

Questie/QuestieDB ne sont pas inclus. Aucun code, contenu ou parcours RestedXP. Licence GPL-3.0-or-later du projet d'origine conservée.
