## 1.0.0-alpha.6 — Stabilité et remises proches — 5 novembre 2026

- Une quête active terminée peut être rendue même si les filtres métier/groupe/élite sont désactivés. Un report explicite reste respecté.
- Remise prioritaire à moins de 40 yards (environ 37 mètres), même carte, avec approche estimée à 15 secondes maximum. Aucun classement « proche » à partir d'un pourcentage de carte. Les accès incertains ou longs ne sont pas forcés.
- La comparaison des quêtes à prendre précède désormais la protection contre les changements de direction ; le premier objectif imposé reste respecté.
- Les changements de sous-zone sur la même carte et les événements concernant d'autres quêtes ne suppriment plus la protection de la route.
- Une position de camp déjà suivie reste choisie tant qu'elle existe dans les données actuelles du fournisseur. Une position native du jeu reste autoritaire ; pas de verrouillage d'une position inventée.
- Les étapes facultatives ajoutées conservent leur objectif principal ; elles ne viennent plus interrompre une instruction déjà suivie.
- Catégories compactes : Métier (si identifié), À rendre, À prendre, Déplacement (passage/autre zone), Objectif. Bouton Plus tard : report de 30 minutes sans abandon. Optimisation manuelle toujours disponible via /qf opt.
- Dialogue de PNJ : mémorisation temporaire (5 minutes) du lieu d'interaction d'une remise confirmée. Cela aide sans QuestieDB, mais ne détecte pas un PNJ inconnu avant dialogue.
- Diagnostic /qf debug : liste des quêtes terminées, présence d'une position et état de report.
- Le correctif des nombres secrets reste inclus.

Installation : quitter le jeu, remplacer Interface/AddOns/QuestFlowForever par le dossier du ZIP, puis relancer. Conserver les SavedVariables.

Validation hors jeu : syntaxe Lua 5.1 ; tests du solveur (14 scénarios), évolution (29), intégration, boucles, profil, guidage, vitesses protégées simulées, import de données et nouvelles régressions de stabilité/remises. Tous réussis. Aucun test sur le client Forever réel ; aucun gain d'XP mesuré annoncé. La priorité de remise nécessite un état terminé et une position exploitable. Les métiers non identifiés faute de données ne sont pas devinés. L'apprentissage par type d'objectif et la comparaison avancée de camps restent à faire.

## 1.0.0-alpha.5-hotfix.1 — 5 novembre 2026

Correction des lectures de vitesse protégée (secret number) dans la navigation, les temps de trajet, l’apprentissage et la détection de blocage. Vérification avant comparaison ; valeur de secours 7 yards/s pour les estimations uniquement. Une vitesse indisponible ne prouve pas que le personnage se déplace. Orientation protégée : flèche masquée temporairement. Aucun contournement des restrictions du client.

Validation : syntaxe Lua 5.1, tests intégration/navigation/évolution/boucles/profil et nouveau test avec API simulées réussis. Les vrais nombres secrets du client ne sont pas reproductibles dans Lua standard : validation en jeu encore nécessaire. Les nouvelles optimisations des camps ne sont pas incluses dans ce correctif.

Installation : quitter le jeu, remplacer le dossier Interface/AddOns/QuestFlowForever par celui de cette archive, puis relancer. Conserver les SavedVariables.

Alpha.5 — tests hors jeu de l’entrée, de la sortie, du passage partagé et de l’ajout ou du retrait de quêtes selon leur coût. Aucun gain de temps mesuré en jeu.

# Alpha.4

Le test `python tests/test_profile.py` vérifie la présentation initiale, la persistance par personnage, le changement de sélection, les coordonnées invalides, le respect du détour et la distinction entre métier souhaité et métier appris. Tests réalisés hors jeu.

# Alpha.3

Tests Lua hors jeu réussis : directions cardinales avec deux orientations du joueur, stabilité à l’arrivée, absence de coordonnées, grotte sans entrée, approche balisée, montagne, détour, formateur connu/lointain, budget insuffisant, sort déjà appris et annulation d’un abandon après changement de sélection ou progression. Le panneau, le sens de la texture et les API d’abandon/formation restent à valider sur le client du joueur. Les 14 scénarios du moteur et les 29 scénarios de l’alpha.2 ont aussi été rejoués.

# Validation de QuestFlow Forever alpha.2

Les 14 scénarios du moteur et les 29 scénarios d’évolution passent sous Lua 5.1. Les tests d’intégration chargent les modules dans l’ordre du TOC avec des API de jeu simulées. Les tests de pack vérifient la validation des données, la copie des observations et leur relecture.

## Recalcul sur six cartes synthétiques

Chaque stratégie exécute une action puis recalcule le parcours. Toutes finissent les mêmes actions et obtiennent la même XP pour une carte donnée. Le tableau donne le temps simulé en secondes.

| Carte | Alpha.1 | Alpha.2 | Ordre fixe | Proximité | Récompense |
|---|---:|---:|---:|---:|---:|
| 1 | 1863.4 | 1863.4 | 3169.9 | 1785.3 | 2646.8 |
| 2 | 2004.9 | 2004.9 | 3416.3 | 1745.3 | 2145.4 |
| 3 | 1744.2 | 1744.2 | 3331.6 | 1589.0 | 2726.2 |
| 4 | 1396.2 | 1396.2 | 3114.5 | 1242.7 | 2559.5 |
| 5 | 1093.9 | 1093.9 | 2897.0 | 1170.2 | 2129.9 |
| 6 | 1933.3 | 1933.3 | 3355.1 | 1577.4 | 2654.7 |

Les deux versions obtiennent le même temps sur ces six cartes. Ces scénarios mesurent le coût des parcours sur des données identiques. Les nouveaux comportements de reprise, de vérification d’offres et d’apprentissage sont exercés séparément. Les performances réelles, la rotation de la flèche et les disponibilités des API restent à vérifier dans le client Forever.

## Scénarios d’évolution

- session reprise hors ligne/pause — OK
- budget souple — OK
- absence PNJ confirmée — OK
- PNJ différent — OK
- vérification sur trajet — OK
- correction locale — OK
- blocage actif et pause — OK
- AFK — OK
- sacs et détour marchand — OK
- réparation pertinente — OK
- objets vérifiés — OK
- entrée manuelle — OK
- transition dirigée observée — OK
- nouvelle version des données — OK
- temps robustes — OK
- import atomique — OK
- export copiable — OK
- chaîne prérequis — OK
- chaîne exclusion — OK
- calculs annulés — OK
- offre périmée — OK
- difficulté temporaire — OK
- navigation interzone connue — OK
- session libre — OK
- objectifs partagés prouvés — OK
- apprentissage excluant les pauses — OK
- passage impossible — OK
- trajets observés hors combat — OK
- transitions observées sans téléportation — OK

Les résultats détaillés et les commandes de reproduction figurent dans les fichiers JSON et le README.
