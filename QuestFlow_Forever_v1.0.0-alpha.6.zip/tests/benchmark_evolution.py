"""Equal-work, rolling replanning benchmark. Synthetic maps; no game performance claims."""
from pathlib import Path
import random,json,time
from lupa.lua51 import LuaRuntime
ROOT=Path(__file__).resolve().parents[1]
ADDON=ROOT/'deliverable'/'QuestFlowForever'
if not ADDON.exists():ADDON=ROOT/'QuestFlowForever'
lua=LuaRuntime(unpack_returned_tuples=True)
a=lua.table();b=lua.table()
lua.execute((ADDON/'Optimizer.lua').read_text(),'test',a)
lua.execute((ADDON.parent/'tests/optimizer_alpha1.lua').read_text(),'test',b)
lua.execute('''
function runReplay(O,input,slots,mode)
 local actions={};for _,a in ipairs(input)do actions[#actions+1]=a end
 local state={used={},seq={},where={map=1,x=0,y=0},seconds=0,travel=0,xp=0,utility=0,credit=0,slots=slots,tie=''}
 local function travel(a,b)return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2)end
 local loops=0
 while #actions>0 do
  local selected
  if mode=='solver' then
   local plan=O.Solve(actions,state.where,{slots=state.slots,capacity=20,travel=travel,width=12,horizon=90})
   selected=plan.seq[1]
  else
   local score
   for i,a in ipairs(actions)do
    if O.Eligible(a,{used={},slots=state.slots},20)then
     local value=mode=='fixed' and -i or mode=='nearest' and -travel(state.where,a.point) or (a.xp+a.credit)
     if not score or value>score then score=value;selected=a end
    end
   end
  end
  if not selected then break end
  state=O.Step(selected,state,travel);loops=loops+1;assert(loops<=200)
  local remaining={}
  for _,a in ipairs(actions)do
   if a.key~=selected.key then
    local deps={};for _,key in ipairs(a.requires)do if key~=selected.key then deps[#deps+1]=key end end
    local copy={};for k,v in pairs(a)do copy[k]=v end;copy.requires=deps;remaining[#remaining+1]=copy
   end
  end
  actions=remaining
 end
 return {seconds=state.seconds,travel=state.travel,xp=state.xp,actions=#state.seq,remaining=#actions}
end
''')
results=[]
for seed in range(1,7):
    rng=random.Random(seed);actions=[];slots=0
    for qid in range(1,9):
        pickup=qid>5
        if not pickup:slots+=1
        x,y=rng.choice([50,150,250]),rng.choice([-50,0,50]);xp=rng.choice([100,150,300]);work=rng.choice([20,60,180]);hub=rng.choice([0,10])
        def action(kind,pos,seconds,deps,reward,credit):
            return {'key':f'{qid}:{kind}','id':qid,'kind':kind,'point':{'map':1,'x':pos[0],'y':pos[1]},'seconds':seconds,'requires':deps,'xp':reward,'credit':credit}
        if pickup:actions.append(action('pickup',(hub,0),8,[],0,xp*.1))
        actions.append(action('work',(x,y),work,[f'{qid}:pickup'] if pickup else [],0,xp*(.65 if pickup else .75)))
        actions.append(action('turnin',(hub,0),10,[f'{qid}:work'],xp,-xp*.75))
    row={'seed':seed,'metrics':{}}
    for name,O,mode in [('alpha1',b.Optimizer,'solver'),('alpha2',a.Optimizer,'solver'),('fixed',a.Optimizer,'fixed'),('nearest',a.Optimizer,'nearest'),('reward',a.Optimizer,'reward')]:
        start=time.perf_counter();result=lua.globals().runReplay(O,lua.table_from(actions,recursive=True),slots,mode)
        row['metrics'][name]={k:round(v,3) for k,v in result.items()};row['metrics'][name]['runtime_ms']=round((time.perf_counter()-start)*1000,2)
        assert result.remaining==0
    assert len({v['xp'] for v in row['metrics'].values()})==1
    results.append(row)
    print('seed',seed,'alpha1',round(row['metrics']['alpha1']['seconds'],1),'alpha2',round(row['metrics']['alpha2']['seconds'],1))
(ROOT/'BENCHMARK_RESULTS.json').write_text(json.dumps(results,indent=2))
