from pathlib import Path
from lupa.lua51 import LuaRuntime
import json,time
ROOT=Path(__file__).resolve().parents[1]
ADDON=ROOT/'deliverable'/'QuestFlowForever'
if not ADDON.exists(): ADDON=ROOT/'QuestFlowForever'
lua=LuaRuntime(unpack_returned_tuples=True)
q=lua.table()
for p in ADDON.glob('*.lua'):
    lua.execute('assert(loadstring(...))',p.read_text())
print('Syntaxe Lua 5.1 : OK')
lua.execute((ADDON/'Optimizer.lua').read_text(),'QuestFlowForever',q)
lua.globals().Q=q
lua.execute(r'''
local O=Q.Optimizer
function point(x,y,map) return {x=x,y=y or 0,map=map or 1} end
function travel(a,b) if a.map~=b.map then return nil end return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2) end
function options(slots,cap) return {width=12,horizon=90,slots=slots or 0,capacity=cap,travel=travel} end
function task(id,kind,x,req,xp,credit)
 return {key=tostring(id)..':'..kind,id=id,kind=kind,point=point(x),seconds=kind=='work' and 24 or 8,requires=req or {},xp=xp or 0,credit=credit or 0}
end
function chain(id,x,accepted,xp)
 local w=tostring(id)..':work';local p=tostring(id)..':pickup'
 local list={}
 if not accepted then list[#list+1]=task(id,'pickup',0,{},0,(xp or 100)*.10) end
 list[#list+1]=task(id,'work',x,accepted and {} or {p},0,(xp or 100)*(accepted and .75 or .65))
 list[#list+1]=task(id,'turnin',0,{w},xp or 100,-(xp or 100)*.75)
 return list
end
function add(a,b) for _,v in ipairs(b) do a[#a+1]=v end return a end
function validate(r,slots,cap)
 local used={};local xp=0
 for _,a in ipairs(r.seq) do
  assert(not used[a.key],'duplicate action')
  for _,dep in ipairs(a.requires) do assert(used[dep],'dependency violated '..dep) end
  assert(O.Eligible(a,{used=used,slots=slots},cap),'ineligible action')
  used[a.key]=true
  if a.kind=='pickup' then slots=slots+1 elseif a.kind=='turnin' then slots=slots-1 end
  assert(slots>=0,'negative slots')
  if cap then assert(slots<=cap,'capacity exceeded') end
  xp=xp+a.xp
 end
 assert(math.abs(xp-r.xp)<.0001,'XP counted twice')
 return used
end
function solve(a,slots,cap)
 local r=O.Solve(a,point(0),options(slots,cap));validate(r,slots or 0,cap);return r
end
function baseline(a,slots,cap,mode)
 local s={used={},seq={},where=point(0),seconds=0,travel=0,xp=0,utility=0,credit=0,slots=slots,tie=''}
 while true do
  local chosen,score
  for i,v in ipairs(a) do
   if O.Eligible(v,s,cap) then
    local dt=travel(s.where,v.point)
    if dt then
     local rank=mode=='fixed' and -i or mode=='nearest' and -dt or (v.xp+v.credit)
     if not chosen or rank>score then chosen=v;score=rank end
    end
   end
  end
  if not chosen then break end
  s=O.Step(chosen,s,travel)
 end
 validate(s,slots,cap);return s
end
function runScenario(n)
 local a,r
 if n==1 then
  a={};for id=1,12 do add(a,chain(id,100+id,true)) end
  r=solve(a,12,20);assert(#r.seq==24);assert(r.xp==1200)
 elseif n==2 then
  a={};for id=1,18 do add(a,chain(id,100+(id%2)*10,id<=12)) end
  r=solve(a,12,20);assert(#r.seq==42);assert(r.xp==1800)
  local firstWork=100;local pickups=0
  for i,v in ipairs(r.seq) do if v.kind=='work' then firstWork=i;break end end
  for i=1,firstWork-1 do if r.seq[i].kind=='pickup' then pickups=pickups+1 end end
  assert(pickups==6,'must batch all six village offers')
 elseif n==3 then
  a=chain(1,100,true);add(a,chain(2,100,false));a[3].point=point(40)
  r=solve(a,1,20);assert(r.seq[1].key=='2:pickup','useful en-route pickup')
 elseif n==4 then
  a=chain(1,2,true);a[1].seconds=2;add(a,chain(2,200,true))
  r=solve(a,2,20);assert(r.seq[1].id==1)
 elseif n==5 then
  a=chain(1,10,false);a[1].blocked=true;r=solve(a,0,20);assert(#r.seq==0)
 elseif n==6 then
  a={task(999999,'work',4,{},0,20)};r=solve(a,1,20);assert(#r.seq==1 and r.xp==0)
 elseif n==7 then
  a=chain(1,10,false);a[3].utility=100;r=solve(a,0,20);assert(r.utility==100)
 elseif n==8 then
  a=chain(1,10,true);a[1].seconds=900;r=solve(a,1,20)
  local slow=r.seconds;a[1].seconds=540;r=solve(a,1,20);assert(r.seconds==slow-360)
 elseif n==9 then
  a=chain(1,10,true,10);add(a,chain(2,15,false,500));a[3].requires={'1:turnin'}
  r=solve(a,1,20);assert(r.xp==510)
 elseif n==10 then
  a=chain(1,10,true);for _,v in ipairs(a) do v.point.map=2 end
  r=solve(a,1,20);assert(#r.seq==0)
 elseif n==11 then
  a={task(1,'turnin',0,{},100)};add(a,chain(2,20,false));r=solve(a,20,20)
  assert(r.seq[1].kind=='turnin');assert(#solve(chain(3,10,false),20,20).seq==0)
 elseif n==12 then
  a={};for id=1,6 do add(a,chain(id,100,true)) end
  r=solve(a,6,20);assert(r.travel==200,'shared hub loop');assert(r.xp==600)
 elseif n==13 then
  a=chain(1,10,true);for _,v in ipairs(a) do v.blocked=true end
  add(a,chain(2,20,true));r=solve(a,2,20);assert(#r.seq==2 and r.seq[1].id==2)
 elseif n==14 then
  local current={seq={1},xp=100,utility=0,credit=0,seconds=100}
  local best={seq={2},xp=110,utility=0,credit=0,seconds=100}
  assert(O.KeepCurrent(best,current,100,0,false));best.xp=150
  assert(not O.KeepCurrent(best,current,100,0,false));assert(O.KeepCurrent(best,current,10,0,false))
  a=chain(1,10,true);r=solve(a,1,20)
 end
 local metrics={}
 if a then
  for _,mode in ipairs({'fixed','nearest','reward'}) do
   local slots=0;local seen={}
   for _,v in ipairs(a) do if v.kind=='pickup' then seen[v.id]=true end end
   local ids={};for _,v in ipairs(a) do ids[v.id]=true end
   for id in pairs(ids) do if not seen[id] then slots=slots+1 end end
   if n==11 then slots=20 end
   local b=baseline(a,slots,20,mode)
   metrics[mode]={seconds=b.seconds,travel=b.travel,xp=b.xp,steps=#b.seq}
  end
 end
 metrics.qdro={seconds=r.seconds,travel=r.travel,xp=r.xp,steps=#r.seq}
 return metrics
end
''')
names=['12 quêtes acceptées','6 offres au village','détour utile','presque terminée','événement bloqué','quête inconnue','métier utile','groupe prêt','chaîne conditionnelle','changement de zone','journal plein','secteur commun','zone bondée','anti-oscillation']
reports=[]
for i,name in enumerate(names,1):
    t=time.perf_counter(); result=lua.globals().runScenario(i)
    metrics={k:{kk:vv for kk,vv in v.items()} for k,v in result.items()}
    reports.append({'scenario':name,'status':'PASS','runtime_ms':round((time.perf_counter()-t)*1000,2),'metrics':metrics})
    print(f'{i:02} PASS {name}: {metrics["qdro"]}')
# Extra solver safety invariants
lua.execute('assert(#solve(chain(2,10,false),0,nil).seq==0)')
lua.execute("local a=chain(1,10,false);a[1].requires={'missing'};assert(#solve(a,0,20).seq==0)")
(ROOT/'TEST_RESULTS.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2))
print('14 scénarios + capacité inconnue + dépendance manquante : OK')
