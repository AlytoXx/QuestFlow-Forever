"""Behavioral regressions for alpha.2, running the shipped Lua modules."""
from pathlib import Path
import runpy,json,time,importlib.util
ROOT=Path(__file__).resolve().parents[1]
ADDON=ROOT/'deliverable'/'QuestFlowForever'
if not ADDON.exists(): ADDON=ROOT/'QuestFlowForever'
env=runpy.run_path(str(Path(__file__).with_name('test_integration.py')))
l=env['l']
l.execute(r'''
function resetEvolution()
 clock=1000;map=1;timers={};player={map=1,x=10,y=10};afk=false;dead=false;combat=false;speed=7;taxi=false
 GetUnitSpeed=function()return speed end
 UnitIsAFK=function()return afk end
 UnitIsDeadOrGhost=function()return dead end
 UnitAffectingCombat=function()return combat end
 UnitOnTaxi=function()return taxi end
 UnitGUID=function()return 'Creature-0-0-0-0-12-0000' end
 Q.PlayerPoint=function()return Q.Copy(player)end
 Q.PlayerPosition=function()return player.x,player.y end
 Constants={QuestLogConsts={MAXIMUM_NUM_QUESTS_LOG_CAN_ACCEPT=20}}
 C_QuestLog.GetQuestsOnMap=function()return {{questID=999999,x=.2,y=.2}}end
 C_QuestLog.GetQuestObjectives=function()return {{text='Mobs',type='monster',numRequired=10,numFulfilled=2,finished=false}}end
 C_GossipInfo={};QuestieLoader=nil;C_Container=nil;GetInventoryItemDurability=nil
 LibQuestieDB=nil;QuestFlowForeverDB={};Q.DataPack=nil;Q:InitSettings()
 Q.route={};Q.discovery={};Q.quests={};Q._objectiveSample={};Q.lastSwitchAt=-999;Q.lastError=nil
 Q.travelSample=nil;Q.travelPrevious=nil;Q.servicedUntil=nil;Q.stallMute=nil
 Q.ready=true;log={{questID=999999,title='Test',level=10}};completed=false
 Q:ReadQuestLog()
end
function quest(id,x)
 return {id=id,title='Q'..id,active=true,state='journal',kind='solo',level=10,xp=100,
  workPoint={map=1,x=x,y=10},returnPoint={map=1,x=10,y=10},objectives={{needed=10,current=2}}}
end
function destination()
 local q=quest(1,20)
 return {key='1:work',id=1,kind='work',point=q.workPoint,map=1,x=20,y=10,quest=q,remaining=8,title=q.title}
end
function offer()
 return {id=42,title='Offre',potential=true,state='potential',kind='solo',
  startPoint={map=1,x=12,y=10},workPoint={map=1,x=20,y=10},returnPoint={map=1,x=10,y=10},npcIDs={12}}
end
function scenario(n)
 resetEvolution()
 if n==1 then
  Q:StartSession(30);drain();Q:TickSession(5);assert(Q.sessionRemaining==1795)
  Q:SaveSession();clock=clock+40000;Q:InitSession();assert(Q.sessionRemaining==1795,'offline time subtracted')
  afk=true;Q:TickSession(5);assert(Q.sessionRemaining==1795)
  afk=false;Q.sessionPaused=true;Q:TickSession(5);assert(Q.sessionRemaining==1795)
 elseif n==2 then
  Q:StartSession(15);drain();Q.sessionRemaining=1;Q:Plan();drain()
  assert(#Q.route>0 and Q.route[1].reason:find('dépassant'),'soft fallback missing')
  Q:TickSession(5);drain();assert(Q:SessionBudget()==nil and #Q.route>0)
 elseif n==3 then
  Q.discovery={offer()};Q.route={destination()}
  C_GossipInfo.GetAvailableQuests=function()return {}end
  Q:RememberNPCOffers();assert(not Q:OfferSuppressed(42),'nil count is not complete evidence')
  C_GossipInfo.GetNumAvailableQuests=function()return 0 end
  Q:RememberNPCOffers();assert(Q:OfferSuppressed(42))
  clock=clock+601;assert(not Q:OfferSuppressed(42))
 elseif n==4 then
  Q.discovery={offer()};C_GossipInfo.GetAvailableQuests=function()return {}end
  C_GossipInfo.GetNumAvailableQuests=function()return 0 end
  UnitGUID=function()return 'Creature-0-0-0-0-99-0000'end
  Q:RememberNPCOffers();assert(not Q:OfferSuppressed(42),'unrelated NPC suppressed offer')
 elseif n==5 then
  Q.discovery={offer()};local a=Q:VerificationStep(player,destination())
  assert(a and a.kind=='verify' and not a.potential)
  local near=destination();near.remaining=2;assert(Q:VerificationStep(player,near)==nil)
  Q.discovery[1].startPoint.x=90;assert(Q:VerificationStep(player,destination())==nil)
 elseif n==6 then
  Q.discovery={offer()};local a=destination();Q.route={a};Q:Feedback('wrong');drain()
  assert(Q:ActionBlocked(a))
  local alternate=Q.Copy(a);alternate.point={map=1,x=21,y=10};assert(not Q:ActionBlocked(alternate))
  clock=clock+1801;assert(not Q:ActionBlocked(a))
 elseif n==7 then
  local a=destination();a.point={map=1,x=10,y=10};Q.route={a};speed=0
  for i=1,50 do clock=clock+5;Q:ObserveStall(5)end
  assert(not Q.stallHint,'idle player considered stuck')
  speed=7
  for i=1,37 do clock=clock+5;Q:ObserveStall(5)end
  assert(Q.stallHint)
  a.quest.objectives[1].current=3;Q:ObserveStall(5);assert(not Q.stallHint)
 elseif n==8 then
  Q.route={destination()};Q.route[1].point=Q.Copy(player);afk=true
  for i=1,60 do clock=clock+5;Q:ObserveStall(5)end
  assert(not Q.stallHint)
 elseif n==9 then
  C_Container={GetContainerNumFreeSlots=function()return 0,0 end,GetContainerNumSlots=function()return 4 end}
  Q.memory.services.a={point={map=1,x=12,y=10},name='Marchand',at=clock,stamp=Q.stamp,repair=true}
  local a=Q:ServiceStep(player,destination());assert(a and a.kind=='service')
  Q.memory.services.a.point.x=90;assert(not Q:ServiceStep(player,destination()))
  C_Container=nil;Q:RefreshNeeds();assert(not Q.needs.vendor)
 elseif n==10 then
  GetInventoryItemDurability=function(i)if i==1 then return 10,100 end end
  Q.memory.services.a={point={map=1,x=12,y=10},name='Marchand',at=clock,stamp=Q.stamp,repair=false}
  assert(not Q:ServiceStep(player,destination()),'nonrepair vendor used')
  Q.memory.services.a.repair=true;assert(Q:ServiceStep(player,destination()))
 elseif n==11 then
  Q.quests={{id=1,title='Objets',objectives={{type='item',objectID=100,needed=5,current=2},
    {type='item',objectID=200,needed=3,current=3,finished=true}}}}
  local items=Q:RequiredItems();assert(items[100].needed==5 and not items[200])
 elseif n==12 then
  Q.route={destination()};Q:MarkPassage();drain()
  Q.visitedPassages={};player.x=1
  local a=Q:NavigationStep(destination());assert(a.kind=='passage' and a.point.x==10)
  player.x=10;assert(Q:NavigationStep(destination()).kind=='work')
 elseif n==13 then
  local a={map=1,x=10,y=10};local b={map=2,x=10,y=10}
  Q:AddTransition(a,b,5);assert(Q:KnownCrossMap(a,b)==nil)
  Q:AddTransition(a,b,7);local t,e=Q:KnownCrossMap(a,b);assert(t and e and t==5)
  assert(Q:KnownCrossMap(b,a)==nil,'reverse transition invented')
  Q.memory.corrections['edge:'..e.key]={untilTime=clock+100,stamp=Q.stamp,pointKey=Q:PointKey(e.from)}
  assert(Q:KnownCrossMap(a,b)==nil)
 elseif n==14 then
  Q:AddTransition({map=1,x=10,y=10},{map=2,x=10,y=10},5)
  Q:AddTransition({map=1,x=10,y=10},{map=2,x=10,y=10},5)
  local saved=Q.memory.edges;Q.stamp='new-build'
  assert(Q:KnownCrossMap(player,{map=2,x=10,y=10})==nil)
  assert(next(saved)~=nil,'historical memory deleted')
 elseif n==15 then
  local a={map=1,x=10,y=10};local b={map=1,x=20,y=10};local key=Q:PointKey(a)..'>'..Q:PointKey(b)
  Q.memory.timings[key]={stamp=Q.stamp,at=clock,samples={50,52,500}}
  assert(Q:TravelEstimate(a,b)==52,'median not robust')
  Q.memory.timings[key].samples={50};assert(Q:TravelEstimate(a,b)~=50)
 elseif n==16 then
  Q.DataPack={schema=1,stamp=Q.stamp,source='reviewed local',revision='1',passages={{action='1:work',point={map=1,x=15,y=10}}},edges={}}
  Q:ImportDataPack();assert(Q.memory.passages['1:work'].point.x==15)
  Q.DataPack.revision='2';Q.DataPack.passages[2]={action='2:work',point={map=1,x=200,y=10}}
  Q.DataPack.passages[1].point.x=16;Q:ImportDataPack()
  assert(Q.memory.passages['1:work'].point.x==15,'partial invalid import applied')
 elseif n==17 then
  Q:MemoryExport();assert(Q.db.lastExport:find('QF%-OBSERVATIONS'))
  Q:ShowExport(true);assert(Q.exportFrame:IsShown())
  Q:ShowExport(false);assert(Q.db.lastDiagnostic:find('Session'))
 elseif n==18 then
  local old=Q.DBGet
  Q.DBGet=function(_,entity,id,key)
   if id==1 and key=='nextQuestInChain' then return 2 end
   if id==2 and key=='requiredLevel' then return 10 end
   if id==2 and key=='questLevel' then return 10 end
   if id==2 and key=='preQuestGroup' then return {1,3} end
  end
  assert(Q:ChainBenefit(quest(1,20))==0,'missing prerequisite ignored')
  local done=Q.QuestFinished;Q.QuestFinished=function(_,id)return id==3 end
  assert(Q:ChainBenefit(quest(1,20))>0)
  Q.DBGet=old;Q.QuestFinished=done
 elseif n==19 then
  local old=Q.DBGet
  Q.DBGet=function(_,entity,id,key)
   if id==1 and key=='nextQuestInChain' then return 2 end
   if id==2 and (key=='requiredLevel' or key=='questLevel') then return 10 end
   if id==2 and key=='exclusiveTo' then return {3} end
  end
  Q.activeIds[3]=true;assert(Q:ChainBenefit(quest(1,20))==0)
  Q.DBGet=old
 elseif n==20 then
  Q:Plan();Q:Plan();Q:Plan();map=2;player.map=2;Q:Plan();drain()
  assert(not Q.lastError)
  for _,a in ipairs(Q.route)do assert(a.map==2,'stale route published')end
 elseif n==21 then
  Q.quests={quest(1,20)};Q.activeIds={[1]=true};Q.discovery={offer()}
  Q.discovery[1].state='verified';Q.discovery[1].expires=clock-1
  local actions=Q:BuildActions();for _,a in ipairs(actions)do if a.id==42 then assert(a.blocked)end end
 elseif n==22 then
  Q.route={destination()};Q:Feedback('hard');drain()
  assert(Q:TimeMultiplier(1)==1.15,'single report overreacted')
  clock=clock+86401;assert(Q:TimeMultiplier(1)==1)
 elseif n==23 then
  local q=quest(1,20);q.returnPoint={map=2,x=10,y=10};q.complete=true
  Q.quests={q};Q.activeIds={[1]=true};Q:Plan();drain();assert(#Q.route==0)
  Q:AddTransition(player,q.returnPoint,5);Q:AddTransition(player,q.returnPoint,5)
  Q:Plan();drain();assert(Q.route[1].kind=='passage' and Q.route[1].map==1)
 elseif n==25 then
  local a=quest(1,20);local b=quest(2,20)
  a.objectives={{needed=10,current=0,type='monster',objectID=99,point=a.workPoint}}
  b.objectives={{needed=10,current=0,type='monster',objectID=99,point=b.workPoint}}
  Q.quests={a,b};Q.activeIds={[1]=true,[2]=true};Q._objectiveSample={}
  Q:ObserveQuestProgress()
  for i=1,3 do
   clock=clock+10;a.objectives[1].current=i;b.objectives[1].current=i;Q:ObserveQuestProgress()
  end
  assert(Q:ShareProof(99,1,2))
  local actions=Q:BuildActions();local first,second
  for _,v in ipairs(actions)do if v.kind=='work' then if not first then first=v else second=v end end end
  assert(first.shareKey and first.shareKey==second.shareKey)
  local state={used={},seq={},where=first.point,seconds=0,travel=0,xp=0,utility=0,credit=0,slots=2,tie=''}
  local travel=function()return 0 end
  local one=Q.Optimizer.Step(first,state,travel);local two=Q.Optimizer.Step(second,one,travel)
  assert(two.seconds==first.seconds+6,'shared kills counted twice')
 elseif n==26 then
  Q.learningEpoch=0;Q.learningActive=0;Q._objectiveSample={}
  local a=quest(1,20);Q.quests={a};Q:ObserveQuestProgress();local previous=Q.db.secondsPerObjective
  speed=0;for i=1,10 do clock=clock+5;Q:TickLearning(5)end
  a.objectives[1].current=3;Q:ObserveQuestProgress();assert(Q.db.secondsPerObjective==previous,'idle time learned as combat')
 elseif n==27 then
  local a=destination();Q.route={a};Q.memory.passages[a.key]={point={map=1,x=5,y=5},at=clock,stamp=Q.stamp}
  player.x=0;player.y=0;Q.visitedPassages={}
  local nav=Q:NavigationStep(a);Q.route={nav};Q:Feedback('passage');drain()
  assert(Q.memory.passages[a.key]==nil and Q:ActionBlocked(a))
 elseif n==28 then
  Q.route={destination()};player.x=10;player.y=10
  for repeatID=1,3 do
   player.x=10;Q.travelSample=nil;clock=clock+5;Q:TickTravel(5)
   player.x=15;clock=clock+5;Q:TickTravel(5)
   player.x=20;clock=clock+5;Q:TickTravel(5)
  end
  local key=Q:PointKey({map=1,x=10,y=10})..'>'..Q:PointKey({map=1,x=20,y=10})
  assert(#Q.memory.timings[key].samples==3 and Q:TravelEstimate({map=1,x=10,y=10},{map=1,x=20,y=10})==10)
  player.x=10;Q.travelSample=nil;Q:TickTravel(5);combat=true
  player.x=15;clock=clock+5;Q:TickTravel(5);combat=false
  player.x=20;clock=clock+5;Q:TickTravel(5)
  assert(#Q.memory.timings[key].samples==3,'combat trip learned')
 elseif n==29 then
  local old=Q.MapDistance
  Q.MapDistance=function(_,a,b)
   if not a or not b then return nil,false end
   return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2)*10,true
  end
  for i=1,2 do
   player.map=1;player.x=10;clock=clock+5;Q:TickTravel(5)
   player.map=2;player.x=11;clock=clock+5;Q:TickTravel(5)
  end
  local key=Q:PointKey({map=1,x=10,y=10})..'>'..Q:PointKey({map=2,x=11,y=10})
  assert(Q.memory.edges[key] and Q.memory.edges[key].count==2)
  local count=0;for _ in pairs(Q.memory.edges)do count=count+1 end
  taxi=true;player.map=3;player.x=90;clock=clock+5;Q:TickTravel(5)
  local after=0;for _ in pairs(Q.memory.edges)do after=after+1 end;assert(after==count)
  Q.MapDistance=old
 elseif n==24 then
  Q:StartSession(0);drain();assert(Q:SessionBudget()==nil)
  Q:TickSession(10);assert(Q.sessionRemaining==0)
  Q:StartSession(31);assert(Q.db.timeBudget==0,'unsupported duration accepted')
 end
 assert(Q.lastError==nil,Q.lastError)
end
''')
names=['session reprise hors ligne/pause','budget souple','absence PNJ confirmée','PNJ différent','vérification sur trajet','correction locale','blocage actif et pause','AFK','sacs et détour marchand','réparation pertinente','objets vérifiés','entrée manuelle','transition dirigée observée','nouvelle version des données','temps robustes','import atomique','export copiable','chaîne prérequis','chaîne exclusion','calculs annulés','offre périmée','difficulté temporaire','navigation interzone connue','session libre','objectifs partagés prouvés','apprentissage excluant les pauses','passage impossible','trajets observés hors combat','transitions observées sans téléportation']
results=[]
for n,name in enumerate(names,1):
    start=time.perf_counter();l.globals().scenario(n)
    results.append({'test':name,'status':'PASS','runtime_ms':round((time.perf_counter()-start)*1000,3)})
    print(f'{n:02} PASS {name}')
# Python import validator rejects code-like action IDs and non-finite coordinates.
tools=ADDON.parent/'tools'/'build_data_pack.py'
spec=importlib.util.spec_from_file_location('pack',tools);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
valid={'schema':1,'reviewed':True,'stamp':'fixture','source':'manual test','revision':'1','passages':[],'edges':[]}
assert module.validate(valid)==valid
for invalid in [dict(valid,reviewed=False),dict(valid,passages=[{'action':'os.execute(1)','point':{'map':1,'x':1,'y':1}}]),dict(valid,passages=[{'action':'1:work','point':{'map':1,'x':float('nan'),'y':1}}])]:
    try:module.validate(invalid)
    except ValueError:pass
    else:raise AssertionError('Invalid pack accepted')
# Lua serialization must preserve strings as data, even with quotes or newlines.
s='"; error("injection") --\nÉpreuve'
assert l.eval(module.lua(s))==s
(ROOT/'EVOLUTION_RESULTS.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('29 scénarios évolution + validation/import non exécutable: PASS')
