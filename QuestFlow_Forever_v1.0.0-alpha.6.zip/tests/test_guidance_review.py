from pathlib import Path
import runpy
l=runpy.run_path(str(Path(__file__).with_name('test_integration.py')) )['l']
l.execute(r'''
map=1;clock=1000;local player={map=1,x=50,y=50};Q.PlayerPoint=function()return player end
GetPlayerFacing=function()return 0 end
local function action(x,y)return {key='1:work',id=1,kind='work',title='Test',map=1,x=x,y=y,point={map=1,x=x,y=y},quest={objectives={}},remaining=8} end
Q.db.terrain={};Q.memory.passages={}
local atan=function(a,b)return math.abs((a-b+math.pi)%(2*math.pi)-math.pi)<.001 end
for _,v in ipairs({{50,40,0},{40,50,math.pi/2},{50,60,math.pi},{60,50,-math.pi/2}}) do
 local a=action(v[1],v[2]);local g=Q:CalculateGuidance(a);assert(atan(g.rotation,v[3]))
 GetPlayerFacing=function()return math.pi/2 end;g=Q:CalculateGuidance(a);assert(atan(g.rotation,v[3]-math.pi/2));GetPlayerFacing=function()return 0 end
end
Q.route={action(50.5,50)};Q:RefreshNavigation();assert(not Q.navFrame.icon:IsShown())
player.x=49.1;Q:RefreshNavigation();assert(not Q.navFrame.icon:IsShown(),'arrival hysteresis')
player.x=50;Q.route={action(54,50)};Q:RefreshNavigation();assert(Q.navFrame.icon:IsShown())
local world=Q.WorldPoint;Q.WorldPoint=function()return nil end;Q:RefreshNavigation();assert(not Q.navFrame.icon:IsShown());Q.WorldPoint=world
local cave=action(60,50);cave.objectiveText='Tuer la cible dans la grotte';local dest,label=Q:AccessTarget(cave);assert(not dest and label:find('Grotte'))
cave.objectiveText='Aller au sommet de la montagne';dest,label=Q:AccessTarget(cave);assert(dest and label:find('Montagne'))
local travel=Q.TravelEstimate;Q.TravelEstimate=function()return 300 end;cave.objectiveText=nil;dest,label=Q:AccessTarget(cave);assert(label:find('détour'));Q.TravelEstimate=travel
local ex=action(60,50);ex.point.entity={kind='npc',id=20,area=1,x=60,y=50}
LibStub=function()return {GetSpawnApproach=function()return {continent=1,points={{53,47},{60,50}}}end} end
C_Map.GetMapPosFromWorldPos=function(_,v,m)return m,CreateVector2D(v.x/100,v.y/100)end
local p,n=Q:AccessTarget(ex);assert(p.x==53 and n:find('entrée'))
player.x=53;player.y=47;p,n=Q:AccessTarget(ex);assert(p.x==60)
player.x=50;player.y=50;LibStub=nil
UnitClass=function()return 'Chasseur','HUNTER' end;UnitLevel=function()return 10 end;UnitName=function()return 'Maître' end
GetSpellInfo=function(id)if id==3044 then return 'Tir des arcanes' end end
local learned=false;IsSpellKnown=function()return learned end
GetNumTrainerServices=function()return 1 end;GetTrainerServiceInfo=function()return 'Tir des arcanes','Rang 1','available' end
GetTrainerServiceCost=function()return 100 end;GetTrainerServiceLevelReq=function()return 6 end
GetMoney=function()return 150 end
Q:ObserveTrainer();clock=clock+130;local goal=action(70,50);local t=Q:TrainerStep(player,goal);assert(t and t.spell==3044)
learned=true;assert(not Q:TrainerStep(player,goal));learned=false;GetMoney=function()return 1 end;assert(not Q:TrainerStep(player,goal));GetMoney=function()return 150 end
for _,row in pairs(Q.db.trainers)do row.point={x=50,y=99,map=1}end;assert(not Q:TrainerStep(player,goal),'long detour proposed')
local q={id=75,title='Quête ancienne',active=true,kind='solo',level=2,objectives={{needed=8,current=0,type='monster'}}}
Q.Provider=function()return {}end;Q.DBGet=function(_,_,id,k)if k=='name' then return 'Quête ancienne' elseif k=='zoneOrSort' then return 12 end end
Q.ReadQuestLog=function()Q.quests={q}end;Q.quests={q};assert(Q:CleanupReason(q));q.classQuest=true;assert(not Q:CleanupReason(q));q.classQuest=nil
q.objectives[1].current=1;assert(not Q:CleanupReason(q));q.objectives[1].current=0
Q.db.keepQuests[q.id]=true;assert(not Q:CleanupReason(q));Q.db.keepQuests[q.id]=nil
local abandoned=0;local selected=0;C_QuestLog.SetSelectedQuest=function(id)selected=id end;C_QuestLog.GetSelectedQuest=function()return selected end
C_QuestLog.SetAbandonQuest=function()end;C_QuestLog.GetAbandonQuestName=function()return q.title end;C_QuestLog.AbandonQuest=function()abandoned=abandoned+1 end
StaticPopupDialogs={};local pending;StaticPopup_Show=function(_,_,_,data)pending=data end
Q:ReviewAbandon(q.id);assert(pending and abandoned==0)
selected=99;Q:ConfirmedRemove(pending);assert(abandoned==0);selected=q.id
q.objectives[1].current=1;Q:ConfirmedRemove(pending);assert(abandoned==0);q.objectives[1].current=0
Q:ConfirmedRemove(pending);assert(abandoned==1)
print('Directions cardinales, arrivée, API absente, accès, détour, maître et tri confirmé : OK')
''')
