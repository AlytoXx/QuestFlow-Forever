from pathlib import Path
from lupa.lua51 import LuaRuntime
ROOT=Path(__file__).resolve().parents[1]
ADDON=ROOT/'deliverable'/'QuestFlowForever'
if not ADDON.exists(): ADDON=ROOT/'QuestFlowForever'
l=LuaRuntime(unpack_returned_tuples=True)
l.execute(r'''
unpack=unpack or table.unpack
clock=1000; map=1; frames={}; timers={}; messages={}
function GetTime() return clock end
GetServerTime=GetTime
function GetBuildInfo() return '1.60.1','fixture','',16001 end
function UnitLevel() return 10 end
function GetZoneText() return 'Test' end
function UnitName() return 'Test NPC' end
function GetPlayerFacing() return 0 end
function GetUnitSpeed() return 7 end
function CreateVector2D(x,y) return {x=x,y=y,GetXY=function(s)return s.x,s.y end} end
function CreateFrame(kind,name,parent,template)
 local f={shown=true,scripts={},events={}}
 local methods={
  SetScript=function(s,k,fn)s.scripts[k]=fn end,
  RegisterEvent=function(s,k)s.events[k]=true end,
  IsShown=function(s)return s.shown end,
  Show=function(s)s.shown=true end,Hide=function(s)s.shown=false end,
  SetShown=function(s,v)s.shown=v end,
  GetPoint=function()return 'CENTER',nil,'CENTER',0,0 end,
  SetText=function(s,t)s.text=t end,
  CreateFontString=function()return CreateFrame('FontString')end,
  CreateTexture=function()return CreateFrame('Texture')end,
 }
 setmetatable(f,{__index=function(s,k)return methods[k] or function()end end})
 frames[#frames+1]=f;return f
end
UIParent=CreateFrame('Frame');SlashCmdList={}
DEFAULT_CHAT_FRAME={AddMessage=function(_,msg)messages[#messages+1]=msg end}
C_Timer={After=function(_,fn)timers[#timers+1]=fn end}
function drain()
 local count=0
 while #timers>0 do
  local fn=table.remove(timers,1);fn();count=count+1;assert(count<10000,'timer runaway')
 end
end
function emit(event,...)
 for _,f in ipairs(frames) do if f.events[event] and f.scripts.OnEvent then f.scripts.OnEvent(f,event,...) end end
end
C_Map={GetBestMapForUnit=function()return map end,
 GetPlayerMapPosition=function()return CreateVector2D(.1,.1)end,
 GetWorldPosFromMapPos=function(m,p)return m,CreateVector2D(-p.y*1000,-p.x*1000)end}
log={{questID=999999,title='Forever inconnue',level=10}}
completed=false
C_QuestLog={GetNumQuestLogEntries=function()return #log end,
 GetInfo=function(i)return log[i]end,
 GetQuestObjectives=function()return {{text='Mobs',numRequired=10,numFulfilled=8,finished=false}}end,
 GetQuestsOnMap=function()return {{questID=999999,x=.2,y=.2}}end,
 IsComplete=function()return completed end,
 IsQuestFlaggedCompleted=function()return false end}
Constants={QuestLogConsts={MAXIMUM_NUM_QUESTS_LOG_CAN_ACCEPT=20}}
C_SkillInfo={GetNumSkillLines=function()return 1 end,
 GetSkillLineInfo=function()return {skillID=393,name='Dépeçage',rank=20,maxRank=75}end}
''')
q=l.table();l.globals().Q=q
for line in (ADDON/'QuestFlowForever.toc').read_text().splitlines():
    if line.endswith('.lua'): l.execute((ADDON/line).read_text(),'QuestFlowForever',q)
l.execute(r'''
emit('PLAYER_LOGIN');drain()
assert(Q.lastError==nil,Q.lastError)
assert(#Q.quests==1 and Q.activeIds[999999])
assert(Q.db.observed[999999].title=='Forever inconnue')
assert(Q.db.observed[999999].workPoint.x==20,'POI must not be player position')
assert(Q.professions[393].rank==20)
assert(Q:JournalCapacity()==20)
assert(#Q.route==1 and Q.route[1].kind=='work' and Q.route[1].remaining==2)
local guide=Q:CalculateGuidance(Q.route[1]);assert(guide.distance>0)
local north=Q:HeadingOnMap(50,50,50,0);assert(math.abs(north)<.0001)
local east=Q:HeadingOnMap(50,50,100,50);assert(math.abs(east+math.pi/2)<.0001)
Q:Diagnostic();assert(Q.db.lastDiagnostic:find('16001'))
Q:Skip(999999,'crowd');drain();assert(#Q.route==0)
clock=clock+1801;Q:Replan();drain();assert(#Q.route==1)
-- Unknown coordinates remain unknown, with no invented player location.
C_QuestLog.GetQuestsOnMap=nil;Q:Replan();drain();assert(#Q.route==0 and #Q.unlocated==1)
-- Provider contract and flavor isolation.
LibQuestieDB={RequireContract=function(v)return v==4 end,
 ModeIndicator={GetStatus=function()return {expansion='TBC',mode='baked'}end}}
assert(Q:Provider()==nil)
LibQuestieDB.ModeIndicator.GetStatus=function()return {expansion='Forever',mode='baked'}end
LibQuestieDB.Support={Get=function()return {private={areaIdToUiMapId='return {[12]=1}'}}end}
LibQuestieDB.Quest={Get=function(id,key)
 if key=='finishedBy' then return {{1},{}} elseif key=='startedBy' then return {{1},{}}
 elseif key=='objectives' then return {{{2,10}},{},{}} elseif key=='name' then return 'Offre test' end
end}
LibQuestieDB.Npc={Get=function(id,key) if key=='spawns' then return {[12]={{id==1 and 10 or 20,10}}} end end}
assert(Q:Provider()==LibQuestieDB and Q:AreaForMap(1)==12)
C_GossipInfo={GetAvailableQuests=function()return {{questID=42,title='Offre test'}}end}
Q:RememberNPCOffers();Q:BeginDiscovery();drain()
assert(#Q.discovery==1 and Q.discovery[1].state=='verified')
local actions=Q:BuildActions();local count=0
for _,a in ipairs(actions) do if a.id==42 then count=count+1 end end
assert(count==3,'pickup/work/turnin graph')
clock=clock+301;Q:BeginDiscovery();drain();assert(#Q.discovery==0,'stale offers excluded')
-- Internal Questie list stays unconfirmed in strict mode.
QuestieLoader={ImportModule=function()return {__availableQuests={[42]=true}}end}
Q:BeginDiscovery();drain();assert(Q.discovery[1].state=='potential')
for _,a in ipairs(Q:BuildActions()) do assert(a.id~=42,'unconfirmed auto pickup') end
Q.db.experimentalOffers=true;actions=Q:BuildActions();count=0
for _,a in ipairs(actions) do if a.id==42 then count=count+1 end end
assert(count==3)
Q.db.experimentalOffers=false
-- Accepted quests vanish from discovery before new search publishes.
log[#log+1]={questID=42,title='Acceptée',level=10}
emit('QUEST_ACCEPTED');drain()
for _,a in ipairs(Q.route) do assert(not(a.id==42 and a.kind=='pickup')) end
-- Zone changes invalidate old asynchronous work.
map=2;emit('ZONE_CHANGED_NEW_AREA');drain()
for _,a in ipairs(Q.route) do assert(a.map==2) end
assert(Q.lastError==nil,Q.lastError)
-- Unknown capacity must stay unknown, not default to 20 or 25.
Constants=nil;assert(Q:JournalCapacity()==nil)
print('Integration: journal, UI/events mock, discovery, provider, capacity, professions, geometry, reports, expiry, zone: PASS')
''')
