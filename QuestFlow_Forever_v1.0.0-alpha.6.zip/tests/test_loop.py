from pathlib import Path
from lupa.lua51 import LuaRuntime
r=Path(__file__).resolve().parents[1]/'QuestFlowForever'
l=LuaRuntime();q=l.table();l.globals().Q=q
for f in ('Optimizer.lua','Loop.lua'):l.execute((r/f).read_text(),'test',q)
l.execute("""
local function p(x,y)return {map=1,x=x,y=y or 0}end
local function dist(a,b)return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2)end
Q.TravelEstimate=function(_,a,b)return dist(a,b)end;Q.PointKey=function(_,a)return a.x..':'..a.y end
Q.visitedPassages={};Q.PassageFor=function()end
local access={one={points={p(0,10),p(10,10)},penalty=0},two={points={},penalty=0}}
local one,two={key='one'},{key='two'}
assert(Q:LoopTravel(p(0),p(10),one,nil,access)==30)
assert(Q:LoopTravel(p(10),p(0),two,one,access)==30)
access.two.points={p(0,10),p(10,10)}
assert(Q:LoopTravel(p(10,11),p(10,12),two,one,access)==3)
local function act(id,kind,x,xp,deps,potential)
 return {key=id..kind,id=id,kind=kind,point=p(x),xp=xp,seconds=5,quest={potential=potential},requires=deps}
end
local w=act(1,'work',100,0,{},false);local t=act(1,'turnin',0,100,{w.key},false)
local a=act(2,'pickup',0,0,{},true);local b=act(2,'work',100,0,{a.key},true);local c=act(2,'turnin',0,100,{b.key},true)
local opt={slots=1,capacity=20,horizon=90,travel=dist}
local base={seq={w,t}}
local s,log=Q:ComparePickups(base,{w,t,a,b,c},p(0),opt)
assert(log[2].included and log[2].extraSeconds==15 and s.xp==200)
b.point=p(1000);s,log=Q:ComparePickups(base,{w,t,a,b,c},p(0),opt);assert(not log[2].included and s.xp==100)
s,log=Q:ComparePickups({seq={a,w,b,t,c}},{w,t,a,b,c},p(0),opt);assert(not log[2].included and s.xp==100)
opt.forceFirst=w.key;b.point=p(100)
s,log=Q:ComparePickups(base,{w,t,a,b,c},p(0),opt)
assert(s.seq[1].key==w.key,'pickup comparison bypasses current instruction')
opt.forceFirst=nil
opt.capacity=1;b.point=p(100);s,log=Q:ComparePickups(base,{w,t,a,b,c},p(0),opt);assert(#s.seq==2)
""")
print('Accès aller et retour, passage commun, inclusion rentable, détour et capacité : OK')
