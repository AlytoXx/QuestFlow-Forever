from pathlib import Path
import sys,time,importlib.util
from lupa.lua51 import LuaRuntime
ROOT=Path(__file__).resolve().parents[1]
TOOLS=ROOT/'deliverable'/'tools'
if not TOOLS.exists():TOOLS=ROOT/'tools'
sys.path.insert(0,str(TOOLS))
from observations_to_pack import convert
from build_data_pack import validate,lua
stamp='16001:fixture:4'
text='QF-OBSERVATIONS\t2\nbuild\t'+stamp+'\npassage\t123:work\t1\t10\t20\t'+stamp+'\nedge\t1\t10\t20\t2\t30\t40\t5\t3\t'+str(int(time.time()))+'\t'+stamp+'\n'
p=convert(text)
assert not p['reviewed'] and len(p['edges'])==1 and len(p['passages'])==1
try:validate(p)
except ValueError:pass
else:raise AssertionError('unreviewed draft accepted')
p['reviewed']=True;validate(p)
l=LuaRuntime(unpack_returned_tuples=True);q=l.table();l.execute('local _,QF=...;QF.DataPack='+lua(p),'test',q)
assert q.DataPack.edges[1].samples==3 and q.DataPack.passages[1].action=='123:work'
old=text.replace(str(int(time.time())),str(int(time.time())-40*86400))
assert len(convert(old)['edges'])==0
print('Pack export/import: parsing, provenance review gate, Lua data round-trip, stale edges: PASS')
