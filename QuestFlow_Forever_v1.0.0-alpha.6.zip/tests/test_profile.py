from pathlib import Path
import runpy
L=runpy.run_path(str(Path(__file__).with_name('test_integration.py')))['l']
L.execute(r'''
assert(Q.profileFrame:IsShown() and not Q.profileAdvanced)
local d=Q:ProfileDraft();d.customJobs=true;d.jobs={[165]=true,[393]=true};d.detour=30;d.mode=2
map=1;local master=Q:ProfileMasterPoint('12,5','10','3044');assert(master.point.x==12.5 and master.spell==3044)
assert(not Q:ProfileMasterPoint(101,10,'3044'));assert(not Q:ProfileMasterPoint(1,1,'x'))
d.masters.class=master;d.masters[165]=Q:ProfileMasterPoint(13,10,nil)
Q:ApplyProfile(d);drain();Q.profileFrame:Hide();Q:InitSettings();Q:ShowProfile(true)
assert(not Q.profileFrame:IsShown(),'setup repeated after login')
assert(Q:FollowProfession(165) and not Q:FollowProfession(171));assert(Q.db.professionPriority and Q.db.trainerDetour==30)
Q:ShowProfile(false);assert(Q.profileFrame:IsShown() and Q.profileDraft.jobs[393])
GetSpellInfo=function()return 'Tir des arcanes' end;IsSpellKnown=function()return false end
local pos={map=1,x=10,y=10};local goal={id=10,kind='work',map=1,point={map=1,x=20,y=10},remaining=8}
Q.professions={};Q.trainerMute=nil;local a=Q:DeclaredMasterStep(pos,goal);assert(a and a.profileMaster=='class')
IsSpellKnown=function()return true end;assert(not Q:DeclaredMasterStep(pos,goal))
Q.professions[165]={rank=72,cap=75};assert(Q:DeclaredMasterStep(pos,goal).profileMaster==165)
Q.db.profile.masters[165].point.y=90;assert(not Q:DeclaredMasterStep(pos,goal))
Q.db.profile.masters[165].point.y=10;Q.professions={};assert(not Q:DeclaredMasterStep(pos,goal),'planned job treated as learned')
QuestFlowForeverDB={};Q:InitSettings();assert(not Q.db.profile);Q:ShowProfile(true);assert(Q.profileFrame:IsShown())
print('Premier lancement, profil par personnage, sélection, coordonnées et détours : OK')
''')
