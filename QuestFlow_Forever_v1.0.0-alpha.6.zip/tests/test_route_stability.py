from pathlib import Path
import runpy
l=runpy.run_path(str(Path(__file__).with_name('test_integration.py')))['l']
l.execute(r'''
map=1;clock=5000
local p={map=1,x=50,y=50}
Q.PlayerPoint=function()return p end
Q.db.skips={};Q.db.terrain={};Q.db.solo=true;Q.db.group=false;Q.db.professionQuests=false
Q.db.verifyOnPath=false;Q.db.services=false;Q.db.trainerDetour=0;Q.db.timeBudget=0
Q.memory.corrections={};Q.memory.passages={};Q.discovery={};Q.visitedPassages={};Q.route={}
Q.SessionBudget=function()return nil end
Q.JournalCapacity=function()return 20 end
local done={id=501,title='Remise proche',active=true,complete=true,kind='group',level=1,returnPoint={map=1,x=51,y=50},objectives={}}
local work={id=502,title='Travail',active=true,kind='solo',level=10,objectives={{current=0,needed=5,type='monster',point={map=1,x=70,y=50}}}}
Q.quests={work,done};Q.activeIds={[501]=true,[502]=true}
Q:Plan();drain();assert(Q.route[1].id==501 and Q.route[1].nearbyTurnin,'nearby completed group quest hidden')
assert(Q:ActionCategory(Q.route[1])=='À rendre')
done.profession=393;done.professionName='Dépeçage';assert(Q:IsAllowed(done));Q:Plan();drain()
assert(Q:ActionCategory(Q.route[1]):find('Métier'))
-- Still wins during cooldown and even with a huge alternative reward.
Q.route={Q.ranked[1]};Q.lastSwitchAt=clock;work.xp=100000
Q:Plan();drain();assert(Q.route[1].id==501)
Q.db.skips[501]={untilTime=clock+1800};Q:Plan();drain();assert(Q.route[1].id==502,'report ignored')
Q.db.skips={};done.returnPoint.x=80
assert(not Q:NearbyTurnin(Q:BuildActions(),p),'distant return forced')
done.returnPoint.x=51;Q.db.terrain['501:turnin']={kind='cave',stamp=Q.stamp}
assert(not Q:NearbyTurnin(Q:BuildActions(),p),'uncertain access forced')
Q.db.terrain={};local dist=Q.MapDistance;Q.MapDistance=function()return .1,false end
assert(not Q:NearbyTurnin(Q:BuildActions(),p),'map percentage presented as nearby');Q.MapDistance=dist
-- Incidental additions cannot invalidate the underlying current instruction.
local main={key='502:work1',id=502,kind='work',point={map=1,x=70,y=50},map=1,quest=work,title=work.title}
local verify={key='503:verify',id=503,kind='verify',point=p,map=1,title='Offre'}
local originalVerify,originalNav=Q.VerificationStep,Q.NavigationStep
Q.VerificationStep=function()return verify end;Q.NavigationStep=function(_,a)return a end
assert(Q:DecorateRoute({seq={main}},p,main)[1]==main,'new incidental stop interrupts travel')
local seq=Q:DecorateRoute({seq={main}},p,nil)
assert(seq[1]==verify and verify.originalAction==main)
assert(Q:DecorateRoute({seq={main}},p,verify)[1]==verify)
main.nearbyTurnin=true;assert(Q:DecorateRoute({seq={main}},p,nil)[1]==main);main.nearbyTurnin=nil
Q.VerificationStep=originalVerify;Q.NavigationStep=originalNav
-- Subzone retains commitment; true map change clears it before new async work.
Q.route={main};Q.routeMap=1;Q.lastSwitchAt=clock;Q.visitedPassages={kept=true}
emit('ZONE_CHANGED');assert(Q.route[1]==main and Q.visitedPassages.kept and Q.lastSwitchAt==clock)
-- Discard queued refresh for isolated event checks.
timers={};map=2;emit('ZONE_CHANGED_NEW_AREA');assert(#Q.route==0 and not Q.visitedPassages.kept)
timers={};map=1
-- Spawn stays stable only while still present in current provider data.
local oldGet=Q.DBGet
Q.DBGet=function(_,kind,id,key)if kind=='Npc' and key=='spawns' then return {[12]={{40,50},{60,50}}}end end
local preferred={map=1,x=40,y=50,entity={kind='npc',id=10}}
p.x=59;assert(Q:EntityPoint('Npc',10,1,preferred).x==40)
assert(Q:EntityPoint('Npc',10,1).x==60)
Q.DBGet=function(_,kind,id,key)if key=='spawns' then return {[12]={{60,50}}}end end
assert(Q:EntityPoint('Npc',10,1,preferred).x==60)
Q.DBGet=oldGet
-- Known NPC dialogue supplies a short-lived return position without DB coordinates.
Q.Provider=function()return nil end
C_GossipInfo.GetActiveQuests=function()return {{questID=501,isComplete=true}}end
Q:RememberNPCTurnins()
log={{questID=501,title='Remise',level=10}};completed=true
C_QuestLog.GetQuestsOnMap=nil;C_QuestLog.GetNextWaypoint=nil
Q:ReadQuestLog();assert(Q.quests[1].returnPoint.source=='npc-dialogue')
clock=clock+301;Q:ReadQuestLog();assert(not Q.quests[1].returnPoint,'expired position retained')
print('Stabilité, sous-zones, points validés, remise proche, filtres, report et catégories : OK')
''')
