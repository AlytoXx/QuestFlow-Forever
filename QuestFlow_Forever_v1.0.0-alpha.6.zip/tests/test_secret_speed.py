from pathlib import Path
import runpy
l=runpy.run_path(str(Path(__file__).with_name('test_integration.py')))['l']
l.execute(r'''
local normalSpeed=GetUnitSpeed
issecretvalue=function(v)return v==12345 end
GetUnitSpeed=function()return 12345 end
assert(Q:CurrentSpeed()==nil)
assert(Q:GroundSpeed()==7)
local before=Q.learningActive or 0
UnitAffectingCombat=function()return false end
Q:TickLearning(.1);assert((Q.learningActive or 0)==before)
Q:TickTravel(.1)
Q:ObserveStall()
local a={key='speed:test',id=1,kind='work',title='Test',point={map=1,x=70,y=50},quest={objectives={}}}
Q.PlayerPoint=function()return {map=1,x=50,y=50}end
Q.db.terrain={};Q.memory.passages={}
GetPlayerFacing=function()return 12345 end
local guide=Q:CalculateGuidance(a)
assert(guide and guide.rotation==nil,'secret facing must hide rotation')
Q.route={a};Q:RefreshNavigation();assert(not Q.navFrame.icon:IsShown())
issecretvalue=nil
for _,value in ipairs({0,1,-1,0/0,math.huge,-math.huge,'7',false})do
 GetUnitSpeed=function()return value end;assert(Q:GroundSpeed()==7)
end
GetUnitSpeed=function()return 14 end;assert(Q:GroundSpeed()==14)
GetUnitSpeed=function()error('restricted API')end;assert(Q:GroundSpeed()==7)
GetUnitSpeed=nil;assert(Q:GroundSpeed()==7)
issecretvalue=function()error('unavailable detector')end
GetUnitSpeed=normalSpeed;assert(Q:GroundSpeed()==7)
issecretvalue=nil;assert(Q:GroundSpeed()==7)
print('Secret speed/facing guards, fallback, learning, travel, arrow: OK (simulated APIs)')
''')
