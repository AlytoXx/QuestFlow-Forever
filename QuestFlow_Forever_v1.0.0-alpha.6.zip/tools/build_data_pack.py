"""Validate an explicitly reviewed JSON pack and generate the optional addon file.
No network, no execution of imported code. Usage: python build_data_pack.py data.json DataPack.lua
"""
import argparse,json,math,re
from pathlib import Path

def point(p):
    if not isinstance(p,dict) or set(p)!={'map','x','y'}: raise ValueError('Point: map, x et y requis uniquement')
    if type(p['map']) is not int or p['map']<=0: raise ValueError('UiMap invalide')
    for k in ('x','y'):
        if type(p[k]) not in (int,float) or not math.isfinite(p[k]) or not 0<=p[k]<=100: raise ValueError('Coordonnée invalide')

def validate(p):
    if not isinstance(p,dict) or set(p)-{'schema','stamp','source','revision','reviewed','passages','edges'}: raise ValueError('Champs inconnus')
    if p.get('schema')!=1 or p.get('reviewed') is not True: raise ValueError('schema=1 et reviewed=true requis après examen des données')
    for k in ('stamp','source','revision'):
        if not isinstance(p.get(k),str) or not 1<=len(p[k])<=500: raise ValueError(k+' requis')
    if len(p['source'])<3: raise ValueError('Provenance manquante')
    for k in ('passages','edges'):
        if not isinstance(p.get(k),list) or len(p[k])>100: raise ValueError(k+' : liste de 100 maximum')
    for r in p['passages']:
        if set(r)!={'action','point'} or not re.fullmatch(r'\d+:[a-zA-Z0-9]+',str(r['action'])): raise ValueError('Action invalide')
        point(r['point'])
    for r in p['edges']:
        if set(r)!={'from','to','seconds','samples'}: raise ValueError('Transition invalide')
        point(r['from']);point(r['to'])
        if r['from']['map']==r['to']['map']: raise ValueError('La transition doit changer de carte')
        if type(r['seconds']) not in (int,float) or not math.isfinite(r['seconds']) or not 0<r['seconds']<=600: raise ValueError('Durée invalide')
        if type(r['samples']) is not int or not 2<=r['samples']<=7: raise ValueError('2 à 7 observations déclarées requises')
    return p

def lua(v):
    if v is True:return 'true'
    if v is False:return 'false'
    if isinstance(v,str):
        # Encode UTF-8 bytes using fixed-width Lua decimal escapes: safe against code injection.
        return '"'+''.join('\\%03d'%b for b in v.encode('utf-8'))+'"'
    if isinstance(v,(int,float)):return str(v)
    if isinstance(v,list):return '{'+','.join(lua(x) for x in v)+'}'
    if isinstance(v,dict):return '{'+','.join('['+lua(k)+']='+lua(x) for k,x in sorted(v.items()))+'}'
    raise ValueError('Type non pris en charge')

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
    data=validate(json.loads(a.input.read_text(encoding='utf-8')))
    a.output.write_text('local _,QF=...\nQF.DataPack='+lua(data)+'\n',encoding='utf-8')
    print('Pack généré. La validation de format ne prouve pas la justesse des observations.')
