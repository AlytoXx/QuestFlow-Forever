"""Prepare a JSON draft from /qf export. Review it before build_data_pack.py.
Only explicit passages and repeated transitions are portable; no availability inferred.
"""
import argparse,csv,json,time
from pathlib import Path
from build_data_pack import validate

def convert(text):
    rows=list(csv.reader(text.splitlines(),delimiter='\t'))
    if not rows or rows[0]!=['QF-OBSERVATIONS','2']:raise ValueError('Export QF version 2 requis')
    stamp=next((r[1] for r in rows if len(r)==2 and r[0]=='build'),None)
    if not stamp:raise ValueError('Empreinte client absente')
    result={'schema':1,'stamp':stamp,'source':'observations locales QuestFlow','revision':str(int(time.time())),
        'reviewed':False,'passages':[],'edges':[]}
    for r in rows:
        if r[0]=='passage' and len(r)==6 and r[5]==stamp:
            result['passages'].append({'action':r[1],'point':{'map':int(r[2]),'x':float(r[3]),'y':float(r[4])}})
        elif r[0]=='edge' and len(r)==11 and r[10]==stamp and int(r[8])>=2 and time.time()-float(r[9])<30*86400:
            result['edges'].append({'from':{'map':int(r[1]),'x':float(r[2]),'y':float(r[3])},
              'to':{'map':int(r[4]),'x':float(r[5]),'y':float(r[6])},'seconds':float(r[7]),'samples':int(r[8])})
    # Validate the data shape without claiming the user has reviewed it.
    validate(dict(result,reviewed=True));return result

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args()
    a.output.write_text(json.dumps(convert(a.input.read_text(encoding='utf-8')),ensure_ascii=False,indent=2),encoding='utf-8')
    print('Brouillon généré, reviewed=false : examiner la provenance et les coordonnées avant import.')
