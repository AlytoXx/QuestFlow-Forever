local ADDON,QF=...
-- Active quests are the ONLY confirmed objectives; DB discoveries are always 'a verifier'.

function QF:QuestKind(id,info)
    -- Questie has corrected tags for many classic quests; use only when available.
    local provider=_G.QuestieLoader
    if provider and type(provider.ImportModule)=='function' then
        local ok,module=pcall(provider.ImportModule,provider,'QuestieDB')
        if ok and type(module)=='table' then
            local checks={{'IsDungeonQuest','dungeon'},{'IsRaidQuest','raid'},
                {'IsGroupQuest','group'}}
            for _,entry in ipairs(checks) do
                if type(module[entry[1]])=='function' then
                    local safe,result=pcall(module[entry[1]],id)
                    if safe and result==true then return entry[2] end
                end
            end
        end
    end
    local tag
    if C_QuestLog and C_QuestLog.GetQuestTagInfo then
        local ok,t=pcall(C_QuestLog.GetQuestTagInfo,id)
        if ok and type(t)=='table' then tag=t.tagID end
    end
    if tag==81 or tag==85 then return 'dungeon' end
    if tag==62 or tag==88 or tag==89 then return 'raid' end
    if tag==1 or (info and (tonumber(info.suggestedGroup) or 0)>1) then return 'group' end
    return 'solo'
end
function QF:ReadQuestLog()
    local out,active={},{}
    local header=''
    local n=0
    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries then
        local ok,v=pcall(C_QuestLog.GetNumQuestLogEntries)
        if ok and type(v)=='number' then n=v end
    elseif GetNumQuestLogEntries then n=GetNumQuestLogEntries() or 0 end
    for i=1,n do
        local info=C_QuestLog and C_QuestLog.GetInfo and C_QuestLog.GetInfo(i)
        if info then
            if info.isHeader then header=info.title or header
            else
                local id=info.questID
                if not id and C_QuestLog.GetQuestIDForLogIndex then id=C_QuestLog.GetQuestIDForLogIndex(i) end
                if id and id>0 then
                    local done=(info.isComplete==true or info.isComplete==1)
                    if not done and C_QuestLog.IsComplete then local r=C_QuestLog.IsComplete(id);done=(r==true or r==1) end
                    local q={id=id,title=info.title or ('Quête '..id),level=info.level or info.difficultyLevel,
                        complete=done,zone=header,kind=self:QuestKind(id,info),active=true,objectives={}}
                    if C_QuestLog.GetQuestObjectives then
                        local ok,objectives=pcall(C_QuestLog.GetQuestObjectives,id)
                        if ok and type(objectives)=='table' then
                            for _,o in ipairs(objectives) do
                                q.objectives[#q.objectives+1]={text=o.text,finished=o.finished,
                                  current=o.numFulfilled,needed=o.numRequired}
                            end
                        end
                    end
                    out[#out+1]=q;active[id]=true
                end
            end
        elseif GetQuestLogTitle then
            local title,level,suggested,isHeader,_,isComplete,_,id=GetQuestLogTitle(i)
            if isHeader then header=title or header
            elseif id and id>0 then
                local q={id=id,title=title or ('Quête '..id),level=level,
                  complete=isComplete==1 or isComplete==true,zone=header,
                  kind=self:QuestKind(id,{suggestedGroup=suggested}),active=true,objectives={}}
                out[#out+1]=q;active[id]=true
            end
        end
    end
    self.quests=out;self.activeIds=active
    -- Blizzard quest POIs, when available, give an actual point for active quests.
    local map=self:MapID()
    if map and C_QuestLog and C_QuestLog.GetQuestsOnMap then
        local ok,pois=pcall(C_QuestLog.GetQuestsOnMap,map)
        if ok and type(pois)=='table' then
            for _,poi in ipairs(pois) do
                if poi.questID and active[poi.questID] then
                    for _,q in ipairs(out) do
                        if q.id==poi.questID and type(poi.x)=='number' and type(poi.y)=='number' then
                            q.map=map;q.x=poi.x*100;q.y=poi.y*100;break
                        end
                    end
                end
            end
        end
    end
    -- Questie already knows entity spawns. Fallback for active quests whose
    -- Blizzard quest POI is missing on TBC, so arrows can also point to mobs.
    if self.LocateActiveQuests then self:LocateActiveQuests() end
    if self.AnnotateProfession then
        for _,q in ipairs(out) do self:AnnotateProfession(q) end
    end
    if self.ObserveQuestProgress then self:ObserveQuestProgress() end
    if GetQuestLogRewardXP then
        for _,q in ipairs(out) do
            local ok,xp=pcall(GetQuestLogRewardXP,q.id)
            if ok and type(xp)=='number' and xp>0 then q.xp=xp end
        end
    end
end

-- UI map ID -> historical AreaTable ID used by QuestieDB NPC spawns.
-- Only whitelisted mappings: absent area = no speculative pickups.
-- QuestieDB NPC coordinates use AreaTable IDs, NOT Blizzard UiMap IDs.
-- The old table omitted TBC UiMaps (e.g. Durotar = 1411), producing zero discoveries.
-- Proven Classic outdoor mappings; ZoneDB can supplement these without guessing coordinates.
QF.areaByUiMap={
 [1411]=14,[1412]=215,[1413]=17,[1454]=1637,[1456]=1638,[1453]=1519,
 [1420]=85,[1421]=130,[1422]=28,[1423]=139,[1424]=267,[1425]=47,
 [1426]=1,[1427]=51,[1428]=46,[1429]=12,[1430]=41,[1431]=10,
 [1432]=38,[1433]=44,[1434]=33,[1435]=8,[1436]=40,[1437]=11,
 [1438]=141,[1439]=148,[1440]=331,[1441]=400,[1442]=406,
 [1443]=405,[1444]=357,[1445]=15,[1446]=440,[1447]=16,[1448]=361,
 [1449]=490,[1450]=493,[1451]=1377,[1452]=618,
 [1416]=36,[1417]=45,[1418]=3,[1419]=4,[1455]=1537,[1457]=1657,[1458]=1497,
 -- Older client UiMaps retained for compatibility (only if matching the selected API flavor).
 [37]=12,[1]=14,[18]=85,[57]=141,[7]=215,[48]=38,[52]=40,[49]=44,
 [47]=10,[21]=130,[25]=267,[14]=45,[26]=47,[23]=139,[22]=28,[51]=51,
 [36]=46,[17]=4,[50]=33,[10]=17,[62]=148,[63]=331,[65]=406,[66]=405,
 [69]=357,[70]=15,[71]=440,[78]=490,[77]=361,[83]=618,[94]=3430,
 [95]=3433,[97]=3524,[106]=3525,[100]=3483,[102]=3521,[107]=3518,
 [108]=3519,[109]=3523,[105]=3522,[104]=3520,
}
-- Read the provider's published map mapping, where present, instead of requiring
-- hardcoded areas in every future zone. Only a trusted installed QuestieDB is evaluated.
function QF:AreaForMap(map)
    if not map then return nil end
    local known=self.areaByUiMap[map]
    if known then return known end
    if not self.dynamicAreaMap then
        self.dynamicAreaMap={}
        local lib=_G.LibQuestieDB
        local support=lib and lib.Support and lib.Support.Get and lib.Support.Get('ZoneDB')
        local source=support and support.private and support.private.areaIdToUiMapId
        if type(source)=='string' and type(loadstring)=='function' then
            local loader=loadstring(source) or loadstring('return '..source)
            if loader then
                local ok,t=pcall(loader)
                if ok and type(t)=='table' then
                    for area,ui in pairs(t) do
                        if type(area)=='number' and type(ui)=='number' and not self.dynamicAreaMap[ui] then
                            self.dynamicAreaMap[ui]=area
                        end
                    end
                end
            end
        end
    end
    return self.dynamicAreaMap[map]
end

local raceBit={ [1]=1,[2]=2,[3]=4,[4]=8,[5]=16,[6]=32,[7]=64,[8]=128,[10]=512,[11]=1024 }
local function allowed(mask,bitValue)
    if not mask or mask==0 then return true end
    if not bitValue then return false end
    if bit and bit.band then return bit.band(mask,bitValue)~=0 end
    return math.floor(mask/bitValue)%2==1
end
local function prereqsOk(QF,qdb,id)
    local one=qdb.Get(id,'preQuestSingle')
    if type(one)=='table' and #one>0 then
        local any=false
        for _,pre in ipairs(one) do if pre>0 and QF:QuestFinished(pre) then any=true end end
        if not any then return false end
    end
    local all=qdb.Get(id,'preQuestGroup')
    if type(all)=='table' then
        for _,pre in ipairs(all) do if pre>0 and not QF:QuestFinished(pre) then return false end end
    end
    return true
end
function QF:CandidateAllowed(id,qdb,level,rb,cb)
    if self.activeIds[id] or self:QuestFinished(id) or self:IsSkipped(id) then return false end
    local req=qdb.Get(id,'requiredLevel')
    local qlevel=qdb.Get(id,'questLevel')
    if type(req)~='number' or req>level then return false end
    if type(qlevel)=='number' and qlevel>0 and (qlevel>level+3 or qlevel<level-8) then return false end
    if not allowed(qdb.Get(id,'requiredRaces'),rb) or not allowed(qdb.Get(id,'requiredClasses'),cb) then return false end
    if not prereqsOk(self,qdb,id) then return false end
    local skill=qdb.Get(id,'requiredSkill')
    if type(skill)=='table' and type(skill[1])=='number' and skill[1]>0 then
        local owned=self.professions and self.professions[skill[1]]
        if not owned or (tonumber(skill[2]) or 0)>(owned.rank or 0) then return false end
    end
    -- High-uncertainty gates are handled by Questie itself. Until a server
    -- offer is observed, conservatively exclude quests using complex gates.
    for _,key in ipairs({'requiredMinRep','requiredMaxRep','requiredSpell',
                         'exclusiveTo','availableStartingWith','requiredSourceItems'}) do
        local gate=qdb.Get(id,key)
        if gate and gate~=0 and (type(gate)~='table' or next(gate)~=nil) then return false end
    end
    return true
end
function QF:PlayerPosition()
    local map=self:MapID()
    if map and C_Map and C_Map.GetPlayerMapPosition then
        local ok,p=pcall(C_Map.GetPlayerMapPosition,map,'player')
        if ok and p then
            local x,y
            if p.GetXY then x,y=p:GetXY() else x,y=p.x,p.y end
            if x and y then return x*100,y*100 end
        end
    end
end
-- Approximate, data-backed locations for active quests without Blizzard POIs.
-- Never invent locations or select out-of-zone spawns as if they were nearby.
function QF:LocateActiveQuests()
    local lib=_G.LibQuestieDB
    local questDB=lib and lib.Quest
    local npcDB=lib and lib.Npc
    local objectDB=lib and lib.Object
    local itemDB=lib and lib.Item
    local map=self:MapID()
    local area=self:AreaForMap(map)
    if not (area and questDB and questDB.Get and npcDB and npcDB.Get) then return end
    local px,py=self:PlayerPosition()
    px=px or 50;py=py or 50
    local function location(entity,id)
        if type(id)~='number' or id<=0 or not entity or not entity.Get then return end
        local spawns=entity.Get(id,'spawns')
        local positions=type(spawns)=='table' and spawns[area]
        if type(positions)~='table' then return end
        local best,bestD
        for _,pt in ipairs(positions) do
            if type(pt)=='table' and type(pt[1])=='number' and type(pt[2])=='number'
                  and pt[1]>=0 and pt[1]<=100 and pt[2]>=0 and pt[2]<=100 then
                local d=(pt[1]-px)^2+(pt[2]-py)^2
                if not bestD or d<bestD then best=pt;bestD=d end
            end
        end
        if best then return best[1],best[2],bestD end
    end
    for _,q in ipairs(self.quests or {}) do
        if not q.x then
            local bestD=math.huge
            local function consider(entity,id)
                local x,y,d=location(entity,id)
                if d and d<bestD then q.x=x;q.y=y;q.map=map;q.approximate=true;bestD=d end
            end
            if q.complete then
                local finishers=questDB.Get(q.id,'finishedBy')
                if type(finishers)=='table' then
                    for _,id in ipairs(finishers[1] or {}) do consider(npcDB,id) end
                    for _,id in ipairs(finishers[2] or {}) do consider(objectDB,id) end
                end
            else
                local objectives=questDB.Get(q.id,'objectives')
                if type(objectives)=='table' then
                    for _,entry in ipairs(objectives[1] or {}) do consider(npcDB,entry[1]) end
                    for _,entry in ipairs(objectives[2] or {}) do consider(objectDB,entry[1]) end
                    if itemDB and itemDB.Get then
                        for _,entry in ipairs(objectives[3] or {}) do
                            local itemID=entry[1]
                            if type(itemID)=='number' and itemID>0 then
                                local mobs=itemDB.Get(itemID,'npcDrops')
                                for _,mob in ipairs(type(mobs)=='table' and mobs or {}) do consider(npcDB,mob) end
                                local objs=itemDB.Get(itemID,'objectDrops')
                                for _,id in ipairs(type(objs)=='table' and objs or {}) do consider(objectDB,id) end
                            end
                        end
                    end
                end
            end
        end
    end
end


-- QuestFlow 0.3: candidates are read exclusively from Questie's already-filtered
-- available list, or quests observed in the actual NPC gossip. No raw GetAllIds.
-- AvailableQuests.__availableQuests is READ-ONLY and is an INTERNAL Questie field:
-- guarded at runtime, may change in future Questie releases.
function QF:QuestieAvailableSet()
    local loader=_G.QuestieLoader
    if not loader or type(loader.ImportModule)~='function' then return nil,'Module Questie indisponible' end
    local ok,module=pcall(loader.ImportModule,loader,'AvailableQuests')
    if not ok or type(module)~='table' then return nil,'Module AvailableQuests incompatible' end
    if type(module.__availableQuests)~='table' then return nil,'Liste filtree non exposee par Questie' end
    return module.__availableQuests,nil
end

function QF:RememberNPCOffers()
    self.observedOffers=self.observedOffers or {}
    if not (C_GossipInfo and C_GossipInfo.GetAvailableQuests) then return end
    local ok,list=pcall(C_GossipInfo.GetAvailableQuests)
    if not ok or type(list)~='table' then return end
    local map=self:MapID();local x,y=self:PlayerPosition()
    if not (map and x and y) then return end
    for _,row in ipairs(list) do
        if type(row.questID)=='number' and row.questID>0 then
            self.observedOffers[row.questID]={map=map,x=x,y=y,time=self:Time(),npc=UnitName and UnitName('npc')}
        end
    end
end

local function safeGet(entity,id,key)
    if not entity or type(entity.Get)~='function' then return nil end
    local ok,value=pcall(entity.Get,id,key)
    if ok then return value end
end
local function validPt(pt)
    return type(pt)=='table' and type(pt[1])=='number' and type(pt[2])=='number'
       and pt[1]>=0 and pt[1]<=100 and pt[2]>=0 and pt[2]<=100
end
function QF:StarterFor(id,map,area,px,py)
    local lib=_G.LibQuestieDB
    local qdb=lib and lib.Quest
    local starters=safeGet(qdb,id,'startedBy')
    if type(starters)~='table' then return nil end
    local faction=UnitFactionGroup('player')
    local best,bestSq
    local function search(entity,entityId)
        local friendly=safeGet(entity,entityId,'friendlyToFaction')
        if friendly=='H' and faction~='Horde' then return end
        if friendly=='A' and faction~='Alliance' then return end
        local spawns=safeGet(entity,entityId,'spawns')
        local pts=type(spawns)=='table' and spawns[area]
        if type(pts)~='table' then return end
        for _,point in ipairs(pts) do
            if validPt(point) then
                local d=(point[1]-(px or 50))^2+(point[2]-(py or 50))^2
                if not bestSq or d<bestSq then
                    bestSq=d
                    best={map=map,x=point[1],y=point[2],npc=safeGet(entity,entityId,'name') or 'PNJ de quête'}
                end
            end
        end
    end
    for _,idNPC in ipairs(starters[1] or {}) do search(lib.Npc,idNPC) end
    for _,idObject in ipairs(starters[2] or {}) do search(lib.Object,idObject) end
    return best
end
function QF:BeginDiscovery()
    self.discoveryToken=(self.discoveryToken or 0)+1
    local token=self.discoveryToken
    self.discovery={}
    self.discoveryRunning=false
    self.discoveryError=nil
    local lib=_G.LibQuestieDB
    local questdb=lib and lib.Quest
    if not questdb or type(questdb.Get)~='function' then
        self.discoveryError='QuestieDB indisponible';self:UpdateUI();return
    end
    local map=self:MapID();local area=self:AreaForMap(map)
    if not map or not area then
        self.discoveryError='Zone non cartographiee : quetes du journal seulement';self:UpdateUI();return
    end
    local available,err=self:QuestieAvailableSet()
    local saved=self.observedOffers or {}
    if not available and not next(saved) then
        self.discoveryError=err or 'Attente de Questie';self:UpdateUI();return
    end
    local ids,seen={},{}
    if available then
        for id,yes in pairs(available) do
            if yes and type(id)=='number' and not seen[id] then ids[#ids+1]=id;seen[id]=true end
        end
    end
    for id,offer in pairs(saved) do
        if offer.map==map and not seen[id] then ids[#ids+1]=id;seen[id]=true end
    end
    local px,py=self:PlayerPosition();local discovered={}
    local level=UnitLevel('player') or 1
    local _,_,raceID=UnitRace and UnitRace('player')
    local _,_,classID=UnitClass and UnitClass('player')
    local rb=raceID and raceBit[raceID]
    local cb=classID and 2^(classID-1)
    local at=1
    self.discoveryRunning=true
    local function scan()
        if self.discoveryToken~=token then return end
        for _=1,35 do
            local id=ids[at];at=at+1
            if not id then break end
            if not (self.activeIds and self.activeIds[id]) and not self:QuestFinished(id) and not self:IsSkipped(id)
               and ((saved[id] and saved[id].map==map) or self:CandidateAllowed(id,questdb,level,rb,cb)) then
                local special=safeGet(questdb,id,'specialFlags')
                local eventLocked=(type(special)=='number' and math.floor(special/2)%2==1)
                if not eventLocked or (saved[id] and saved[id].map==map) then
                local questLevel=safeGet(questdb,id,'questLevel')
                -- Only offers Questie itself considers available (or seen at NPC).
                -- Avoid the strictly low-level spam unless the player enabled exploration.
                if self.db.mode=='explore' or type(questLevel)~='number' or questLevel>=level-9 then
                    local p=self:StarterFor(id,map,area,px,py)
                    local observed=saved[id]
                    if observed and observed.map==map then
                        p=p or {map=map,x=observed.x,y=observed.y,npc=observed.npc}
                    end
                    if p then
                        local dx=(p.x-(px or p.x));local dy=(p.y-(py or p.y))
                        local kind=self:QuestKind(id)
                        local q={id=id,title=safeGet(questdb,id,'name') or ('Quête '..id),
                            level=questLevel,kind=kind,active=false,potential=true,
                            verifiedOffer=observed and observed.map==map or false,
                            questieFiltered=available and available[id] and true or false,
                            npc=p.npc or 'Donneur de quête',zone=self:Zone(),x=p.x,y=p.y,
                            map=map,distance=math.sqrt(dx*dx+dy*dy)}
                        if self.QuestLocations then
                            q.futurePoint,q.returnPoint=self:QuestLocations(id,map,p.x,p.y)
                        end
                        local objectives=safeGet(questdb,id,'objectives')
                        if type(objectives)=='table' then
                            local count=0
                            for _,typ in ipairs(objectives) do
                                if type(typ)=='table' then
                                    for _,entry in ipairs(typ) do
                                        if type(entry)=='table' then
                                            count=count+math.max(1,tonumber(entry[2]) or 1)
                                        else count=count+1 end
                                    end
                                end
                            end
                            q.futureActions=math.min(30,math.max(3,count))
                        end
                        if self.AnnotateProfession then self:AnnotateProfession(q) end
                        if not q.missingProfession then discovered[#discovered+1]=q end
                    end
                end
                end -- event gate
            end
        end
        if at<=#ids then
            if C_Timer and C_Timer.After then C_Timer.After(0,scan)
            else self.discoveryRunning=false;self.discoveryError='Planificateur indisponible' end
        else
            if self.discoveryToken~=token then return end
            table.sort(discovered,function(a,b) return a.distance<b.distance end)
            for i=1,math.min(45,#discovered) do self.discovery[#self.discovery+1]=discovered[i] end
            self.totalFound=#discovered
            self.discoveryRunning=false
            self:Replan()
        end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0,scan) else scan() end
end
