local ADDON,QF=...
local frame=CreateFrame('Frame')
frame:RegisterEvent('PLAYER_LOGIN')
frame:RegisterEvent('PLAYER_XP_UPDATE')
frame:RegisterEvent('QUEST_LOG_UPDATE')
frame:RegisterEvent('QUEST_ACCEPTED')
frame:RegisterEvent('QUEST_REMOVED')
frame:RegisterEvent('QUEST_TURNED_IN')
frame:RegisterEvent('PLAYER_LEVEL_UP')
frame:RegisterEvent('ZONE_CHANGED_NEW_AREA')
frame:RegisterEvent('TAXIMAP_OPENED')
frame:RegisterEvent('GOSSIP_SHOW')
frame:RegisterEvent('QUEST_DETAIL')
frame:RegisterEvent('SKILL_LINES_CHANGED')
frame:SetScript('OnEvent',function(_,event,...)
    if event=='PLAYER_LOGIN' then
        QF:InitSettings()
        if QF.SampleXP then QF:SampleXP() end
        QF.ready=true
        QF:CreateUI()
        QF:Optimise()
        local api=_G.Questie and _G.Questie.API
        if api and type(api.RegisterOnReady)=='function' and not api.isReady then
            pcall(api.RegisterOnReady,function() if QF.ready then QF:Optimise() end end)
        end
        -- Questie builds its filtered quest list after login; refresh once it is ready.
        -- The timer is a bounded fallback, not a per-frame DB scan.
        if C_Timer and C_Timer.After then
            C_Timer.After(3,function() if QF.ready then QF:Optimise() end end)
            C_Timer.After(9,function() if QF.ready and #(QF.discovery or {})==0 then QF:Optimise() end end)
        end
        QF:Print('Prêt. /qf = interface, /qf opt = nouvelle route, /qf aide = commandes.')
    elseif not QF.ready then return
    elseif event=='PLAYER_XP_UPDATE' then
        if QF.SampleXP then QF:SampleXP() end
        local now=GetTime and GetTime() or 0
        if now-(QF.lastXPUI or -9999)>4 then
            QF.lastXPUI=now;QF:UpdateUI()
        end
    elseif event=='PLAYER_LEVEL_UP' then
        if QF.SampleXP then QF:SampleXP() end
        QF:Optimise()
    elseif event=='TAXIMAP_OPENED' then QF:OnTaxiOpened()
    elseif event=='SKILL_LINES_CHANGED' then QF:ReadProfessions();QF:Optimise()
    elseif event=='GOSSIP_SHOW' then
        QF:RememberNPCOffers();QF:Optimise()
    elseif event=='QUEST_DETAIL' then
        -- QuestID at the NPC is stronger evidence than the database alone.
        if GetQuestID then
            local id=GetQuestID()
            if id and id>0 then
                local x,y=QF:PlayerPosition()
                if x and y then
                    QF.observedOffers=QF.observedOffers or {}
                    QF.observedOffers[id]={map=QF:MapID(),x=x,y=y,time=QF:Time(),npc=UnitName and UnitName('questnpc')}
                end
            end
        end
    elseif event=='ZONE_CHANGED_NEW_AREA' then
        QF.db.focus=nil
        QF.currentId=nil
        QF:Optimise()
        QF:Print('Nouvelle zone détectée : parcours recalculé. Clique sur Optimiser pour relancer.')
    elseif event=='QUEST_TURNED_IN' or event=='QUEST_ACCEPTED' or event=='QUEST_REMOVED' then
        QF:Optimise()
    else
        -- Throttle noisy quest-log events; all explicit accept/turn-in events
        -- above still trigger an immediate discovery refresh.
        local now=GetTime and GetTime() or 0
        if event~='QUEST_LOG_UPDATE' or now-(QF.lastQuestLogAt or -9999)>.6 then
            QF.lastQuestLogAt=now;QF:Replan()
        end
    end
end)
SLASH_QUESTFLOW1='/qf'
SLASH_QUESTFLOW2='/questflow'
SlashCmdList.QUESTFLOW=function(msg)
    msg=(msg or ''):lower():match('^%s*(.-)%s*$')
    if not QF.ready then return end
    if msg=='opt' or msg=='optimiser' then QF:Optimise();QF:Print('Recherche d’un nouveau parcours.')
    elseif msg=='next' or msg=='suivant' then QF:FocusNext()
    elseif msg=='skip' or msg=='changer' then QF:ToggleSkipMenu()
    elseif msg=='options' then QF:ToggleSettings()
    elseif msg=='reset' then QF:ClearSkips();QF:Optimise()
    elseif msg=='anciennes' or msg=='obsolete' then
        if #(QF.obsolete or {})==0 then QF:Print('Aucune quête dépassée masquée actuellement.') end
        for _,q in ipairs(QF.obsolete or {}) do QF:Print('Masquée du guide (reste dans le journal) : '..q.title) end
    elseif msg=='flyok' then QF:AcknowledgeTip()
    elseif msg=='map' then QF:Waypoint()
    elseif msg=='fleche' or msg=='arrow' then QF:SetPreference('arrowEnabled',not QF.db.arrowEnabled)
    elseif msg=='foyer' then QF:RecordBindPosition();QF:SetPreference('useHearth',true)
    elseif msg=='sens' then QF:SetPreference('arrowInvert',not QF.db.arrowInvert);QF:Print('Orientation de la flèche inversée (test).')
    elseif msg=='xpreset' then
        QF.metrics={xp=0,seconds=0};QF:Print('Compteur XP/h remis à zéro.')
        QF:UpdateUI()
    elseif msg=='debug' then
        QF:Print('Zone='..tostring(QF:Zone())..', UiMap='..tostring(QF:MapID())..', Area='..tostring(QF:AreaForMap(QF:MapID()))..', QuestieDB='..tostring(_G.LibQuestieDB~=nil))
        local avail,err=QF:QuestieAvailableSet()
        QF:Print('Quêtes journal='..tostring(#(QF.quests or {}))..', Questie filtrée='..tostring(avail~=nil)..', propositions='..tostring(#(QF.discovery or {}))..', erreur='..tostring(QF.discoveryError or err))
    elseif msg=='aide' or msg=='help' then
        QF:Print('/qf foyer : marquer le lieu du foyer ; /qf opt : nouveau parcours ; /qf changer : reporter ; /qf next : autre objectif ; /qf options : filtres ; /qf reset : rétablir les quêtes ; /qf anciennes : voir les quêtes masquées ; /qf map : TomTom ; /qf sens : inverser flèche ; /qf fleche : on/off ; /qf debug : diagnostic')
    else
        if QF.frame:IsShown() then QF.frame:Hide();QF.db.visible=false
        else QF.frame:Show();QF.db.visible=true end
    end
end

-- Periodic route recomputation is throttled to 5s internally, and expensive
-- discovery scans to 45s + meaningful travel. Never rescan DB per frame.
local movement=CreateFrame('Frame')
movement:SetScript('OnUpdate',function(self,elapsed)
    if not QF.ready then return end
    self.elapsed=(self.elapsed or 0)+elapsed
    if self.elapsed>=1 then
        self.elapsed=0
        if QF.AutoTick then QF:AutoTick() end
    end
end)
