local ADDON,QF=...
-- Learns a bounded time per objective from quest-log changes. Only used by
-- the planner; observed XP/hour is never shown to the player.
function QF:ObserveQuestProgress()
    self._objectiveSample=self._objectiveSample or {}
    local now=GetTime and GetTime() or 0
    local nextSample={}
    local gains={}
    for _,q in ipairs(self.quests or {}) do
        local done=0
        for _,o in ipairs(q.objectives or {}) do
            if type(o.needed)=='number' and o.needed>0 then
                done=done+math.min(o.needed,tonumber(o.current) or (o.finished and o.needed or 0))
            elseif o.finished then done=done+1 end
        end
        local prev=self._objectiveSample[q.id]
        if prev and done>prev.done and done-prev.done<=6 then
            local delta=now-prev.at
            if delta>=6 and delta<=180 then gains[#gains+1]=delta/(done-prev.done) end
        end
        if not prev or done~=prev.done then nextSample[q.id]={done=done,at=now}
        else nextSample[q.id]=prev end
    end
    self._objectiveSample=nextSample
    if #gains>0 and self.db then
        local mean=0
        for _,v in ipairs(gains) do mean=mean+v end
        mean=mean/#gains
        if mean>=8 and mean<=90 then
            local old=self.db.secondsPerObjective or 24
            self.db.secondsPerObjective=math.max(12,math.min(65,old*.84+mean*.16))
            self.db.learnedActions=(self.db.learnedActions or 0)+1
        end
    end
end
