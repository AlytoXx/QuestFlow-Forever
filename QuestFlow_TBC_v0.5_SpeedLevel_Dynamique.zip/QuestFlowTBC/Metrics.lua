local ADDON,QF=...
local max,min=math.max,math.min
-- Actual observed XP and active elapsed time. Not a server-wide XP/hour claim.
function QF:SampleXP()
    if not(UnitXP and UnitXPMax and UnitLevel) then return end
    local xp,cap,level=UnitXP('player'),UnitXPMax('player'),UnitLevel('player')
    if not(xp and cap and level) then return end
    local now=GetTime and GetTime() or 0
    local prev=self.xpSample
    self.xpSample={xp=xp,cap=cap,level=level,at=now}
    if not prev then return end
    local gained=0
    if level==prev.level and xp>=prev.xp then gained=xp-prev.xp end
    if level==prev.level+1 then gained=max(0,prev.cap-prev.xp)+xp end
    if gained<=0 or gained>500000 then return end
    self.metrics=self.metrics or {xp=0,seconds=0}
    self.metrics.xp=self.metrics.xp+gained
    self.metrics.lastActionAt=now
end
function QF:MeasureTimeTick()
    if not self.db or self.db.xpTracking==false then return end
    local now=GetTime and GetTime() or 0
    self.metrics=self.metrics or {xp=0,seconds=0}
    local m=self.metrics
    local delta=now-(m.prevTick or now)
    m.prevTick=now
    local moving=GetUnitSpeed and (GetUnitSpeed('player') or 0)>0.2
    local fighting=UnitAffectingCombat and UnitAffectingCombat('player')
    if moving or fighting then m.lastActionAt=now end
    if not (UnitIsAFK and UnitIsAFK('player')) and delta>0 and delta<=10
       and now-(m.lastActionAt or -9999)<45 then
        m.seconds=m.seconds+delta
    end
end
function QF:MeasuredXPH()
    local m=self.metrics
    if not m or m.seconds<30 then return nil end
    return m.xp*3600/m.seconds
end
