local ADDON,QF=...
-- 0.4: Map-space bearing and world-space distance are deliberately independent.
-- Texture rotates COUNTERCLOCKWISE for positive angles (WoW SetRotation).
function QF:CalculateGuidance(q)
    local map=self:MapID()
    if not(map and q and q.map and q.x and q.y) then return nil,'Destination inconnue' end
    if map~=q.map then return nil,'Autre zone - voir la carte' end
    local x,y=self:PlayerPosition()
    if not x or not y then return nil,'Position inconnue' end
    local dist,verified=self:MapDistance({map=map,x=x,y=y},q)
    local bearing=self:HeadingOnMap(x,y,q.x,q.y)
    -- The two world axes are North and West (yards). Prefer them when both
    -- positions can be mapped to the same world space; this handles rotated
    -- or transformed maps more robustly than percentage-map bearings.
    if self.WorldPoint then
        local c1,n1,w1=self.WorldPoint(map,x,y)
        local c2,n2,w2=self.WorldPoint(q.map,q.x,q.y)
        if c1 and c2 and c1==c2 then
            bearing=self:HeadingOnMap(-w1,-n1,-w2,-n2)
        end
    end
    return {
        bearing=bearing,
        distance=verified and (dist*0.9144) or nil,
        arrived=verified and dist<13,
        verified=verified,
    },nil
end
function QF:CreateNavigation()
    if self.navFrame then return end
    local f=CreateFrame('Frame','QuestFlowTBCArrow',UIParent,'BackdropTemplate')
    f:SetSize(224,90)
    local p=self.db.arrowPoint
    if type(p)=='table' and type(p[4])=='number' then
        f:SetPoint(p[1] or 'CENTER',UIParent,p[3] or 'CENTER',p[4],p[5])
    else f:SetPoint('CENTER',UIParent,'CENTER',380,210) end
    if f.SetBackdrop then
        f:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=10,insets={left=2,right=2,top=2,bottom=2}})
        f:SetBackdropColor(.035,.055,.075,.93)
        f:SetBackdropBorderColor(.26,.56,.51,.65)
    end
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag('LeftButton')
    f:SetScript('OnDragStart',function(self) self:StartMoving() end)
    f:SetScript('OnDragStop',function(self)
        self:StopMovingOrSizing();local a,_,c,x,y=self:GetPoint(1)
        QF.db.arrowPoint={a,'UIParent',c,x,y}
    end)
    f.icon=f:CreateTexture(nil,'ARTWORK');f.icon:SetSize(66,66)
    f.icon:SetPoint('LEFT',f,'LEFT',8,0)
    f.icon:SetTexture('Interface\\AddOns\\QuestFlowTBC\\Arrow.tga')
    f.icon:SetVertexColor(.31,.94,.71)
    local function label(y,font)
        local t=f:CreateFontString(nil,'OVERLAY',font)
        t:SetPoint('TOPLEFT',f,'TOPLEFT',81,y)
        t:SetWidth(136);t:SetJustifyH('LEFT');return t
    end
    f.heading=label(-10,'GameFontNormalSmall')
    f.target=label(-30,'GameFontNormal')
    f.distance=label(-62,'GameFontNormal')
    f.distance:SetTextColor(.38,.98,.79)
    f:SetScript('OnUpdate',function(self,elapsed)
        self.tick=(self.tick or 0)+elapsed
        if self.tick<.12 then return end
        self.tick=0
        QF:UpdateArrowRealtime()
    end)
    self.navFrame=f
    self:RefreshNavigation()
end
function QF:SyncNavigation() if self.navFrame then self:RefreshNavigation() end end
function QF:RefreshNavigation()
    local f=self.navFrame
    if not f then return end
    if not self.db.arrowEnabled then f:Hide();return end
    f:Show()
    local q=self.route and self.route[1]
    if not q then
        f.heading:SetText('NAVIGATION');f.target:SetText('Aucune route')
        f.distance:SetText('/qf opt');f.icon:SetVertexColor(.45,.5,.5)
        f.icon:SetRotation(0);return
    end
    f.heading:SetText(q.complete and 'RENDRE LA QUÊTE' or q.potential and 'RÉCUPÉRER' or 'OBJECTIF ACTIF')
    f.target:SetText(q.title)
    f.distance:SetText('Calcul...')
    self:UpdateArrowRealtime()
end
function QF:UpdateArrowRealtime()
    local f=self.navFrame
    if not f or not f:IsShown() then return end
    local q=self.route and self.route[1]
    local guide,note=self:CalculateGuidance(q)
    if not guide then
        f.icon:SetRotation(0);f.icon:SetVertexColor(.5,.5,.5)
        f.distance:SetText(note or 'Position non disponible')
        return
    end
    if guide.arrived then f.distance:SetText('À destination')
    elseif guide.distance then f.distance:SetText(math.floor(guide.distance+.5)..' m (ligne droite)')
    else f.distance:SetText('Distance indisponible') end
    local facing=GetPlayerFacing and GetPlayerFacing()
    if type(facing)~='number' then
        f.icon:SetRotation(0);f.icon:SetVertexColor(.55,.55,.55)
        return
    end
    -- SetRotation rotates the icon clockwise on this client; GetPlayerFacing
    -- is counterclockwise from North. Invert their relative sign.
    local angle=facing-guide.bearing
    if QF.db.arrowInvert then angle=-angle end
    f.icon:SetRotation(angle)
    f.icon:SetVertexColor(.31,.94,.71)
end
