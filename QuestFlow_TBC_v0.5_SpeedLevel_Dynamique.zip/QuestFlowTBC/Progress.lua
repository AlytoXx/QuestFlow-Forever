local ADDON,QF=...

function QF:ComputeTip()
    local map=self:MapID()
    local zone=self:Zone()
    local level=UnitLevel('player') or 1
    local t
    if self.db.flightTips and map and not self.db.flightVisited[map] and not self.db.flyDismissed[map] then
        -- A reminder, NOT proof that this map has a flight master or that a node is missing.
        t={key='flight:'..map,title='Point de vol à vérifier',
          detail='Nouvelle zone : si un maître de vol est présent, débloque-le. Ouvre sa carte pour valider.',
          type='flight'}
    elseif self.db.trainerTips and level>=4 and level%2==0 and not self.db.acknowledged['trainer:'..level] then
        t={key='trainer:'..level,title='Compétences de classe',
          detail='Niveau '..level..' : vérifie si ton entraîneur propose de nouvelles compétences.',type='trainer'}
    elseif level>=30 and level<60 and not self.db.acknowledged['mount:30'] then
        t={key='mount:30',title='Monture terrestre',
          detail='Dès le niveau 30, vérifie l’entraînement de monte et ton budget monture.',type='mount'}
    elseif level>=60 and level<70 and not self.db.acknowledged['mount:60'] then
        t={key='mount:60',title='Monte rapide / Outreterre',
          detail='Vérifie la monte rapide et prépare tes accès et déplacements en Outreterre.',type='mount'}
    elseif level>=70 and not self.db.acknowledged['mount:70'] then
        t={key='mount:70',title='Vol en Outreterre',
          detail='Vérifie les conditions et le coût de la compétence de vol.',type='mount'}
    end
    if not t and self.TravelTip then t=self:TravelTip() end
    if not t and self.ProfessionReminder then t=self:ProfessionReminder() end
    self.tip=t
end
function QF:AcknowledgeTip()
    local t=self.tip
    if not t then return end
    if t.type=='flight' then
        local map=self:MapID()
        if map then self.db.flyDismissed[map]=true end
    else self.db.acknowledged[t.key]=true end
    self:Replan()
end
function QF:OnTaxiOpened()
    local map=self:MapID()
    if map then
        self.db.flightVisited[map]=true
        self.db.flyDismissed[map]=nil
    end
    -- The taxi node list is only reliably queryable while the taxi map is open.
    if NumTaxiNodes and TaxiNodeGetType and TaxiNodeName then
        self.db.knownTaxiNames=self.db.knownTaxiNames or {}
        local n=NumTaxiNodes() or 0
        for i=1,n do
            local status=TaxiNodeGetType(i)
            if status=='CURRENT' or status=='REACHABLE' then
                local name=TaxiNodeName(i)
                if name then self.db.knownTaxiNames[name]=true end
            end
        end
    end
    self:Replan()
end
