local ADDON,QF=...
-- QuestFlow v0.5: receding-horizon planner. The internal reward units and
-- travel times are MODELS, not a claim of measured/guaranteed XP/hour.
local min,max,abs=math.min,math.max,math.abs
local function shallow(t)
    local out={};for k,v in pairs(t) do out[k]=v end;return out
end
local function hasPosition(q)
    return q and type(q.map)=='number' and type(q.x)=='number' and type(q.y)=='number'
end
local function point(q)
    if hasPosition(q) then return {map=q.map,x=q.x,y=q.y} end
end
local function unknownXP(q)
    -- Fallback used ONLY to rank routes internally. Not presented as quest XP.
    local lvl=tonumber(q.level) or (UnitLevel and UnitLevel('player')) or 10
    local same=UnitLevel and UnitLevel('player') or lvl
    local relative=max(.15,min(1.15,1-abs((same-lvl)*.07)))
    return max(110,55*lvl)*relative
end
function QF:QuestValue(q)
    if type(q.xp)=='number' and q.xp>0 then return q.xp,true end
    return unknownXP(q),false
end
function QF:IsAllowed(q)
    if self:IsSkipped(q.id) or q.kind=='raid' or q.missingProfession then return false end
    if q.profession and self.db.professionQuests==false then return false end
    if q.kind=='dungeon' then
        return self.db.dungeonQuests and (q.potential or q.complete or self.db.dungeonRuns)
    end
    if q.kind=='group' then return self.db.group end
    return self.db.solo
end
function QF:IsObsolete(q)
    if not self.db.hideObsolete or q.complete or not q.level or q.level<=0 then return false end
    local level=UnitLevel('player') or 1
    if q.level>level-(self.db.obsoleteDiff or 7) then return false end
    local quest=_G.LibQuestieDB and _G.LibQuestieDB.Quest
    if quest and quest.Get then
        local ok,kids=pcall(quest.Get,q.id,'childQuests')
        if ok and type(kids)=='table' then
            for _,kid in ipairs(kids) do
                local yes,val=pcall(quest.Get,kid,'questLevel')
                if yes and type(val)=='number' and val>=level-5 and not self:QuestFinished(kid) then return false end
            end
        end
    end
    return true
end
function QF:RemainFraction(q)
    if q.potential then return 1 end
    if q.complete then return 0 end
    local missing,total=0,0
    for _,o in ipairs(q.objectives or {}) do
        local need=tonumber(o.needed)
        if need and need>0 then
            local cur=max(0,min(need,tonumber(o.current) or (o.finished and need or 0)))
            total=total+need;missing=missing+need-cur
        else
            total=total+1;missing=missing+(o.finished and 0 or 1)
        end
    end
    if total==0 then return 1 end
    return max(.01,min(1,missing/total))
end
function QF:WorkEstimate(q)
    if q.complete then return 14 end
    if q.potential then return 15 end
    local remain=0
    for _,o in ipairs(q.objectives or {}) do
        if type(o.needed)=='number' and o.needed>0 then
            remain=remain+max(0,o.needed-(tonumber(o.current) or (o.finished and o.needed or 0)))
        elseif not o.finished then remain=remain+3 end
    end
    if remain==0 then remain=5*self:RemainFraction(q) end
    local perAction=max(10,min(65,(self.db.secondsPerObjective or 24)))
    local sec=18+remain*perAction
    if q.kind=='group' then
        sec=sec+(IsInGroup and IsInGroup() and 20 or 190)
    elseif q.kind=='dungeon' then
        sec=sec+(self.db.dungeonReady and 540 or 900)
    end
    return sec
end
function QF:TaskEstimate(q,from)
    local travel,dist,known=self:TravelEstimate(from,q)
    local hearth
    if self.HearthEstimate then hearth=self:HearthEstimate(from,q,travel) end
    if hearth then travel=hearth end
    local base,exact=self:QuestValue(q)
    local work=self:WorkEstimate(q)
    local uncertainty=1
    local endPoint=point(q)
    local extra=0
    if q.potential then
        -- One recommendation is 'take the quest'. Scoring looks ahead to the
        -- work and return that the pickup commits us to, rather than granting
        -- free XP when talking to the NPC.
        local future=q.futurePoint
        local finish=q.returnPoint
        local a=self:TravelEstimate(q,future or q)
        local b=self:TravelEstimate(future or q,finish or q)
        local tasks=type(q.futureActions)=='number' and q.futureActions or 8
        extra=a+b+max(120, tasks*(self.db.secondsPerObjective or 24))+18
        if q.kind=='dungeon' then extra=extra+(self.db.dungeonReady and 540 or 900) end
        if q.kind=='group' and not (IsInGroup and IsInGroup()) then extra=extra+210 end
        -- If objectives cannot be located, penalize speculation.
        if not future then uncertainty=uncertainty*.62;extra=extra+260 end
        if not finish then uncertainty=uncertainty*.77;extra=extra+180 end
        if not q.verifiedOffer then uncertainty=uncertainty*.82 end
        if finish then endPoint=finish elseif future then endPoint=future end
    elseif q.complete then
        if q.returnPoint and hasPosition(q.returnPoint) then endPoint=q.returnPoint end
    else
        -- Include the effort to return the finished quest; this is often the
        -- dominant unnecessary backtrack in simplistic guides.
        if q.returnPoint and hasPosition(q.returnPoint) then
            local t=self:TravelEstimate(q,q.returnPoint)
            extra=extra+t+14
            endPoint=q.returnPoint
        else extra=extra+105;uncertainty=uncertainty*.79 end
    end
    if not hasPosition(q) then uncertainty=uncertainty*.42 end
    if q.approximate then uncertainty=uncertainty*.90 end
    local benefit=base*uncertainty
    -- In a professional-quest mode, only an OWNED profession earns the bonus.
    if q.profession and self.db.professionQuests then benefit=benefit*1.22 end
    if q.kind=='group' and IsInGroup and IsInGroup() then benefit=benefit*1.07 end
    if q.kind=='dungeon' and not self.db.dungeonRuns then benefit=benefit*.4 end
    if q.kind=='dungeon' and self.db.dungeonRuns and self.db.dungeonReady then benefit=benefit*1.20 end
    if self.db.mode=='explore' and q.potential then benefit=benefit*1.16 end
    if self.db.mode=='balance' and q.kind=='group' then benefit=benefit*.9 end
    return {seconds=max(25,travel+work+extra),travel=travel,meters=dist,known=known,
      benefit=benefit,rawXP=base,exact=exact,endPoint=endPoint,confidence=uncertainty}
end
function QF:CandidatePool()
    local list,obsolete,seen={},{},{}
    for _,q in ipairs(self.quests or {}) do
        if type(q.id)=='number' and not self:QuestFinished(q.id) and self:IsAllowed(q) then
            if self:IsObsolete(q) then obsolete[#obsolete+1]=q
            else list[#list+1]=q;seen[q.id]=true end
        end
    end
    for _,q in ipairs(self.discovery or {}) do
        if type(q.id)=='number' and not seen[q.id] and not self:QuestFinished(q.id)
           and self:IsAllowed(q) and q.map==self:MapID() and (q.questieFiltered or q.verifiedOffer) then
            list[#list+1]=q;seen[q.id]=true
        end
    end
    self.obsolete=obsolete
    return list
end
-- Avoid the classic back-and-forth bug: if two accepted quests have
-- objectives in the same region and share a return hub, finish both before
-- returning. Savings compare hub round trips with one combined loop.
function QF:ClusterSavings(previous,nextTask)
    if not(previous and nextTask and previous.active and nextTask.active) then return 0 end
    if previous.complete or nextTask.complete or not previous.returnPoint or not nextTask.returnPoint then return 0 end
    local betweenHubs,reliable=self:MapDistance(previous.returnPoint,nextTask.returnPoint)
    if not betweenHubs or not ((reliable and betweenHubs<=120) or (not reliable and betweenHubs<=2.4)) then return 0 end
    local back=self:TravelEstimate(previous,previous.returnPoint)
    local out=self:TravelEstimate(previous.returnPoint,nextTask)
    local direct=self:TravelEstimate(previous,nextTask)
    return max(0,back+out-direct)
end
function QF:SearchRoute(candidates,start)
    local ranked={}
    for _,q in ipairs(candidates) do
        local e=self:TaskEstimate(q,start)
        q.estimatedTravel=e.travel
        q.estimatedSeconds=e.seconds
        q.estimatedMeters=e.meters
        q.estimatedRealDistance=e.known
        q.priority=e.benefit/max(25,e.seconds)
        ranked[#ranked+1]=q
    end
    table.sort(ranked,function(a,b)
        if a.priority==b.priority then return a.id<b.id end
        return a.priority>b.priority
    end)
    local shortlist,seen={},{}
    for i=1,min(12,#ranked) do
        local q=ranked[i];shortlist[#shortlist+1]=q;seen[q.id]=true
    end
    -- Include productive tasks just off the path, even when solo efficiency
    -- ranks them lower, so the beam can reward combined trips.
    for _,q in ipairs(ranked) do
        if #shortlist>=20 then break end
        if not seen[q.id] then
            local d,real=self:MapDistance(start,q)
            if d and ((real and d<180) or (not real and d<3.5)) then
                shortlist[#shortlist+1]=q;seen[q.id]=true
            end
        end
    end
    local budget=(tonumber(self.db.timeBudget) or 0)*60
    local beam={{seq={},used={},time=0,reward=0,where=start,score=0}}
    local winner=nil
    for depth=1,min(5,#shortlist) do
        local expanded={}
        for _,route in ipairs(beam) do
            for _,q in ipairs(shortlist) do
                if not route.used[q.id] then
                    local e=self:TaskEstimate(q,route.where)
                    local previous=route.seq[#route.seq]
                    local saved=previous and self:ClusterSavings(previous,q) or 0
                    local t=route.time+e.seconds-saved
                    if budget==0 or t<=budget or depth==1 then
                        local seq={};for i,v in ipairs(route.seq) do seq[i]=v end;seq[#seq+1]=q
                        local used=shallow(route.used);used[q.id]=true
                        local reward=route.reward+e.benefit
                        -- Less distance wins when speed is otherwise similar.
                        local score=reward/max(1,t)
                        local nextRoute={seq=seq,used=used,time=t,reward=reward,
                             where=e.endPoint or route.where,score=score}
                        if not winner or score>winner.score then winner=nextRoute end
                        expanded[#expanded+1]=nextRoute
                    end
                end
            end
        end
        table.sort(expanded,function(a,b) return a.score>b.score end)
        beam={}
        for i=1,min(15,#expanded) do beam[i]=expanded[i] end
        if #beam==0 then break end
    end
    -- Prefer a coherent three-stop sequence over an isolated high-scoring task,
    -- but only if it is competitive (roughly within 8% on the model).
    if winner then
        for _,s in ipairs(beam) do
            if s.score>=winner.score*.92 and #s.seq>#winner.seq then winner=s end
        end
    end
    return winner and winner.seq or {},ranked,winner
end
function QF:DetourCandidate(pool,start,current)
    if self.db.autoDetours==false or not current then return nil end
    local d0,r0=self:MapDistance(start,current)
    if current.active and not current.complete and self:RemainFraction(current)<=.25 and d0
       and ((r0 and d0<120) or (not r0 and d0<2.4)) then return nil end
    local selected=nil;local bestGain=0
    for _,q in ipairs(pool) do
        if q.potential and q.id~=current.id and q.map==start.map and q.questieFiltered then
            local d1,r1=self:MapDistance(start,q)
            local d2,r2=self:MapDistance(q,current)
            if d1 and d2 and d0 and r0==r1 and r1==r2 then
                local extra=max(0,d1+d2-d0)
                local limit=r1 and 95 or 1.9
                if extra<=limit and d1<(r1 and 175 or 3.4) then
                    local e=self:TaskEstimate(q,start)
                    local cur=self:TaskEstimate(current,start)
                    -- The pickup is worthwhile only when the follow-up quest
                    -- actually has a route we can estimate (no blind events).
                    if q.futurePoint and e.confidence>=.4 then
                        local gain=e.benefit/max(1,e.seconds+extra/self:GroundSpeed())
                        if gain>bestGain and (gain>cur.benefit/max(1,cur.seconds)*.37) then
                            selected=q;bestGain=gain
                        end
                    end
                end
            end
        end
    end
    return selected
end
function QF:Plan()
    local pool=self:CandidatePool()
    local start=self:PlayerPoint()
    if not start then
        self.route={};self.ranked={};self.routeReport='Position introuvable'
        if self.ComputeTip then self:ComputeTip() end
        if self.SyncNavigation then self:SyncNavigation() end
        return
    end
    local seq,ranked,winner=self:SearchRoute(pool,start)
    local oldID=self.currentId
    local current=nil
    for _,q in ipairs(ranked) do if q.id==oldID then current=q;break end end
    local desired=seq[1]
    if self.db.focus then
        local selected=nil
        for _,q in ipairs(ranked) do if q.id==self.db.focus then selected=q;break end end
        if selected then desired=selected else self.db.focus=nil end
    end
    if not self.db.focus and desired then
        local detour=self:DetourCandidate(ranked,start,current or desired)
        if detour then desired=detour;self.lastReason='Quête sur le trajet' end
    end
    if current and desired and current.id~=desired.id and not self.db.focus then
        local now=GetTime and GetTime() or 0
        local stay=self:TaskEstimate(current,start)
        local swap=self:TaskEstimate(desired,start)
        local onWay=desired.potential and self:DetourCandidate({desired},start,current)
        local d,reliable=self:MapDistance(start,current)
        local almostDone=current.active and not current.complete and self:RemainFraction(current)<=.30
           and d and ((reliable and d<=130) or (not reliable and d<=2.7))
        local ratio=almostDone and 1.7 or 1.18
        if not onWay and (swap.benefit/max(1,swap.seconds)<stay.benefit/max(1,stay.seconds)*ratio
             or now-(self.lastSwitchAt or -9999)<30) then
            desired=current
        end
    end
    if desired then
        for i,q in ipairs(seq) do if q.id==desired.id then table.remove(seq,i);break end end
        table.insert(seq,1,desired)
    end
    self.route=seq;self.ranked=ranked
    if desired and desired.id~=oldID then self.lastSwitchAt=GetTime and GetTime() or 0 end
    self.currentId=desired and desired.id or nil
    self.routeReport=winner and 'Parcours recalculé (modèle de temps)' or 'Aucun parcours fiable'
    if self.ComputeTip then self:ComputeTip() end
    if self.SyncNavigation then self:SyncNavigation() end
end
function QF:RouteSummary()
    return string.format('%d étapes · %d nouvelles quêtes · %d masquées',#(self.route or {}),
      #(self.discovery or {}),#(self.obsolete or {}))
end
function QF:Waypoint()
    local q=self.route and self.route[1]
    if not hasPosition(q) then return self:Print('Destination non localisée. Consulte Questie.') end
    if TomTom and TomTom.AddWaypoint then
        if self.tomtomPoint and TomTom.RemoveWaypoint then pcall(TomTom.RemoveWaypoint,TomTom,self.tomtomPoint) end
        local ok,uid=pcall(TomTom.AddWaypoint,TomTom,q.map,q.x/100,q.y/100,
                 {title='QuestFlow : '..q.title,persistent=false,silent=true})
        if ok then self.tomtomPoint=uid;self:Print('Point transmis à TomTom.')
        else self:Print('TomTom n’a pas accepté le point.') end
    else self:Print('La flèche QuestFlow fonctionne sans TomTom.') end
end
