local ADDON,QF=...
-- QuestieDB locations; all coordinates remain area-specific.
local function get(entity,id,key)
    if not(entity and entity.Get and type(id)=='number') then return nil end
    local ok,v=pcall(entity.Get,id,key)
    if ok then return v end
end
local function selectNearest(entity,ids,area,map,px,py)
    if not entity or type(ids)~='table' then return nil end
    local best,dist=nil,nil
    for _,id in ipairs(ids) do
        local spots=get(entity,id,'spawns')
        spots=type(spots)=='table' and spots[area] or nil
        if type(spots)=='table' then
            for _,p in ipairs(spots) do
                if type(p)=='table' and type(p[1])=='number' and type(p[2])=='number'
                   and p[1]>=0 and p[1]<=100 and p[2]>=0 and p[2]<=100 then
                    local d=(p[1]-px)^2+(p[2]-py)^2
                    if not dist or d<dist then
                        dist=d
                        best={map=map,x=p[1],y=p[2],approximate=true}
                    end
                end
            end
        end
    end
    return best
end
function QF:QuestLocations(id,map,px,py)
    local area=self:AreaForMap(map)
    local lib=_G.LibQuestieDB
    if not(area and lib and lib.Quest and lib.Quest.Get) then return nil,nil end
    px=px or 50;py=py or 50
    local started=get(lib.Quest,id,'startedBy')
    local ended=get(lib.Quest,id,'finishedBy')
    local objectives=get(lib.Quest,id,'objectives')
    local function group(list)
        if type(list)~='table' then return nil end
        return selectNearest(lib.Npc,list[1],area,map,px,py)
            or selectNearest(lib.Object,list[2],area,map,px,py)
    end
    local finish=group(ended)
    local work=nil
    if type(objectives)=='table' then
        local npcs,objects={},{}
        for _,v in ipairs(objectives[1] or {}) do if type(v)=='table' and type(v[1])=='number' then npcs[#npcs+1]=v[1] end end
        for _,v in ipairs(objectives[2] or {}) do if type(v)=='table' and type(v[1])=='number' then objects[#objects+1]=v[1] end end
        for _,v in ipairs(objectives[3] or {}) do
            if lib.Item and type(v)=='table' and v[1] then
                local mobs=get(lib.Item,v[1],'npcDrops')
                local objs=get(lib.Item,v[1],'objectDrops')
                for _,mob in ipairs(type(mobs)=='table' and mobs or {}) do npcs[#npcs+1]=mob end
                for _,obj in ipairs(type(objs)=='table' and objs or {}) do objects[#objects+1]=obj end
            end
        end
        work=selectNearest(lib.Npc,npcs,area,map,px,py) or selectNearest(lib.Object,objects,area,map,px,py)
    end
    return work,finish
end
-- Overlay our safety checks on the existing target resolver without overriding
-- Blizzard's exact quest POI coordinates when they are present.
local previous=QF.LocateActiveQuests
function QF:LocateActiveQuests()
    if previous then previous(self) end
    local map=self:MapID()
    if not map then return end
    local px,py=self:PlayerPosition()
    for _,q in ipairs(self.quests or {}) do
        local work,finish=self:QuestLocations(q.id,map,px,py)
        q.workPoint=work
        q.returnPoint=finish
        if q.complete and finish then
            q.map=finish.map;q.x=finish.x;q.y=finish.y;q.approximate=true
        elseif not q.x and work then
            q.map=work.map;q.x=work.x;q.y=work.y;q.approximate=true
        end
    end
end
