local ADDON,QF=...
-- Travel shortcuts are offered only when the actual binding coordinate was
-- recorded by the player. A place name alone cannot validate a waypoint.
function QF:RecordBindPosition()
    local p=self:PlayerPoint()
    if not p then return self:Print('Position inconnue : enregistre le foyer dans une auberge.') end
    self.db.bindPoint={map=p.map,x=p.x,y=p.y,name=GetBindLocation and GetBindLocation() or self:Zone()}
    self:Print('Position du foyer enregistrée : '..(self.db.bindPoint.name or 'auberge')..'.')
end
function QF:HearthEstimate(from,destination,walking)
    if not(self.db and self.db.useHearth and self.db.bindPoint and from and destination) then return nil end
    local bind=self.db.bindPoint
    if GetBindLocation and bind.name and bind.name~=GetBindLocation() then return nil end
    if not(GetItemCount and (GetItemCount(6948) or 0)>0 and GetItemCooldown) then return nil end
    local start,duration=GetItemCooldown(6948)
    if start and duration and start+duration>(GetTime and GetTime() or 0)+1 then return nil end
    local me=self:PlayerPoint()
    local close,real=self:MapDistance(from,me)
    if not(close and ((real and close<=12) or (not real and close<=.25))) then return nil end
    local after,_,sure=self:TravelEstimate(bind,destination)
    if not sure then return nil end
    -- A cast and loading screen are modelled conservatively as 35 s.
    local total=35+after
    if walking and walking-total>=95 then return total,walking-total end
end
function QF:TravelTip()
    local q=self.route and self.route[1]
    if not q then return nil end
    local p=self:PlayerPoint()
    local walk=p and self:TravelEstimate(p,q)
    local estimate,saved=self:HearthEstimate(p,q,walk)
    if estimate and saved then
        local key='hearth:'..q.id
        if not self.db.acknowledged[key] then
            return {key=key,title='Raccourci : pierre de foyer',
             detail='Foyer enregistré : trajet potentiellement plus rapide (à vérifier).',type='travel'}
        end
    end
end
