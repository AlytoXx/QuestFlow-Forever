local ADDON,QF=...
local function button(parent,label,w,x,y,action)
    local b=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
    b:SetSize(w,24);b:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
    b:SetText(label);b:SetScript('OnClick',action)
    return b
end
local function line(parent,x,y,w,font)
    local t=parent:CreateFontString(nil,'OVERLAY',font or 'GameFontNormal')
    t:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
    t:SetWidth(w);t:SetJustifyH('LEFT');return t
end
local function backdrop(f)
    if f.SetBackdrop then
        f:SetBackdrop({bgFile='Interface\\Buttons\\WHITE8X8',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=11,
          insets={left=3,right=3,top=3,bottom=3}})
        f:SetBackdropColor(.025,.043,.058,.94)
        f:SetBackdropBorderColor(.26,.58,.5,.72)
    end
end
function QF:CreateUI()
    if self.frame then return end
    local f=CreateFrame('Frame','QuestFlowTBCPanel',UIParent,'BackdropTemplate')
    f:SetSize(336,242)
    local p=self.db.point
    if type(p)=='table' and type(p[4])=='number' then
        f:SetPoint(p[1] or 'CENTER',UIParent,p[3] or 'CENTER',p[4],p[5])
    else f:SetPoint('CENTER',UIParent,'CENTER',320,0) end
    backdrop(f)
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag('LeftButton')
    f:SetScript('OnDragStart',function(self) self:StartMoving() end)
    f:SetScript('OnDragStop',function(self)
        self:StopMovingOrSizing()
        local a,_,c,x,y=self:GetPoint(1)
        QF.db.point={a,'UIParent',c,x,y}
    end)
    self.frame=f
    self.label=line(f,12,-12,275,'GameFontNormalLarge')
    self.zoneLabel=line(f,12,-39,313,'GameFontNormalSmall')
    self.goal=line(f,12,-67,305,'GameFontNormal')
    self.detail=line(f,12,-91,310,'GameFontNormalSmall')
    self.progress=line(f,12,-115,307,'GameFontNormalSmall')
    self.extra1=line(f,12,-141,307,'GameFontNormalSmall')
    self.extra2=line(f,12,-158,307,'GameFontNormalSmall')
    self.tipLabel=line(f,12,-185,270,'GameFontNormalSmall')
    button(f,'Optimiser',112,10,-211,function() QF:Optimise() end)
    button(f,'Changer',98,125,-211,function() QF:ToggleSkipMenu() end)
    button(f,'Options',90,227,-211,function() QF:ToggleSettings() end)
    button(f,'X',28,300,-10,function() f:Hide();QF.db.visible=false end)
    self.tipButton=button(f,'OK',40,283,-181,function() QF:AcknowledgeTip() end)
    self.waypointButton=button(f,'>',27,300,-66,function() QF:Waypoint() end)
    local menu=CreateFrame('Frame',nil,f,'BackdropTemplate')
    menu:SetSize(314,181);menu:SetPoint('TOPLEFT',f,'BOTTOMLEFT',10,-5)
    backdrop(menu)
    line(menu,10,-10,290):SetText('Reporter cet objectif :')
    local why={{'Trop de monde','crowd'},{'Trop loin','far'},{'Trop difficile','hard'},
       {'Groupe absent','group'},{'Plus tard','later'},{'Pas envie','unwanted'}}
    for i,reason in ipairs(why) do
        local col=(i-1)%2;local row=math.floor((i-1)/2)
        button(menu,reason[1],140,12+col*151,-35-row*29,function()
            local q=QF.route and QF.route[1]
            if q then QF:Skip(q.id,reason[2]);QF:Print('Objectif reporté : '..q.title) end
            menu:Hide()
        end)
    end
    button(menu,'Rétablir les reports',190,12,-135,function() QF:ClearSkips();menu:Hide() end)
    menu:Hide();self.skipMenu=menu
    local opt=CreateFrame('Frame',nil,f,'BackdropTemplate')
    opt:SetSize(314,464);opt:SetPoint('TOPRIGHT',f,'TOPLEFT',-6,0)
    backdrop(opt)
    line(opt,10,-10,285):SetText('Paramètres XP / activités')
    local opts={{'Quêtes solo','solo'},{'Quêtes de groupe','group'},
      {'Quêtes de donjon','dungeonQuests'}, {'Sessions de donjon','dungeonRuns'},
      {'Masquer quêtes dépassées','hideObsolete'}, {'Flèche de navigation','arrowEnabled'},
      {'Recalcul automatique','autoRoute'}, {'Détours utiles','autoDetours'},
      {'Quêtes de mes métiers','professionQuests'}, {'Rappels de métier','professionTips'},
      {'Foyer enregistré','useHearth'}, {'Groupe prêt pour donjon','dungeonReady'}}
    for i,optEntry in ipairs(opts) do
        local b=button(opt,'',292,10,-33-(i-1)*27,function()
            QF:SetPreference(optEntry[2],not QF.db[optEntry[2]])
            QF:RefreshOptions()
        end)
        b.key=optEntry[2];b.caption=optEntry[1]
        self.optionButtons=self.optionButtons or {}
        self.optionButtons[#self.optionButtons+1]=b
    end
    self.modeButton=button(opt,'Mode : XP maximum',292,10,-370,function()
        local cycles={xp='balance',balance='explore',explore='xp'}
        QF:SetPreference('mode',cycles[QF.db.mode] or 'xp');QF:RefreshOptions()
    end)
    self.timeButton=button(opt,'Session : 60 minutes',292,10,-399,function()
        local cycles={[15]=30,[30]=60,[60]=120,[120]=0,[0]=15}
        QF:SetPreference('timeBudget',cycles[QF.db.timeBudget] or 60);QF:RefreshOptions()
    end)
    opt:Hide();self.settingsMenu=opt
    self:RefreshOptions()
    if self.CreateNavigation then self:CreateNavigation() end
    if self.db.visible==false then f:Hide() end
end
function QF:RefreshOptions()
    local names={xp='XP maximum',balance='Équilibré',explore='Exploration'}
    if self.modeButton then self.modeButton:SetText('Mode : '..(names[self.db.mode] or 'XP maximum')) end
    if self.timeButton then
        self.timeButton:SetText('Session : '..(self.db.timeBudget==0 and 'libre' or ((self.db.timeBudget or 60)..' min')))
    end
    for _,b in ipairs(self.optionButtons or {}) do
        b:SetText((self.db[b.key] and '|cff6ee7b7[✓]|r ' or '[ ] ')..b.caption)
    end
end
function QF:ToggleSkipMenu()
    if not self.skipMenu then return end
    if self.skipMenu:IsShown() then self.skipMenu:Hide() else
        if self.settingsMenu then self.settingsMenu:Hide() end
        self.skipMenu:Show()
    end
end
function QF:ToggleSettings()
    if not self.settingsMenu then return end
    if self.settingsMenu:IsShown() then self.settingsMenu:Hide() else
        if self.skipMenu then self.skipMenu:Hide() end
        self.settingsMenu:Show()
    end
end
local function detailFor(q)
    if not q then return 'Aucune destination fiable. Ouvre Questie ou réoptimise.' end
    if q.potential then
        return (q.verifiedOffer and 'Offerte par ' or 'Questie : à confirmer auprès de ')
           ..(q.npc or 'un PNJ')
    end
    if q.complete then return 'Objectifs terminés : rendre cette quête.' end
    for _,o in ipairs(q.objectives or {}) do
        if not o.finished then return (o.text or 'Objectif en cours')..(q.approximate and ' · Position approchée' or '') end
    end
    return 'Consulte les objectifs sur la carte Questie.'
end
function QF:UpdateUI()
    if not self.frame then return end
    self.label:SetText('|cff6ee7b7QuestFlow TBC|r  |cff899da4v0.5|r')
    self.zoneLabel:SetText(self:Zone()..' · '..tostring(#(self.route or {}))..' étapes · Mode '..(self.db.mode=='xp' and 'XP rapide' or self.db.mode=='explore' and 'Exploration' or 'Équilibré'))
    local q=self.route and self.route[1]
    self.goal:SetText(q and ((q.complete and '|cff80ed97[Rendre]|r ' or
      q.potential and '|cffffc27c[Prendre]|r ' or '|cffd4e9f2[En cours]|r ')..q.title)
      or '|cffffc27cAucune quête adaptée|r')
    self.detail:SetText(detailFor(q))
    local remaining=''
    if q and q.active and not q.complete then
        local total,left=0,0
        for _,o in ipairs(q.objectives or {}) do
            if tonumber(o.needed) then
                total=total+o.needed;left=left+math.max(0,o.needed-(tonumber(o.current) or 0))
            end
        end
        if total>0 then remaining=' · '..left..'/'..total..' restants' end
    end
    self.progress:SetText((q and 'Parcours adaptatif' or 'En attente de quête')..remaining)
    local a=self.route and self.route[2];local b=self.route and self.route[3]
    self.extra1:SetText(a and ('2. '..(a.potential and 'Prendre : ' or a.complete and 'Rendre : ' or '')..a.title) or '2. —')
    self.extra2:SetText(b and ('3. '..(b.potential and 'Prendre : ' or b.complete and 'Rendre : ' or '')..b.title) or '3. —')
    if self.tip then
        self.tipLabel:SetText('|cffffc27c'..self.tip.title..'|r · '..self.tip.detail)
        self.tipButton:Show()
    else self.tipLabel:SetText('');self.tipButton:Hide() end
    if self.discoveryError and not q then self.detail:SetText(self.discoveryError) end
    if q and q.map and q.x and q.y then self.waypointButton:Show() else self.waypointButton:Hide() end
    if self.navFrame then self:RefreshNavigation() end
end
